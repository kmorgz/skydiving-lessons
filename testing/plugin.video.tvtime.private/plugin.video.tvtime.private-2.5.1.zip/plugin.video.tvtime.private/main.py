"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import json
import os
import sys
import urllib
import urllib2
import jsbeautifier.unpackers.packer as packer
import requests
import xbmc
import xbmcgui
import xbmcplugin
from datetime import datetime, timedelta
import time
from bs4 import BeautifulSoup
from resources.lib import common, tvtime
from resources.lib import channels
import m7lib

common.plugin_url = sys.argv[0]
common.plugin_handle = int(sys.argv[1])
common.plugin_queries = common.parse_query(sys.argv[2][1:])

mode = common.plugin_queries['mode']

access_key = tvtime.TVtime().access_key

key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})['status']

if key_check == 'offline':
    common.dlg.ok(common.addonname, common.get_string(90000))
    exit()

if key_check != 'success':
    # Enter Access Key
    retval = common.dlg.input(common.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if retval and len(retval) > 0:
        common.set_setting('access_key', str(retval))
        access_key = common.get_setting('access_key')
        key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})[
            'status']
    if len(common.get_setting('access_key')) > 0 and key_check == 'success':
        common.dlg.ok(common.addonname, common.get_string(70000))
    else:
        common.dlg.ok(common.addonname, common.get_string(80000))
        exit()

if mode == 'main':
    try:
        main_menu = tvtime.TVtime()._get_json('/menus/main' + base64.b64decode('LnBocA=='), {'key': access_key})
        main_menu_results = main_menu['results']
        for i in main_menu_results:
            if i['status'] == 'on':
                if os.path.isfile(xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                    icon = xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
                else:
                    icon = xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
                common.add_directory({'mode': i['mode']}, i['label'], img=icon)

        if len(common.get_setting('notify')) > 0:
            common.set_setting('notify', str(int(common.get_setting('notify')) + 1))
        else:
            common.set_setting('notify', "1")
        if int(common.get_setting('notify')) == 1:
            common.dlg.notification('Like ' + common.addonname + ' Private?', 'Keep it Private!', common.ICON, 5000, False)
        elif int(common.get_setting('notify')) == 9:
            common.set_setting('notify', "0")
    except:
        common.dlg_oops(common.addonname)

# Begin ArconaiTV #
elif mode == 'arconaitv':
    try:
        arconaitv_menu = tvtime.TVtime()._get_json('/menus/arconaitv' + base64.b64decode('LnBocA=='), {'key': access_key})
        arconaitv_menu_results = arconaitv_menu['results']
        for i in arconaitv_menu_results:
            if i['status'] == 'on':
                common.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                    os.path.join(common.plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg')))
    except:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_live':
    try:
        channels = tvtime.TVtime().get_arconaitv_streams('Cable')
        if channels:
            for c in sorted(channels, reverse=False):
                channel = c['channel']
                id = c['id']
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + common.random_generator()
                logo = xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'logos', c['img']))
                cm_refresh = (common.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (common.plugin_url))
                cm_menu = [cm_refresh]
                common.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                      cm_replace=False)
        else:
            common.dlg_oops(common.addonname)
    except:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_tv_show_channels':
    try:
        channels = tvtime.TVtime().get_arconaitv_streams('Shows')
        if channels:
            for c in sorted(channels, reverse=False):
                channel = c['channel']
                id = c['id']
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + common.random_generator()
                logo = c['img']
                cm_refresh = (common.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (common.plugin_url))
                cm_menu = [cm_refresh]
                common.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                      cm_replace=False)
        else:
            common.dlg_oops(common.addonname)
    except:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_movie_channels':
    try:
        channels = tvtime.TVtime().get_arconaitv_streams('Movies')
        if channels:
            for c in sorted(channels, reverse=False):
                channel = c['channel']
                id = c['id']
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + common.random_generator()
                logo = xbmc.translatePath(
                    os.path.join(common.plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
                cm_refresh = (common.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (common.plugin_url))
                cm_menu = [cm_refresh]
                common.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                      cm_replace=False)
        else:
            common.dlg_oops(common.addonname)
    except:
        common.dlg_oops(common.addonname)
# End ArconaiTV #

# End Pokemon Fire #
elif mode == 'pokemon_fire':
    try:
        season_path_base = "https://www.pokemonfire.com/seasons/"
        icon_path_base = "https://www.pokemonfire.com/wp-content/uploads/"
        for season in channels.Channel().pokemon_seasons:
            common.add_dir(season["name"], "", season_path_base + season["season"], 500, icon_path_base + season["icon"])
    except:
        common.dlg_oops(common.addonname)
# End Pokemon Fire #

# Begin Fluxus IPTV #
elif mode == 'fluxus_main':
    try:
        # Set protect flag.
        common.set_setting('protect', "true")

        fluxus_menu = tvtime.TVtime()._get_json('/menus/fluxus' + base64.b64decode('LnBocA=='), {'key': access_key})
        fluxus_menu_results = fluxus_menu['results']
        for i in fluxus_menu_results:
            if i['status'] == 'on':
                if os.path.isfile(xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                    icon = xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
                else:
                    icon = xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
                common.add_directory({'mode': i['mode']}, i['label'], img=icon)

        if common.get_setting('enable_adult_sections') == 'true':
            if os.path.isfile(xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))):
                icon = xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))
            else:
                icon = xbmc.translatePath(
                    os.path.join(common.plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
            common.add_directory({'mode': "fluxus_lust"}, "Fluxus Lust", img=icon)
    except:
        common.dlg_oops(common.addonname)

elif mode == 'fluxus_iptv':
    try:
        fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                                {'key': access_key, 'list': mode.replace("fluxus_","")})
        fluxus_menu_results = fluxus_menu

        # Get Updated Date
        for i in sorted(fluxus_menu_results):
            try:
                if "=" in i['tvtitle']:
                    tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                    if "tvlogo" not in tvtitle:
                        if i['tvlogo'] == "":
                            img = 'https://i.imgur.com/CvQCnwZ.png'
                        else:
                            img = i['tvlogo']
                        common.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass

        # Get Streams
        for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
            try:
                if i['tvgroup'] == "USA" or \
                        i['tvgroup'] == "USA LOCAL" or \
                        i['tvgroup'] == "UK" or \
                        i['tvgroup'] == "CANADA" or \
                        i['tvgroup'] == "AUSTRALIA":
                    tvtitle = json.dumps(i['tvtitle']).replace('"','')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    common.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass
    except:
        common.dlg_oops(common.addonname)

elif mode == 'fluxus_cctv' or mode == 'fluxus_faith' or mode == 'fluxus_lust':
    try:
        def get_fluxus():
            fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                                    {'key': access_key, 'list': mode.replace("fluxus_", "")})
            fluxus_menu_results = fluxus_menu

            # Get Updated Date
            for i in sorted(fluxus_menu_results):
                try:
                    if "=" in i['tvtitle']:
                        tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                        if i['tvlogo'] == "":
                            img = 'https://i.imgur.com/CvQCnwZ.png'
                        else:
                            img = i['tvlogo']
                        common.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
                except KeyError:
                    pass

            # Get Streams
            for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
                try:
                    if i['tvgroup'] != "INFO" and i['tvgroup'] != "LABEL" and "* Fluxus Lust" not in i['tvtitle']:
                        tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                        if i['tvlogo'] == "":
                            img = 'https://i.imgur.com/CvQCnwZ.png'
                        else:
                            img = i['tvlogo']
                        common.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
                except KeyError:
                    pass

        if mode == 'fluxus_lust':
            # Access Key Protection
            if str(common.get_setting('protect')) == 'true':
                retval = common.dlg.input(common.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                lock_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': retval})[
                    'status']

                if lock_check == 'success':
                    # Set protect flag. This will be set back to true once use 'backs out' of Fluxus Lust section.
                    common.set_setting('protect', "false")

                    common.dlg.ok(common.addonname, common.get_string(900004))

                    get_fluxus()

                else:
                    common.dlg.ok(common.addonname, common.get_string(80000))
                    exit()

            elif str(common.get_setting('protect')) == 'false':
                get_fluxus()

        else:
            get_fluxus()
    except:
        common.dlg_oops(common.addonname)

elif mode == 'fluxus_cinema':
    try:
        fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                                {'key': access_key, 'list': mode.replace("fluxus_","")})
        fluxus_menu_results = fluxus_menu
        for i in sorted(fluxus_menu_results, reverse=False):
            try:
                if i['tvgroup'] == "MOVIES" or "=" in i['tvtitle']:
                    if "=" in i['tvtitle']:
                        tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                    else:
                        tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    common.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass
    except:
        common.dlg_oops(common.addonname)
# End Fluxus IPTV #

# End Lodge TV IPTV #
elif mode == 'lodge_tv_main':
    try:
        lodgetv_menu = tvtime.TVtime()._get_json('/lodgetv/v1/get_list' + base64.b64decode('LnBocA=='),
                                                   {'key': access_key, 'list': 'english'})
        lodgetv_menu_results = lodgetv_menu

        # Get Updated Date
        for i in sorted(lodgetv_menu_results):
            if "~" not in i['tvtitle'] and "=" in i['tvtitle']:
                tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                img = i['tvlogo']

                common.addlink_live(tvtitle, '', i['tvmedia'], 400, img)

        # Get Streams
        for i in sorted(lodgetv_menu_results, key=lambda k: k['tvtitle']):
            if "~" not in i['tvtitle'] and "=" not in i['tvtitle'] and ">" not in i['tvtitle'] and "LODGE" not in i['tvtitle']:
                img = i['tvlogo']

                common.addlink_live(i['tvtitle'], '', i['tvmedia'], 400, img)
    except:
        common.dlg_oops(common.addonname)
# End Lodge TV IPTV #

# End Stratus TV IPTV #
elif mode == 'stratus_tv_main':
    try:
        stratustv_menu = tvtime.TVtime()._get_json('/stratustv/v1/get_list' + base64.b64decode('LnBocA=='),
                                                   {'key': access_key, 'list': 'english'})
        stratustv_menu_results = stratustv_menu
        for i in sorted(stratustv_menu_results, key=lambda k: k['tvtitle']):
            try:
                tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                img = i['tvlogo']
                common.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass
    except:
        common.dlg_oops(common.addonname)
# End Stratus TV IPTV #

# Begin YouTube Channels #
elif mode == 'youtube_channels':
    try:
        youtube_channels_menu = tvtime.TVtime()._get_json('/menus/youtube_channels' + base64.b64decode('LnBocA=='),
                                                          {'key': access_key})
        youtube_channels_menu_results = youtube_channels_menu['results']

        for i in youtube_channels_menu_results:
            if i['status'] == 'on':
                common.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                    os.path.join(common.plugin_path, 'resources', 'images', 'logos', i['mode'] + '.jpg')))
    except:
        common.dlg_oops(common.addonname)

elif mode in tvtime.TVtime().get_youtube_channels():
    try:
        playlists = tvtime.TVtime().build_youtube_main(mode)
        if playlists:
            for c in sorted(playlists):
                common.add_directory({'mode': c['title'] + "-youtube-channel_" + mode}, c['title'], img = c['img'])
        else:
            common.dlg_oops(common.addonname)
    except:
        common.dlg_oops(common.addonname)
        exit()

elif "youtube-channel_" in mode:
    try:
        ymode = mode.split('_', 1)[-1]
        playlists = tvtime.TVtime().build_youtube_main(ymode)
        if playlists:
            for c in playlists:
                tvtime.TVtime().show_youtube_streams(c['title'], c['playlist_id'], mode)
    except:
        common.dlg_oops(common.addonname)
# End YouTube Channels #

# Begin Xumo TV & Movies #
elif mode == "xumo_direct_main":
    try:
        req = m7lib.Common().open_url(tvtime.TVtime().XUMO_BASE_API%"channels/list/10006.json?q=genreid:195")
        stations_json = json.loads(req)
        stations = stations_json["channel"]["item"]

        for i in sorted(stations, key=lambda k: k['title']):
            logo = tvtime.TVtime().XUMO_BASE_LOGO % (i["guid"]["value"])
            if i["title"] != "Docurama":
                m7lib.Common.add_section(i["title"] + "-xumo-channel_" + i["guid"]["value"], logo, common.FANART, i["title"])
            else:
                m7lib.Common.add_channel("xumo-stream_XM0CHNSP1IRFM6", logo, common.FANART, i["title"])
    except:
        common.dlg_oops(common.addonname)

elif "xumo-channel_" in mode:
    try:
        channel_id = mode.split('_', 1)[-1]
        req = m7lib.Common().open_url(tvtime.TVtime().XUMO_BASE_API%"channels/channel/%s/categories.json" % channel_id)
        categories_json = json.loads(req)
        categories = categories_json["categories"]

        for i in sorted(categories, key=lambda k: k['title']):
            title = i["title"].replace("&", "and")
            if ":" not in title:
                cat_id = i["categoryId"]
                logo = tvtime.TVtime().XUMO_BASE_LOGO % channel_id
                m7lib.Common.add_section(channel_id + "-xumo-category_" + cat_id, logo, common.FANART, title)
    except:
        common.dlg_oops(common.addonname)

elif "-xumo-category_" in mode:
    try:
        cat_id = mode.split('_', 1)[-1]
        channel_id = mode.split('-')[0]
        req = m7lib.Common().open_url(tvtime.TVtime().XUMO_BASE_API%"categories/category/%s.json?f=asset.title&f=asset.episodeTitle" % cat_id)

        movies_json = json.loads(req)
        movies = movies_json["results"]

        # Create Xumo cache directory #
        xumo_path = xbmc.translatePath('special://home/userdata/addon_data/' + common.addonid + '/xumo/')
        if not os.path.exists(xumo_path):
            os.mkdir(xumo_path)

        # Clean Xumo cache if cache is older than 30 days #
        if common.get_setting('xumo_cache') != "0":
            if datetime(*(time.strptime(common.get_setting('xumo_cache'), "%Y-%m-%d %H:%M:%S.%f")[0:6])) < datetime.now():
                common.set_setting('xumo_cache', "0")
                if os.path.exists(xumo_path):
                    for root, dirs, files in os.walk(xumo_path):
                        for currentFile in files:
                            os.remove(os.path.join(root, currentFile))

        # Xumo cache progress #
        progress = [1]
        progress_heading = 'Caching images...'
        progress_message = 'Cached images are cleared every 30 days.'

        for i in sorted(movies, key=lambda k: k['title']):
            logo_cache_path = xumo_path + i['id'] + '.jpg'
            if common.exists_local(logo_cache_path):
                if common.is_non_zero_file(logo_cache_path):
                    logo = logo_cache_path
                else:
                    logo = tvtime.TVtime().XUMO_BASE_LOGO % channel_id
            else:
                # Set Xumo cache date #
                if common.get_setting('xumo_cache') == "0":
                    common.set_setting('xumo_cache', str(datetime.now() + timedelta(days=30)))

                # Create Xumo progress bar #
                common.dlg_progress.create(progress_heading)

                # If Xumo progress dialog is canceled exit #
                if common.dlg_progress.iscanceled():
                    exit()
                urllib.urlretrieve(tvtime.TVtime().XUMO_BASE_THUMB % i["id"], logo_cache_path)

                # Increment progress bar #
                progress.append(1)

                if common.exists_local(logo_cache_path):
                    if common.is_non_zero_file(logo_cache_path):
                        logo = logo_cache_path
                    else:
                        logo = tvtime.TVtime().XUMO_BASE_LOGO % channel_id
                else:
                    logo = tvtime.TVtime().XUMO_BASE_LOGO % channel_id

                # Update Xumo progress bar #
                common.dlg_progress.update(int(len(progress) * (100 / len(movies))), progress_message, " ", "Images cached: [COLOR lightskyblue]" +
                                           str(len(progress) - 1) + "[/COLOR] of [COLOR lightskyblue]" + str(len(movies)) + "[/COLOR]")

            m7lib.Common.add_channel("xumo-stream_" + i["id"], logo, common.FANART, i["title"])
    except:
        common.dlg_oops(common.addonname)

elif "xumo-stream_" in mode:
    try:
        stream_id = mode.split('_', 1)[-1]
        req = m7lib.Common().open_url(tvtime.TVtime().XUMO_BASE_API%"/assets/asset/%s.json?f=title&f=providers" % stream_id)

        stream_json = json.loads(req)
        stream = m7lib.Common.rebase(stream_json["providers"][0]["sources"][0]["uri"])
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_oops(common.addonname)
    except:
        common.dlg_oops(common.addonname)
# End Xumo TV & Movies #

# Begin Free Live TV (Extra) #
elif mode == 'free_livetv_direct_main':
    try:
        # Generate Section List
        for section in sorted(m7lib.Common.get_sections(), reverse=False):
            m7lib.Common.add_section(section, m7lib.Common.get_logo(section, "section"), common.FANART)
    except:
        common.dlg_oops(common.addonname)

elif mode == "All Channels":
    try:
        channel_list = []

        m7lib_channels = m7lib.Common.get_channels()

        # Get channels from m7lib
        for channel in m7lib_channels:
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "m7lib"})

        # Add extra channels
        for channel in channels.Channel().free_live_tv_extra_channels:
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "extra"})

        # Add ustvgo channels
        for channel in channels.Channel().get_ustvgo_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "ustvgo"})

        # Add easyview channels
        for channel in channels.Channel().get_easyview_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "easyview"})

        # Build channel list
        for channel in sorted(channel_list):
            channel_logo = channels.get_channel_logo(channel["name"])
            if channel["source"] == "extra":
                m7lib.Common.add_channel(channel["name"], channel_logo, common.FANART)
            elif channel["source"] == "ustvgo":
                m7lib.Common.add_channel(channel["url"] + "_play-ustvgo", channel_logo, common.FANART, channel["name"])
            elif channel["source"] == "easyview":
                m7lib.Common.add_channel(channel["url"] + "_play-easyview", channel_logo, common.FANART, channel["name"])
            else:
                channel_logo = m7lib.Common.get_logo(channel["name"])
                m7lib.Common.add_channel(channel["name"] + "_play-m7lib", channel_logo, common.FANART, channel["name"])
    except:
        common.dlg_oops(common.addonname)

elif mode == "Genres":
    try:
        # Generate Genre List
        genres = channels.Channel().get_genres()
        for genre in sorted(genres, reverse=False):
            if genre == "Network TV" or genre == "Misc":
                logo = xbmc.translatePath(os.path.join(common.plugin_path, 'resources', 'images', 'genres', genre + '.png'))
            else:
                logo = m7lib.Common.get_logo(genre, "genre")
            m7lib.Common.add_section(genre, logo, common.FANART)
    except:
        common.dlg_oops(common.addonname)

elif mode in channels.Channel().get_genres():
    try:
        channel_list = []

        m7lib_channels = m7lib.Common.get_channels()

        # Get channels from m7lib
        for channel in m7lib_channels:
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "m7lib"})

        # Add extra channels
        for channel in channels.Channel().free_live_tv_extra_channels:
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "extra"})

        # Add ustvgo channels
        for channel in channels.Channel().get_ustvgo_channels():
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "ustvgo"})

        # Add easyview channels
        for channel in channels.Channel().get_easyview_channels():
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "easyview"})

        # Build channel list within given genre
        for channel in sorted(channel_list):
            channel_logo = channels.get_channel_logo(channel["name"])
            if channel["source"] == "extra":
                m7lib.Common.add_channel(channel["name"], channel_logo, common.FANART)
            elif channel["source"] == "ustvgo":
                m7lib.Common.add_channel(channel["url"] + "_play-ustvgo", channel_logo, common.FANART, channel["name"])
            elif channel["source"] == "easyview":
                m7lib.Common.add_channel(channel["url"] + "_play-easyview", channel_logo, common.FANART, channel["name"])
            else:
                channel_logo = m7lib.Common.get_logo(channel["name"])
                m7lib.Common.add_channel(channel["name"] + "_play-m7lib", channel_logo, common.FANART, channel["name"])
    except:
        common.dlg_oops(common.addonname)

elif "_play-m7lib" in mode:
    mode = mode.split('_')[0]
    m7lib.Common.get_stream_and_play(mode)

elif "_play-ustvgo" in mode:
    mode = mode.split('_')[0]
    channels.Channel().play_ustvgo(mode)

elif "_play-easyview" in mode:
    mode = mode.split('_')[0]
    channels.Channel().play_easyview(mode)

elif mode == 'ET Live':
    channels.Channel().play_et_live(mode)

elif mode == 'ABC News':
    channels.Channel().play_abc_news(mode)

elif mode == "CBS Sports HQ":
    channels.Channel().play_cbs_sports_hq(mode)

elif mode == "HLN":
    channels.Channel().play_hln(mode)

elif mode == 'CBSN':
    channels.Channel().play_cbs_news(mode)

elif mode == 'CBSN New York':
    channels.Channel().play_cbs_news_ny(mode)
# End Free Live TV (Extra) #

# Begin Play Modes #
elif mode == 'play_arconaitv':
    try:
        id = common.plugin_queries['id']
        r = requests.get('https://www.arconaitv.us/stream.php?id=' + id)
        html_text = r.text
        soup = BeautifulSoup(html_text, 'html.parser')
        scripts = soup.find_all('script')
        for script in scripts:
            if script.string is not None:
                if "document.getElementsByTagName('video')[0].volume = 1.0;" in script.string:
                    code = script.string
                    startidx = code.find('eval(function(p,a,c,k,e,')
                    endidx = code.find('hunterobfuscator =')
                    code = code[startidx: endidx]

                    if not code.replace(' ', '').startswith('eval(function(p,a,c,k,e,'):
                        code = 'fail'
                    break
                else:
                    code = 'fail'
            else:
                code = 'fail'

        if code != 'fail':
            USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36'
            addon_handle = int(sys.argv[1])
            unpacked = packer.unpack(code)
            video_location = unpacked[unpacked.rfind('http'): unpacked.rfind('m3u8') + 4]
            play_item = xbmcgui.ListItem(path=video_location + '|User-Agent=%s' % urllib2.quote(USER_AGENT, safe=''))
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            common.dlg_oops(common.addonname)
    except:
        common.dlg_oops(common.addonname)

elif mode == 'play-youtube':
    try:
        videoId = common.plugin_queries['videoId']
        stream_status = tvtime.TVtime()._get_json('/ytpowered/v1/check' + base64.b64decode('LnBocA=='), {'id': videoId})['status']
        if stream_status == 'true':
            channels.play_youtube(videoId)
        else:
            common.dlg_oops(common.addonname)
            exit()
    except:
        common.dlg_oops(common.addonname)
# End Play Modes #

# Begin Misc Mods #
elif mode == "settings":
    common.show_settings()

elif mode == 'refresh':
    xbmc.executebuiltin('Container.Refresh')
# End Misc Mods #


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()

url = None
name = None
mode = None
iconimage = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    name = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

# Begin Fluxus, Lodge TV, and Stratus TV IPTV #
if mode == 400:
    m7lib.Common.play(url)
# End Fluxus, Lodge TV, and Stratus TV IPTV #

# Begin Pokemon Fire #
elif mode == 500:
    tvtime.TVtime().pokemon_fire_seasons(url)

elif mode == 501:
    tvtime.TVtime().pokemon_fire_play(url)
# End Pokemon Fire #

common.end_of_directory()
