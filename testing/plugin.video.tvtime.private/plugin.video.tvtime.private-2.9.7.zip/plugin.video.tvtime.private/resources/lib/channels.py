"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import m7lib
import jsbeautifier
import base64
import json
import xbmc
import xbmcgui
import urlresolver
from datetime import datetime, timedelta
import time
import urllib

try:
    # Python 3
    from resources.lib import common
except ImportError:
    # Python 2
    import common

try:
    # Python 3
    from urllib.parse import quote
except ImportError:
    # Python 2
    import urllib2


class Channel:

    def __init__(self):
        # Begin Xumo TV & Movies #
        self.XUMO_BASE_API = 'https://valencia-app-mds.xumo.com/v2/%s'
        self.XUMO_BASE_LOGO = 'https://image.xumo.com/v1/channels/channel/%s/512x512.png?type=color_onBlack'
        self.XUMO_BASE_THUMB = 'https://image.xumo.com/v1/assets/asset/%s/512x512.jpg'
        # End Xumo TV & Movies #

        # Begin Live TV Direct #
        self.free_live_tv_extra_channels = [
            {"name": "ABC News", "type": "News"},
            {"name": "CBSN", "type": "News"},
            {"name": "CBSN New York", "type": "News"},
            {"name": "CBS Sports HQ", "type": "Sports"},
            {"name": "ET Live", "type": "Celebrity"},
            {"name": "HLN", "type": "News"}
        ]
        # End Live TV Direct #

    @staticmethod
    def get_genres():
        genres = m7lib.Common.get_genres()
        genres.append("Network TV")
        genres.append("Misc")
        return genres

    @staticmethod
    def get_channel_logo(channel):
        logo = os.path.join(common.plugin_path, 'resources', 'images', 'logos', channel + '.png')
        if os.path.isfile(logo):
            return logo
        return common.ICON

    @staticmethod
    def get_channel_poster(channel):
        filename = channel.replace(":", "").replace("&", "").replace("*", "").replace("+", "")
        logo = os.path.join(common.plugin_path, 'resources', 'images', 'posters', filename + '.jpg')
        if os.path.isfile(logo):
            return logo
        return common.ICON

    # Begin standalone live streams #
    @staticmethod
    def play_abc_news():
        link = m7lib.Common.open_url("https://www.livenewson.com/american/abc-news-2.html")
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, 'file: "(.+?)"'))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_news():
        site_url = "https://www.cbsnews.com/live/"
        match_string = '"contentUrl":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)


    @staticmethod
    def play_cbs_news_ny():
        site_url = "https://www.cbsnews.com/live/cbsn-local-ny/"
        match_string = '"video":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_sports_hq():
        site_url = "https://www.cbsnews.com/live/cbs-sports-hq/"
        match_string = '"video":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_hln():
        site_url = "https://www.livenewswatch.com/hln.html"
        match_string = 'file: "(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_et_live():
        site_url = "https://www.cbsnews.com/live/et-live/"
        match_string = '"video":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)
    # End standalone live streams #

    # Begin ustvgo #
    @staticmethod
    def get_ustvgo_channels():
        ustvgo_channels = []
        link = m7lib.Common.open_url("http://ustvgo.net/")
        matches = m7lib.Common.find_multiple_matches(link, '<li>(.*?)</li>')

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, '">(.+?)</a>')
            url = m7lib.Common.find_single_match(entry, '<a href="(.+?)"')
            channel = common.clean_channel_name(channel)
            genre = common.set_channel_genre(channel)
            if channel != "CNBC" and channel != "Tennis Channel":
                ustvgo_channels.append({"name": channel, "type": genre, "url": url})
        return ustvgo_channels

    def get_guide66_channels(self):
        guide66_channels = []
        link = m7lib.Common.open_url("https://guide66.info/")
        matches = m7lib.Common.find_multiple_matches(link, '<li>(.*?)</li>')

        other_channel_sources = []
        for channel in Channel.get_ustvgo_channels():
            other_channel_sources.append(channel["name"])
        for channel in self.free_live_tv_extra_channels:
            other_channel_sources.append(channel["name"])
        for channel in m7lib.Common.get_channels():
            other_channel_sources.append(channel["name"])

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, '">(.+?)</a>')
            url = m7lib.Common.find_single_match(entry, '<a href="(.+?)"')
            channel = common.clean_channel_name(channel)
            genre = common.set_channel_genre(channel)
            if channel not in other_channel_sources:
                guide66_channels.append({"name": channel, "type": genre, "url": url})
        return guide66_channels

    @staticmethod
    def play_ustvgo(url):
        link = m7lib.Common.open_url(url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, "file: '(.+?)'"))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)
    # End ustvgo #

    # Begin Easyview #
    @staticmethod
    def get_easyview_channels():
        easyview_channels = []
        link = m7lib.Common.open_url("https://easyview.eu/")
        matches = m7lib.Common.find_multiple_matches(link, '<li>(.*?)</li>')

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, '">(.+?)</a>')
            channel = common.clean_channel_name(channel)
            genre = common.set_channel_genre(channel)
            url = "https://easyview.eu/" + m7lib.Common.find_single_match(entry, '<a href="(.+?)"')
            if channel != "Home":
                easyview_channels.append({"name": channel, "type": genre, "url": url})
        return easyview_channels
    # End Easyview #

    @staticmethod
    def play_easyview(url):
        match_string = 'video.src = \'(.+?)\''

        req = m7lib.Common.open_url(url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    # Begin ArconaiTV #
    @staticmethod
    def get_arconaitv_channels(type):
        arconaitv_channels = []
        base_url = "https://www.arconaitv.us/"
        link = m7lib.Common.open_url(base_url)
        match = m7lib.Common.find_single_match(link, "<div class='stream-category'>" + type + "</div>(.+?)</div></div> </div>")

        matches = m7lib.Common.find_multiple_matches(match, "<a href(.*?)>")

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, "title='(.+?)'")
            channel = common.clean_channel_name(channel)
            url = base_url + m7lib.Common.find_single_match(entry, "='(.+?)'")
            arconaitv_channels.append({"name": channel, "url": url})
        return arconaitv_channels

    @staticmethod
    def play_arconaitv(url):
        link = m7lib.Common.open_url(url)
        match = m7lib.Common.find_single_match(link, "eval(.+?)</script>")
        code = "eval" + match

        if "(p,a,c,k,e,d)" in code:
            USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36'
            unpacked = jsbeautifier.beautify(code)
            video_location = unpacked[unpacked.rfind('http'): unpacked.rfind('m3u8') + 4]
            try:
                # Python 3
                stream = video_location + '|User-Agent=%s' % quote(USER_AGENT, safe='')
            except:
                # Python 2
                stream = video_location + '|User-Agent=%s' % urllib2.quote(USER_AGENT, safe='')

            m7lib.Common.play(stream)
        else:
            common.dlg_oops(common.addonname)
    # End ArconaiTV #

    # Begin Pokemon Fire #
    @staticmethod
    def play_pokemon(url):
        player_match_string = '<iframe class="metaframe rptss" src="(.*?)"'
        stream_match_string = 'file: \'(.*?)\''

        # Get Player
        req = m7lib.Common.open_url(url)
        player_url = m7lib.Common.find_single_match(req, player_match_string, 1)

        # Get Stream
        req = m7lib.Common.open_url(player_url)
        stream = m7lib.Common.find_single_match(req, stream_match_string)

        if 'mp4' in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_oops(common.addonname)
    # End Pokemon Fire #

    # Begin YouTube Channels #
    @staticmethod
    def get_youtube_channel_modes():
        youtube_channels = []
        url = common.TVTime().BASE + "/menus/youtube_channels" + base64.b64decode("LnBocA==") + "?key=" + common.TVTime().access_key
        channels = m7lib.Common.open_url(url)

        channels_list = json.loads(channels)["results"]
        for channel in channels_list:
            youtube_channels.append(channel["mode"])
        return youtube_channels

    @staticmethod
    def get_youtube_channels():
        url = common.TVTime().BASE + "/menus/youtube_channels" + base64.b64decode("LnBocA==") + "?key=" + common.TVTime().access_key
        channels = m7lib.Common.open_url(url)

        channels_list = json.loads(channels)
        return channels_list

    @staticmethod
    def build_youtube_main(mode):
        url = common.TVTime().BASE + "/ytpowered/v1/get_playlists" + base64.b64decode('LnBocA==') + "?mode=" + mode

        content = m7lib.Common.open_url(url)

        playlists = []
        results = json.loads(content)['results']
        for i in results:
            if "Trailer" not in i['title'] and \
                    "My Top Videos" not in i['title'] and \
                    "420 STONER MOVIES" not in i['title'] and \
                    "TRAILER" not in i['title'] and \
                    "Indie Scene" not in i['title'] and \
                    "TERRIFYING THURSDAYS" not in i['title'] and \
                    "For Rent" not in i['title'] and \
                    "Buzz Extras" not in i['title'] and \
                    "After Dark Double Features" not in i['title'] and \
                    "Geek Week" not in i['title'] and \
                    "Maverick On The Oscars" not in i['title'] and \
                    "for Rent" not in i['title'] and \
                    "Meet The Actors" not in i['title'] and \
                    "Weekly Updates" not in i['title'] and \
                    "Teasers" not in i['title'] and "2012 MAVERICK RELEASES" not in i['title']:
                playlists.append({
                    'channel': i['title'],
                    'title': i['title'],
                    'playlist_id': i['playlist_id'],
                    'img': i['img']
                })
        return playlists

    @staticmethod
    def get_youtube_streams(playlist_id):
        url = common.TVTime().BASE + "/ytpowered/v1/get_streams" + base64.b64decode('LnBocA==') + "?id=" + playlist_id

        content = m7lib.Common.open_url(url)

        streams = []
        results = json.loads(content)['results']
        for i in results:
            if "Movie Trailer" not in i['title'] and \
                    "trailer" not in i['title'] and \
                    "trailer" not in i['title'] and \
                    "Trailer" not in i['title'] and \
                    "Coming Soon" not in i['title'] and \
                    "Coming soon" not in i['title'] and \
                    "coming Soon" not in i['title'] and \
                    "Watch Maverick Movies" not in i['title']:
                title = i['title']
                streams.append({
                    'channel': i['title'],
                    'title': title,
                    'videoId': i['id'],
                    'img': i['img']
                })

        return streams

    def show_youtube_streams(self, title, playlist_id, mode):
        if title in mode:
            streams = self.get_youtube_streams(playlist_id)
            if streams:
                for c in streams:
                    title = c['title']
                    videoId = c['videoId']
                    img = c['img']
                    m7lib.Common().add_channel(videoId + "play-youtube", img, common.FANART, title.encode("utf8"), live=False)

    @staticmethod
    def play_youtube(id):
        stream_url = m7lib.Common.get_playable_youtube_url(id)
        m7lib.Common.play(stream_url)
    # End YouTube Channels #

    # Begin Tubi TV #
    @staticmethod
    def tubitv_main():
        m7lib.Common.add_section("tubitv-search", common.ICON, common.FANART, "Search Tubi")
        cat_list = m7lib.Stream.get_tubi_tv_categories()
        for category in cat_list:
            if category["icon"] == "none":
                icon = common.ICON
            else:
                icon = category["icon"]
            m7lib.Common.add_section(category["id"] + "tubitv-content", icon, common.FANART, category["title"])

    @staticmethod
    def tubitv_content(mode):
        category = mode.split('tubitv-content')[0]
        content_list = m7lib.Stream.get_tubi_tv_content(category)
        for entry in content_list:
            if entry["type"] == "v":
                m7lib.Common.add_channel(entry["id"] + "play-tubitv", entry["icon"], common.FANART, entry["title"], live=False)

            elif entry["type"] == "s":
                m7lib.Common.add_section(entry["id"] + "tubitv-episodes", entry["icon"], common.FANART, entry["title"])

    @staticmethod
    def tubitv_episodes(mode):
        show = mode.split('tubitv-episodes')[0]
        episode_list = m7lib.Stream.get_tubi_tv_episodes(show)
        for entry in episode_list:
            m7lib.Common.add_channel(entry["id"] + "play-tubitv", entry["icon"], common.FANART, entry["title"], live=False)

    @staticmethod
    def search_tubitv():
        retval = common.dlg.input(common.get_string(90001), type=xbmcgui.INPUT_ALPHANUM)
        if retval and len(retval) > 0:
            search_list = m7lib.Stream.get_tubi_tv_search(retval)
            if len(search_list) > 1:
                for entry in search_list:
                    if entry["type"] == "v":
                        m7lib.Common.add_channel(entry["id"] + "play-tubitv", entry["icon"], common.FANART, entry["title"],
                                                 live=False)

                    elif entry["type"] == "s":
                        m7lib.Common.add_section(entry["id"] + "tubitv-episodes", entry["icon"], common.FANART, entry["title"])
            else:
                common.dlg.ok(common.addonname, common.get_string(90002))
                exit()
        else:
            common.dlg.ok(common.addonname, common.get_string(90003))
            exit()


    @staticmethod
    def play_tubitv(mode):
        stream_id = mode.split('play-tubitv')[0]
        stream = m7lib.Stream.get_tubi_tv_stream(stream_id)
        m7lib.Common.play(stream)
    # End Tubi TV #

    # Begin Animal TV #
    @staticmethod
    def get_animal_tv_streams():
        stream_list = m7lib.Stream.get_explore_org_streams()
        for stream in sorted(stream_list, key=lambda k: k['title']):
            m7lib.Common.add_channel(stream["id"] + "play-animaltv", stream["icon"], stream["fanart"], stream["title"])
    # End Animal TV #

    # Begin OpenLoad Movies #
    @staticmethod
    def get_open_load_main():
        if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))):
            channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))
        else:
            channel_logo = common.ICON
        m7lib.Common.add_section("popular_apollo-json", channel_logo, common.FANART, "Most Popular")
        m7lib.Common.add_section("trending_apollo-json", channel_logo, common.FANART, "Trending")
        m7lib.Common.add_section("box_apollo-json", channel_logo, common.FANART, "Box Office")
        m7lib.Common.add_section("oscars_apollo-json", channel_logo, common.FANART, "Oscar Winners")
        m7lib.Common.add_section("theaters_apollo-json", channel_logo, common.FANART, "In Theaters")
        m7lib.Common.add_section("search_openload", channel_logo, common.FANART, "Search")

    @staticmethod
    def get_apollo_json(mode):
        list = mode.split('_')[0]
        url = common.TVTime().OPL_BASE_JSON + "list/movie/" + list + ".json"
        open_url = m7lib.Common.open_url(url)
        json_results = json.loads(open_url)['result']
        for i in json_results:
            m7lib.Common.add_channel(i["imdb"] + "play-apollo", i["poster"], i["fanart"], i["title"], live=False)

    @staticmethod
    def search_openload():
        if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))):
            channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))
        else:
            channel_logo = common.ICON
        search = common.dlg.input('Search OpenLoad', type=xbmcgui.INPUT_ALPHANUM)
        if len(search) != 0:
            embed = m7lib.Common.open_url(common.TVTime().OPL_BASE_TITLE + str(search))
            url = m7lib.Common.rebase(m7lib.Common.find_single_match(embed, 'id="odbIframe" src="(.+?)"'))
            if len(url.replace("?rebase=on", "")) != 0:
                common.dlg.notification(common.addonname, common.get_string(100006), channel_logo, 10000, False)
                stream = urlresolver.resolve(url)
                m7lib.Common.play(stream, xbmc_player=True)
                exit()
            else:
                common.dlg.ok(common.addonname, common.get_string(100002))
                exit()
        else:
            common.dlg.ok(common.addonname, common.get_string(100003))
            exit()

    @staticmethod
    def play_openload(mode):
        if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))):
            channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))
        else:
            channel_logo = common.ICON
        imdb = mode.split('play-apollo')[0]
        openload_link = m7lib.Common.open_url(common.TVTime().OPL_BASE_IMDB + imdb)
        url = m7lib.Common.rebase(m7lib.Common.find_single_match(openload_link, 'id="odbIframe" src="(.+?)"'))
        if len(url.replace("?rebase=on", "")) != 0:
            common.dlg.notification(common.addonname, common.get_string(100006), channel_logo, 10000, False)
            stream = urlresolver.resolve(url)
            m7lib.Common.play(stream)
    # End OpenLoad Movies #

    # Begin Free Live TV (Extra) #
    @staticmethod
    def get_free_live_tv_sections():
        # Generate Section List
        for section in sorted(m7lib.Common.get_sections(), reverse=False):
            m7lib.Common.add_section(section, m7lib.Common.get_logo(section, "section"), common.FANART)

    @staticmethod
    def get_free_live_tv_all():
        if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/free_live_tv.png'))):
            channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/free_live_tv.png'))
        else:
            channel_logo = common.ICON

        common.dlg.notification(common.addonname, common.get_string(100007), channel_logo, False, False)

        channel_list = []

        m7lib_channels = m7lib.Common.get_channels()

        # Get channels from m7lib
        for channel in m7lib_channels:
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "m7lib"})

        # Add extra channels
        for channel in Channel().free_live_tv_extra_channels:
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "extra"})

        # Add ustvgo channels
        for channel in Channel().get_ustvgo_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "ustvgo"})

        # Add guide 66 channels
        for channel in Channel().get_guide66_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "guide66"})

        # Add easyview channels
        for channel in Channel().get_easyview_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "easyview"})

        # Build channel list
        for channel in sorted(channel_list):
            channel_logo = Channel().get_channel_logo(channel["name"])
            if channel["source"] == "extra":
                m7lib.Common.add_channel(channel["name"], channel_logo, common.FANART)
            elif channel["source"] == "ustvgo" or channel["source"] == "guide66":
                m7lib.Common.add_channel(channel["url"] + "play-ustvgo", channel_logo, common.FANART, channel["name"])
            elif channel["source"] == "easyview":
                m7lib.Common.add_channel(channel["url"] + "play-easyview", channel_logo, common.FANART, channel["name"])
            else:
                channel_logo = m7lib.Common.get_logo(channel["name"])
                m7lib.Common.add_channel(channel["name"] + "play-m7lib", channel_logo, common.FANART, channel["name"])

    @staticmethod
    def get_free_live_tv_genres():
        # Generate Genre List
        genres = Channel().get_genres()
        for genre in sorted(genres, reverse=False):
            if genre == "Network TV" or genre == "Misc":
                logo = xbmc.translatePath(os.path.join(common.GENRE_PATH + '/' + genre + '.png'))
            else:
                logo = m7lib.Common.get_logo(genre, "genre")
            m7lib.Common.add_section(genre, logo, common.FANART)

    @staticmethod
    def get_free_live_tv_by_genre(mode):
        if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/free_live_tv.png'))):
            channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/free_live_tv.png'))
        else:
            channel_logo = common.ICON

        common.dlg.notification(common.addonname, common.get_string(100007), channel_logo, False, False)

        channel_list = []

        m7lib_channels = m7lib.Common.get_channels()

        # Get channels from m7lib
        for channel in m7lib_channels:
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "m7lib"})

        # Add extra channels
        for channel in Channel().free_live_tv_extra_channels:
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "extra"})

        # Add ustvgo channels
        for channel in Channel().get_ustvgo_channels():
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "ustvgo"})

        # Add guide 66 channels
        for channel in Channel().get_guide66_channels():
            if mode == channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "guide66"})

        # # Add easyview channels
        for channel in Channel().get_easyview_channels():
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "easyview"})

        # Build channel list within given genre
        for channel in sorted(channel_list):
            channel_logo = Channel().get_channel_logo(channel["name"])
            if channel["source"] == "extra":
                m7lib.Common.add_channel(channel["name"], channel_logo, common.FANART)
            elif channel["source"] == "ustvgo" or channel["source"] == "guide66":
                m7lib.Common.add_channel(channel["url"] + "play-ustvgo", channel_logo, common.FANART, channel["name"])
            elif channel["source"] == "easyview":
                m7lib.Common.add_channel(channel["url"] + "play-easyview", channel_logo, common.FANART, channel["name"])
            else:
                channel_logo = m7lib.Common.get_logo(channel["name"])
                m7lib.Common.add_channel(channel["name"] + "play-m7lib", channel_logo, common.FANART, channel["name"])
    # End Free Live TV (Extra) #

    # Begin Xumo TV & Movies #
    @staticmethod
    def get_xumo_main():
        req = m7lib.Common().open_url(Channel().XUMO_BASE_API%"channels/list/10006.json?q=genreid:195")
        stations_json = json.loads(req)
        stations = stations_json["channel"]["item"]

        for i in sorted(stations, key=lambda k: k['title']):
            logo = Channel().XUMO_BASE_LOGO % (i["guid"]["value"])
            if i["title"] != "Docurama":
                m7lib.Common.add_section(i["title"] + "-xumo-channel" + i["guid"]["value"], logo, common.FANART, i["title"])
            else:
                m7lib.Common.add_channel("xumo-streamXM0CHNSP1IRFM6", logo, common.FANART, i["title"])

    @staticmethod
    def get_xumo_channel(mode):
        channel_id = mode.split('xumo-channel', 1)[-1]
        req = m7lib.Common().open_url(Channel().XUMO_BASE_API%"channels/channel/%s/categories.json" % channel_id)
        categories_json = json.loads(req)
        categories = categories_json["categories"]

        for i in sorted(categories, key=lambda k: k['title']):
            title = i["title"].replace("&", "and")
            if ":" not in title:
                cat_id = i["categoryId"]
                logo = Channel().XUMO_BASE_LOGO % channel_id
                m7lib.Common.add_section(channel_id + "-xumo-category" + cat_id, logo, common.FANART, title.encode("utf8"))

    @staticmethod
    def get_xumo_category(mode):
        cat_id = mode.split('-xumo-category', 1)[-1]
        channel_id = mode.split('-')[0]
        req = m7lib.Common().open_url(Channel().XUMO_BASE_API%"categories/category/%s.json?f=asset.title&f=asset.episodeTitle" % cat_id)

        movies_json = json.loads(req)
        movies = movies_json["results"]

        # Create Xumo cache directory #
        xumo_path = xbmc.translatePath('special://home/userdata/addon_data/' + common.addonid + '/xumo/')
        if not os.path.exists(xumo_path):
            os.mkdir(xumo_path)

        # Clean Xumo cache if cache is older than 30 days #
        if common.get_setting('xumo_cache') != "0":
            if datetime(*(time.strptime(common.get_setting('xumo_cache'), "%Y-%m-%d %H:%M:%S.%f")[0:6])) < datetime.now():
                common.set_setting('xumo_cache', "0")
                if os.path.exists(xumo_path):
                    for root, dirs, files in os.walk(xumo_path):
                        for currentFile in files:
                            os.remove(os.path.join(root, currentFile))

        # Xumo cache progress #
        progress = [1]
        progress_heading = common.get_string(100008)
        progress_message = common.get_string(100009)

        for i in sorted(movies, key=lambda k: k['title']):
            logo_cache_path = xumo_path + i['id'] + '.jpg'
            if common.exists_local(logo_cache_path):
                if common.is_non_zero_file(logo_cache_path):
                    logo = logo_cache_path
                else:
                    logo = Channel().XUMO_BASE_LOGO % channel_id
            else:
                # Set Xumo cache date #
                if common.get_setting('xumo_cache') == "0":
                    common.set_setting('xumo_cache', str(datetime.now() + timedelta(days=30)))

                # Create Xumo progress bar #
                common.dlg_progress.create(progress_heading)

                # If Xumo progress dialog is canceled exit #
                if common.dlg_progress.iscanceled():
                    exit()
                urllib.urlretrieve(Channel().XUMO_BASE_THUMB % i["id"], logo_cache_path)

                # Increment progress bar #
                progress.append(1)

                if common.exists_local(logo_cache_path):
                    if common.is_non_zero_file(logo_cache_path):
                        logo = logo_cache_path
                    else:
                        logo = Channel().XUMO_BASE_LOGO % channel_id
                else:
                    logo = Channel().XUMO_BASE_LOGO % channel_id

                # Update Xumo progress bar #
                common.dlg_progress.update(int(len(progress) * (100 / len(movies))), progress_message, " ", "Images cached: [COLOR lightskyblue]" +
                                           str(len(progress) - 1) + "[/COLOR] of [COLOR lightskyblue]" + str(len(movies)) + "[/COLOR]")

            m7lib.Common.add_channel("xumo-stream" + i["id"], logo, common.FANART, i["title"].encode("utf8"), live=False)

    @staticmethod
    def play_xumo(mode):
        stream_id = mode.split('xumo-stream', 1)[-1]
        req = m7lib.Common().open_url(Channel().XUMO_BASE_API%"/assets/asset/%s.json?f=title&f=providers" % stream_id)

        stream_json = json.loads(req)
        stream = m7lib.Common.rebase(stream_json["providers"][0]["sources"][0]["uri"])
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_oops(common.addonname)
    # End Xumo TV & Movies #


