'''
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import Addon, tvtime
import sys, re, os, urllib, urllib2
from urllib2 import urlopen
import json, base64
import requests
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

import urlparse

from bs4 import BeautifulSoup
import jsbeautifier.unpackers.packer as packer

from datetime import date
from datetime import time
from datetime import datetime

from resources.modules import net
net = net.Net()

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')

Addon.plugin_url = sys.argv[0]
Addon.plugin_handle = int(sys.argv[1])
Addon.plugin_queries = Addon.parse_query(sys.argv[2][1:])

dlg = xbmcgui.Dialog()

addon_logo = xbmc.translatePath(os.path.join(plugin_path,'icon.png'))

mode = Addon.plugin_queries['mode']

quality = int(Addon.get_setting('quality'))

movies_view_option = int(Addon.get_setting('movies_view'))
if movies_view_option == "":
    movies_view = 50
else:
    movies_view = movies_view_option

access_key = str(Addon.get_setting('access_key'))

key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})['status']

if key_check == 'offline':
    dlg.ok(Addon.get_string(5000), Addon.get_string(90000))
    exit()

if key_check != 'success':
    # Enter Access Key
    retval = dlg.input(Addon.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if retval and len(retval) > 0:
        Addon.set_setting('access_key', str(retval))
        access_key = Addon.get_setting('access_key')
        key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})['status']
    if len(Addon.get_setting('access_key')) > 0 and key_check == 'success':
        dlg.ok(Addon.get_string(5000), Addon.get_string(70000))
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(80000))
        exit()

##Begin Stuff for ArconaiTV##
addon_handle = int(sys.argv[1])
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36'

def duf(d,e,f):
	g = list("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/")
	h = g[0:e]
	i = g[0:f]
	d = list(d)[::-1]
	j = 0
	for c,b in enumerate(d):
		if b in h:
			j = j + h.index(b)*e**c

	k = ""
	while j > 0:
		k = i[j%f] + k
		j = (j - (j%f))//f

	return int(k) or 0

def hunter(h,u,n,t,e,r):
	r = "";
	i = 0
	while i < len(h):
		j = 0
		s = ""
		while h[i] is not n[e]:
			s = ''.join([s,h[i]])
			i = i + 1

		while  j < len(n):
			s = s.replace(n[j],str(j))
			j = j + 1

		r = ''.join([r,''.join(map(chr, [duf(s,e,10) - t]))])
		i = i + 1
	return r
##End Stuff for ArconaiTV##

##Begin Live News##

def livenews_stream(url,name):
    if Addon.get_setting('cnn_alternate') == "true" and len(Addon.get_setting('cnn_id')) > 0 and name == "CNN":
        source = xbmcgui.Dialog().select(Addon.get_string(90007), [Addon.get_string(90011),Addon.get_string(90012)])
        if source == 0:
            link = url
        if source == 1:
            link = "https://www.youtube.com/watch?v=" + Addon.get_setting('cnn_id')
        if source < 0:
            exit()
    elif Addon.get_setting('foxnews_alternate') == "true" and len(Addon.get_setting('foxnews_id')) > 0 and name == "Fox News":
        source = xbmcgui.Dialog().select(Addon.get_string(90007), [Addon.get_string(90011),Addon.get_string(90012)])
        if source == 0:
            link = url
        if source == 1:
            link = "https://www.youtube.com/watch?v=" + Addon.get_setting('foxnews_id')
        if source < 0:
            exit()
    elif Addon.get_setting('skynews_alternate') == "true" and len(Addon.get_setting('skynews_id')) > 0 and name == "Sky News":
        source = xbmcgui.Dialog().select(Addon.get_string(90007), [Addon.get_string(90011),Addon.get_string(90012)])
        if source == 0:
            link = url
        if source == 1:
            link = "https://www.youtube.com/watch?v=" + Addon.get_setting('skynews_id')
        if source < 0:
            exit()
    elif Addon.get_setting('aljazeera_alternate') == "true" and len(Addon.get_setting('aljazeera_id')) > 0 and name == "Aljazeera":
        source = xbmcgui.Dialog().select(Addon.get_string(90007), [Addon.get_string(90011),Addon.get_string(90012)])
        if source == 0:
            link = url
        if source == 1:
            link = "https://www.youtube.com/watch?v=" + Addon.get_setting('aljazeera_id')
        if source < 0:
            exit()

    elif Addon.get_setting('bloomberg_alternate') == "true" and len(Addon.get_setting('bloomberg_id')) > 0 and name == "Bloomberg Global News":
        source = xbmcgui.Dialog().select(Addon.get_string(90007), [Addon.get_string(90011),Addon.get_string(90012)])
        if source == 0:
            link = url
        if source == 1:
            link = "https://www.youtube.com/watch?v=" + Addon.get_setting('bloomberg_id')
        if source < 0:
            exit()
    else:
        link = url

    stream = Addon.youtube_resolve(link)
    item = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
##End Live News##

##Begin unblocked.lol Sports and Proxy Portal##
def unblocked_proxy_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<source src="(.*?)"')
    
    Addon.play(url)
##End unblocked.lol Sports and Proxy Portal##

##Begin unblocked.lol Sports##
def unblockedsports_main():
    url = 'http://unblocked.lol'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="col-sm-2 text-center">(.*?)</div>')

    Addon.addLink_live("[COLOR blue]Barclays Premier League[/COLOR]","","http://unblocked.lol/unblocked/sportsphp/barclayspremierleague.php",99,xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'sports.jpg')))
    Addon.addLink_live("[COLOR blue]UEFA Champions League[/COLOR]","","http://unblocked.lol/unblocked/sportsphp/uefachampionsleague.php",99,xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'sports.jpg')))
    
    for entry in sorted(matches, reverse=False):
        name = Addon.find_single_match(entry,'role=button>(.+?)</a>')
        description = ""
        url = Addon.find_single_match(entry,'<a class="btn btn-secondary btn-block spa" href=(.+?) target')
        iconimage  = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'sports.jpg'))
        if len(name) > 0 and "http" in url:
            Addon.addLink_live(name,description,url,99,iconimage)
##End unblocked.lol Sports##

##Begin Proxy Portal##
def proxyportal_main():
    url = 'https://live.proxyportal.net'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="panel-body">(.*?)</div>')
    
    for entry in sorted(matches, reverse=False):
        name = Addon.find_single_match(entry,'spa">(.+?)!</a>')
        description = ""
        url = 'https://live.proxyportal.net' + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage  = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'proxyportal_main_2.jpg'))
        if len(name) > 0:
            Addon.addLink_live(name,description,url,99,iconimage)
##End Proxy Portal##

##Begin SundanceTV##
def sundancetv_main():
    url = 'http://www.sundance.tv/watch-now/'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="listings">(.*?)</a><!--//episode--> ')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'<div class="show-title tablet-only">(.+?)</div>').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http://www.sundance.tv" + Addon.find_single_match(entry,'<a class="episode" href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'<img src="(.+?)"')
        Addon.addDir(name,description,url,16,iconimage)

    Addon.addDir('Movies','','http://www.sundance.tv/watch-now/movies',18,'http://media.sundance.tv/assets/tve/thumbnails/films/movies_poster.jpg?rand=' + Addon.random_generator())

def sundancetv_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<a class="video-link related-triple"(.*?)class="play-link">')

    for entry in matches:
        name = Addon.find_single_match(entry,'<h4 class="video-title">(.+?)</h4>').replace("&amp;", "&").replace("&#39;", "'")
        time = Addon.find_single_match(entry,'<p class="video-detail">(.+?)</p>').strip()
        description = Addon.find_single_match(entry,'<p class="video-description">(.+?)</p>') + " - " + time
        url = "http://www.sundance.tv" + Addon.find_single_match(entry,'href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'src="(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,17,iconimage)

def sundancetv_movies(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response  = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<a class="episode"(.*?)<!--//episode--> ')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'<div class="title">(.+?)</div>').replace("&amp;", "&").replace("&#39;", "'").strip()
        description = Addon.find_single_match(entry,' <div class="expires">(.+?)</div>').strip()
        url = "http://www.sundance.tv/watch-now/movie/" + Addon.find_single_match(entry,'href="(.+?)"')
        iconimage = addon_logo
        if "http" in url:
            Addon.addLink(name,description,url,19,iconimage)

def sundancetv_stream(url):
    vid = url.split('/',6)[-2]

    url = 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=' + vid + '&pubId=3605490453001'
    
    Addon.play(url)

def sundancetv_stream_movie(url):
    vid = url.split('/',9)[-2]

    url = 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=' + vid + '&pubId=3605490453001'
    
    Addon.play(url)
##End SundanceTV##

##Begin HGTV##
def hgtv_main():
    url = 'http://www.hgtv.com/shows/full-episodes/'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</h4>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http:" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry,'data-src="(.+?)"')
        videos = Addon.find_single_match(entry,'<span class="m-MediaBlock__a-AssetInfo">(.+?) Videos</span>')
        if videos != "0":
            Addon.addDir(name,description,url,6,iconimage)

def hgtv_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'"id" : "(.*?)},')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url  = Addon.find_single_match(entry,'"releaseUrl" : "(.+?)"')
        iconimage  = "http://hgtv.com/" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,7,iconimage)

def hgtv_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<video src="(.*?)"')
    
    Addon.play(url)
##End HGTV##

##Begin Travel Channel##
def travel_main():
    url = 'http://www.travelchannel.com/video/full-episodes'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</h4>')
    blacklist = requests.get(base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvdXN0dmNhdGNodXAvYmxhY2tsaXN0LnBocA==')).json()

    featured_name = Addon.find_single_match(link,'<span class="m-Header__a-HeadlineText">(.+?)</span>').replace("Catch Up Now: ", "")
    featured_icon = "http:" + Addon.find_single_match(link,'<img width="196" alt="" title="" src="(.+?)"')
    Addon.addDir(featured_name,"",url,8,featured_icon)
    
    for entry in matches:
        name = Addon.find_single_match(entry,'title="(.+?)"').replace("&amp;", "&")
        description=""
        url = "http:" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry,'data-src="(.+?)"').replace("http://cook.home.sndimg.com", "http://travel.home.sndimg.com")
        videos = Addon.find_single_match(entry,'<span class="m-MediaBlock__a-AssetInfo">(.+?) Videos</span>')
        if not any(x == name for x in blacklist) and videos != "0":
            Addon.addDir(name,description,url,8,iconimage)

def travel_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'"id" : "(.*?)},')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry,'"releaseUrl" : "(.+?)"')
        iconimage  = "http://travelchannel.com/" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,9,iconimage)

def travel_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<video src="(.*?)"')
    
    Addon.play(url)
##End Travel Channel##

##Begin DIY Network##
def diy_main():
    url = 'http://www.diynetwork.com/shows/full-episodes'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    matches = Addon.find_multiple_matches(link,'<html >(.*?)</html>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'<h3 class="m-Header__a-Headline"><span class="m-Header__a-HeadlineText">Catch Up Now: (.+?)</span></h3>').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "null"
        iconimage = "http://diynetwork.com/" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')

        Addon.addDir(name,description,url,10,iconimage)
    matches = Addon.find_multiple_matches(link,'<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</h4>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http:" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry,'data-src="(.+?)"')
        videos = Addon.find_single_match(entry,'<span class="m-MediaBlock__a-AssetInfo">(.+?) Videos</span>')
        if videos != "0":
            Addon.addDir(name,description,url,10,iconimage)

def diy_episodes(url):
    if url == "null":
        url = "http://www.diynetwork.com/shows/full-episodes"
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'"id" : "(.*?)},')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry,'"releaseUrl" : "(.+?)"')
        iconimage  = "http://diynetwork.com/" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,11,iconimage)

def diy_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<video src="(.*?)"')
    
    Addon.play(url)
##End DIY Network##

##Begin Cooking Channel##
def cooking_main():
    url = 'http://www.cookingchanneltv.com/videos/players/full-episodes-player'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    matches = Addon.find_multiple_matches(link,'<html >(.*?)</html>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'<span class="m-Header__a-HeadlineText">(.+?)</span>').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "null"
        iconimage = "http://cookingchanneltv.com/" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')

        Addon.addDir(name,description,url,12,iconimage)

    matches = Addon.find_multiple_matches(link,'data-module="editorial-promo">(.*?)</div>')
    blacklist = requests.get(base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvdXN0dmNhdGNodXAvYmxhY2tsaXN0LnBocA==')).json()

    for entry in matches:
        name = Addon.find_single_match(entry,'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http:" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry,'data-src="(.+?)"')
        if not any(x == name for x in blacklist):
            Addon.addDir(name,description,url,12,iconimage)

def cooking_episodes(url):
    if url == "null":
        url = "http://www.cookingchanneltv.com/videos/players/full-episodes-player"
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'"id" : "(.*?)},')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry,'"releaseUrl" : "(.+?)"')
        iconimage = "http://cookingchanneltv.com/" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,13,iconimage)

def cooking_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<video src="(.*?)"')
    
    Addon.play(url)
##End Cooking Channel##

##Begin Food Network##
def food_main():
    url = 'http://www.foodnetwork.com/videos/full-episodes'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    matches = Addon.find_multiple_matches(link,'<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</div>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http:" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry,'data-src="(.+?)"')
        Addon.addDir(name,description,url,14,iconimage)

def food_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'"id" : "(.*?)},')
    
    for entry in matches:      
        name = Addon.find_single_match(entry,'"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry,'"releaseUrl" : "(.+?)"')
        iconimage  = "http://foodnetwork.com/" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')
        if "http" in url:
            Addon.addLink(name,description,url,15,iconimage)

def food_stream(url):
    req  = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<video src="(.*?)"')
    
    Addon.play(url)
##End Cooking Channel##

##Begin Smithsonian Channel##
def smith_main():
    url = 'http://www.smithsonianchannel.com/full-episodes'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<li class="mix free" data-premium="false">(.*?)</li>')
    
    for entry in matches:
        name = Addon.find_single_match(entry,'<h3 class="promo-series-name">(.+?)</h3>').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'<h2 class="promo-show-name">(.+?)</h2>').replace("&amp;", "&").replace("&#39;", "'")
        url = "http://www.smithsonianchannel.com/" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage  = "http:" + Addon.find_single_match(entry,'<source srcset="(.+?)"')
        if len(name) > 0 and "http" in url:
            Addon.addLink(name,description,url,20,iconimage)

def smith_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<meta name="twitter:player:stream" content="(.*?)"')
    
    Addon.play(url)
##End Smithsonian Channel##

##Begin Freeform##
def freeform_main():
    Addon.addDir('Movies','','http://freeform.go.com/movies',23,xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'ustvcatchup', 'freeform_movies.png')))
    url = 'http://freeform.go.com/shows'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="col-xs-4 shows-grid">(.*?)/h5>')
    blacklist = requests.get(base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvdXN0dmNhdGNodXAvYmxhY2tsaXN0LnBocA==')).json()
    for entry in matches:
        name = Addon.find_single_match(entry,'<h3>(.+?)</h3>').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        coming_soon = Addon.find_single_match(entry,'<h5>(.+?)<').lower()
        url = "http://freeform.go.com" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'<img src="(.+?)"')
        if not any(x in name for x in blacklist) and "http" in url and " coming " not in coming_soon:
            Addon.addDir(name,description,url,21,iconimage)

def freeform_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<hr />(.*?)Watch Now <i class="fa fa-play"></i>')

    if matches == []:
        matches = Addon.find_multiple_matches(link,'<div class="col-md-4(.*?)</a>')
        for entry in matches:
            name = Addon.find_single_match(entry,'<h4 class="card-title">(.+?)</h4>').replace("&amp;", "&").replace("&#39;", "'").strip()
            description = Addon.find_single_match(entry,'<span class="heavy">    <span class="heavy">(.+?)</span>').replace("<p>", "").replace("<\/p>", "").strip().replace("&#39;", "'").replace("&quot;", '"')
            url = "http://freeform.go.com" + Addon.find_single_match(entry,'<a href="(.+?)"')
            iconimage = Addon.find_single_match(entry,"background-image: url\('(.+?)'")
            lock = Addon.find_single_match(entry,'data-sign-in-padlock data-requires-sign-in="(.+?)"').strip()
            if "http" in url and lock == "False":
                Addon.addLink(name,description,url,22,iconimage)

    else:
        for entry in matches:
            name = Addon.find_single_match(entry,'<h3 class="show-title m-y-0">(.+?)</h3>').replace("&amp;", "&").replace("&#39;", "'").strip()
            description = Addon.find_single_match(entry,'<p class="m-t-1">(.+?)</p>').replace("<p>", "").replace("<\/p>", "").strip().replace("&#39;", "'").replace("&quot;", '"')
            url = "http://freeform.go.com" + Addon.find_single_match(entry,'<a href="(.+?)"')
            iconimage = Addon.find_single_match(entry,'<img src="(.+?)"')
            lock = Addon.find_single_match(entry,'data-sign-in-padlock data-requires-sign-in="(.+?)"').strip()
            if "http" in url and lock == "False":
                Addon.addLink(name,description,url,22,iconimage)

def freeform_movies(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="movies-grid col-xs-6 col-md-4 col-lg-3">(.*?)</a>')

    for entry in matches:
        name = Addon.find_single_match(entry,'<h3 class="m-b-0">(.+?)</h3>').replace("&amp;", "&").replace("&#39;", "'").strip()
        description = Addon.find_single_match(entry,'<p>(.+?)</p>').replace("<p>", "").replace("<\/p>", "").strip().replace("&#39;", "'").replace("&quot;", '"')
        url = "http://freeform.go.com" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'<img src="(.+?)"')
        lock = Addon.find_single_match(entry,'data-sign-in-padlock data-requires-sign-in="(.+?)"').strip()
        if "http" in url and lock == "False":
            Addon.addLink(name,description,url,22,iconimage)

def freeform_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    vd = Addon.find_single_match(link,"VDKA(.+?)\"")
    url = 'https://api.entitlement.watchabc.go.com/vp2/ws-secure/entitlement/2020/authorize.json'
    udata = 'video%5Fid=VDKA'+str(vd)+'&device=001&video%5Ftype=lf&brand=002'
    uheaders = Addon.defaultHeaders.copy()
    uheaders['Content-Type'] = 'application/x-www-form-urlencoded'
    uheaders['Accept'] = 'application/json'
    uheaders['X-Requested-With'] = 'ShockwaveFlash/24.0.0.194'
    uheaders['Origin'] = 'http://cdn1.edgedatg.com'
    uheaders['DNT'] = '1'
    uheaders['Referer'] = 'http://cdn1.edgedatg.com/aws/apps/datg/web-player-unity/1.0.6.13/swf/player_vod.swf'
    uheaders['Pragma'] = 'no-cache'
    uheaders['Connection'] = 'keep-alive'
    uheaders['Cache-Control'] = 'no-cache'
    html = Addon.getRequest(url, udata, uheaders)
    a = json.loads(html)
    if a.get('uplynkData', None) is None:
        return

    sessionKey = a['uplynkData']['sessionKey']
    oid = Addon.find_single_match(html,'&oid=(.+?)&')
    eid = Addon.find_single_match(html,'&eid=(.+?)&')
    url = 'http://content.uplynk.com/ext/%s/%s.m3u8?%s' % (oid, eid, sessionKey)

    Addon.play(url)
##End freeform##

##Begin ABC##
def abc_main():
    url = 'http://abc.go.com/shows'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<li  data-sm-id=""(.*?)/li>')
    blacklist = requests.get(base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvdXN0dmNhdGNodXAvYmxhY2tsaXN0LnBocA==')).json()
    for entry in matches:
        name = Addon.find_single_match(entry,'<div class="tile-show-name truncate-text">(.+?)</div>').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        path = Addon.find_single_match(entry,'<a href="(.+?)"').replace("/index", "")
        if name == "The Neighbors":
            url = "http://abc.go.com" + path + "/episode-guide/season-01"
        else:
            url = "http://abc.go.com" + path + "/episode-guide"
        iconimage = Addon.find_single_match(entry,'srcset="(.+?) ')
        if not any(x in name for x in blacklist) and "http" in url and name != "":
            Addon.addDir(name,description,url,24,iconimage)

def abc_seasons(url, name, iconimage):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<option(.*?)option>')

    season_blacklist = requests.get(base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvdXN0dmNhdGNodXAvc2Vhc29uX2JsYWNrbGlzdC5waHA=')).json()

    if matches == [] or any(x in name for x in season_blacklist):
        abc_episodes(url)
    else:

        for entry in matches:
            name = Addon.find_single_match(entry,'>(.+?)</').replace("&amp;", "&").replace("&#39;", "'").strip()
            description = ""
            path = Addon.find_single_match(entry,'value="(.+?)"').replace("/index", "")
            url = "http://abc.go.com" + path
            if len(path) > 0:
                Addon.addDir(name,description,url,25,iconimage)

def abc_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<div class="m-episode-copy medium-8 large-6 columns nogutter ">(.*?)</picture>')

    for entry in matches:
        season = Addon.find_single_match(entry,'<span class="season-number light">(.+?)</span>').replace("&amp;", "&").replace("&#39;", "'").strip()
        season = re.sub('<[^<]+?>', '', season).strip()
        episode = Addon.find_single_match(entry,'<span class="episode-number">(.+?)</a>').replace("&amp;", "&").replace("&#39;", "'").strip()
        episode = re.sub('<[^<]+?>', '', episode).strip()
        name = season + " " + episode
        description = Addon.find_single_match(entry,'<p>(.+?)</p>').replace("&amp;", "&").replace("&#39;", "'").strip()
        description = re.sub('<[^<]+?>', '', description).strip()
        path = Addon.find_single_match(entry,'<a class="dark-text" href="(.+?)">Watch</a>')
        url = "http://abc.go.com" + path
        iconimage = Addon.find_single_match(entry,'srcset="(.+?) ')
        if len(path) > 0:
            Addon.addLink(name,description,url,26,iconimage)

def abc_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    vd = Addon.find_single_match(link,"VDKA(.+?)\"")
    url = 'https://api.entitlement.watchabc.go.com/vp2/ws-secure/entitlement/2020/authorize.json'
    udata = 'video%5Fid=VDKA'+str(vd)+'&device=001&video%5Ftype=lf&brand=001'
    uheaders = Addon.defaultHeaders.copy()
    uheaders['Content-Type'] = 'application/x-www-form-urlencoded'
    uheaders['Accept'] = 'application/json'
    uheaders['X-Requested-With'] = 'ShockwaveFlash/22.0.0.209'
    uheaders['Origin'] = 'http://cdn1.edgedatg.com'
    html = Addon.getRequest(url, udata, uheaders)
    a = json.loads(html)
    if a.get('uplynkData', None) is None:
        return

    sessionKey = a['uplynkData']['sessionKey']
    if not '&cid=' in sessionKey:
        oid = Addon.find_single_match(html,'&oid=(.+?)&')
        eid = Addon.find_single_match(html,'&eid=(.+?)&')
        url = 'http://content.uplynk.com/ext/%s/%s.m3u8?%s' % (oid, eid, sessionKey)
    else:
        cid = Addon.find_single_match(html,'&cid=(.+?)&')
        url = 'http://content.uplynk.com/%s.m3u8?%s' % (cid, sessionKey)

    Addon.play(url)
##End ABC##

##Begin NBC##
def nbc_main():
    req = urllib2.Request('http://www.nbc.com/shows/all')
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    html = Addon.find_single_match(link,'<script>PRELOAD=(.*?)</script>')
    a = json.loads(html)
    a = a['allShows']
    blacklist = requests.get(base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvdXN0dmNhdGNodXAvYmxhY2tsaXN0LnBocA==')).json()
    for b in a:
        if b['tuneIn'] != 'WATCH VIDEOS' and b['tuneIn'] != 'COMING SOON' and b['tuneIn'] != 'LEARN MORE' and b['tuneIn'] != 'WATCH HIGHLIGHTS' and b['tuneIn'] != 'WATCH VIDEO' and 'SERIES PREMIERE' not in str(b['tuneIn']):
            name = b['title']
            description = ""
            url = 'http://www.nbc.com' + b['urlAlias'] + '?nbc=1'
            iconimage = b['image']['path']
            if not any(x in name for x in blacklist):
                Addon.addDir(name,description,url,27,iconimage)

def nbc_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    id = Addon.find_single_match(link,'"entities":{"(.*?)"')

    req = urllib2.Request('https://api.nbc.com/v3.13/videos?fields%5Bvideos%5D=airdate%2Cavailable%2Cdescription%2Centitlement%2Cexpiration%2Cgenre%2Cguid%2CinternalId%2Ckeywords%2Cpermalink%2CrunTime%2Ctitle%2Ctype%2CvChipRating%2CembedUrl%2CseasonNumber%2CepisodeNumber%2CdayPart%2Ccredits&fields%5Bshows%5D=category%2Ccolors%2Cdescription%2CinternalId%2Cname%2Cnavigation%2Creference%2CschemaType%2CshortDescription%2CshortTitle%2CurlAlias%2CshowTag%2Csocial%2CtuneIn%2Ctype&fields%5Bseasons%5D=seasonNumber%2CcontestantTitle&fields%5Bimages%5D=derivatives&include=image%2Cshow%2Cshow.season&derivatives=landscape.widescreen.size350.x1%2Clandscape.widescreen.size640.x1%2Clandscape.widescreen.size640.x2&filter%5Bshow%5D='+id+'&filter%5Bexpiration%5D%5Bvalue%5D=2017-07-07T23%3A00%3A00-04%3A00&filter%5Bexpiration%5D%5Boperator%5D=%3E%3D&filter%5Btype%5D%5Bvalue%5D=Full%20Episode&filter%5Btype%5D%5Boperator%5D=%3D&sort=-airdate')
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    html = response.read()
    response.close()

    a = json.loads(html)
    for b in sorted(a['data']): 
        expiration = b['attributes'].get('expiration').split('T')[0]
        try:
            expiration = datetime.strptime(expiration, "%Y-%m-%d")
        except TypeError:
            expiration = datetime.fromtimestamp(time.mktime(time.strptime(expiration, "%Y-%m-%d")))
        entitlement = b['attributes'].get('entitlement')
        url = b['attributes'].get('embedUrl')
        url = url.split('guid/',1)[1]
        url = url.split('?',1)[0]
        url = 'http://link.theplatform.com/s/NnzsPC/media/guid/%s?format=preview' % url
        html = Addon.getRequest(url)
        if html == '':
            continue
        c = json.loads(html)
        name = c['title']
        description = c.get('description') + "\nExpires: " + expiration.strftime("%m/%d/%Y")
        iconimage = c.get('defaultThumbnailUrl')
        url = 'http://link.theplatform.com/s/NnzsPC/media/'+c['mediaPid']+'?policy=43674&player=NBC.com%20Instance%20of%3A%20rational-player-production&formats=m3u,mpeg4&format=SMIL&embedded=true&tracking=true'
        if b['attributes'].get('type') == "Full Episode" and entitlement == "free" and expiration.date() > date.today():
            Addon.addLink(str(name),description,url,28,iconimage)

def nbc_stream(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()

    url = Addon.find_single_match(link,'<video src="(.*?)"')
    
    Addon.play(url)
##End NBC##

##Begin PBS##
def pbs_main():
    req = urllib2.Request('http://pbskids.org/pbsk/video/api/getShows/?callback=&destination=national&return=images')
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    html = link.strip('()')
    a = json.loads(html)
    a = a.get('items')
    for b in a:
        name = b.get('title').strip()
        url = 'http://pbskids.org/pbsk/video/api/getVideos/?startindex=1&endindex=200&program=%s&type=episode&category=&group=&selectedID=&status=available&player=flash&flash=true' % (urllib.quote(name.encode('utf-8')))
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        count = json.loads(link)
        count = count.get('items')
        iconimage = b.get('images',{'x':None})
        if iconimage == []:
            continue
        iconimage = iconimage.get('program-kids-square',{'x':None}).get('url', addon_logo)
        description = b.get('description')
        if count != []:
            Addon.addDir(str(name),str(description),str(url),29,str(iconimage))

def pbs_episodes(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    a = json.loads(link)
    a = a.get('items')
    for b in a:
        url = b.get('videos',{'x':None}).get('flash',{'x':None})
        url = url.get('mp4-2500k',url.get('mp4-1200k',url)).get('url')
        if not url is None:
            name = b.get('title').strip()
            iconimage  = b.get('images',{'x':None}).get('kids-mezzannine-16x9',{'x':None}).get('url', addon_logo)
            description = b.get('description')
            Addon.addLink(str(name),str(description),str(url),30,str(iconimage))

def pbs_stream(url):
      html = Addon.getRequest('%s?format=json' % url)
      a = json.loads(html)
      url = a.get('url')
      if url is not None:
          url = url.split(':videos/',1)
          if len(url) > 1:
              url = 'http://kids.video.cdn.pbs.org/videos/%s' % url[1]
              Addon.play(url)
##End PBS##

##Begin TVCatchup.com##
def tvcatchup_main():
    url = 'https://tvcatchup.com/'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = Addon.find_multiple_matches(link,'<p class="channelsicon" style.+?>(.*?)</div>')
    
    for entry in matches:
        getchannel = Addon.find_single_match(entry,'alt="Watch (.+?)"')
        gettitle = Addon.find_single_match(entry,'<br/> (.+?) </a>').replace("&#039;","'").replace("&amp;","&")
        name = getchannel+' - '+gettitle
        description = ""
        geturl = Addon.find_single_match(entry,'<a href="(.+?)"')
        url = 'http://tvcatchup.com' + geturl
        iconimage = Addon.find_single_match(entry,'src="(.+?)"')

        Addon.addLink_live(name,description,url,5,iconimage)

def tvcatchup_extra():
    tvcatchup_menu = tvtime.TVtime()._get_json('/tvcatchup/v1/get_channels' + base64.b64decode('LnBocA=='), {'key': access_key})
    tvcatchup_menu_results = tvcatchup_menu['results'];
    for i in tvcatchup_menu_results: 
        if i['status'] == 'on':
            Addon.addLink_live(i['channel'],'','http://www.tvcatchup.com/watch/' + i['id'],5,i['img'])

def tvcatchup(url):
    link  = Addon.open_url(url)
    link  = link
    match = re.compile('<source src="(.+?)" type="application/x-mpegURL">').findall(link)
    for url in match:
	Addon.play(url)
##End TVCatchup.com##

if mode == 'main':
    tvguide_installed = False
    try:
        xbmcaddon.Addon("script.ftvguide.custom")
        tvguide_installed = True
    except Exception:
        pass  # ignore addons that are not installed

    if tvguide_installed == True:
        Addon.add_directory({'mode': 'tvguide'}, 'TV Guide (USTVnow)', img = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'epg.jpg')))

    main_menu = tvtime.TVtime()._get_json('/menus/main' + base64.b64decode('LnBocA=='), {'key': access_key})
    main_menu_results = main_menu['results'];
    for i in main_menu_results: 
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['mode']+'_2.jpg')))
    if len(Addon.get_setting('notify')) > 0:
        Addon.set_setting('notify', str(int(Addon.get_setting('notify')) + 1))  
    else:
        Addon.set_setting('notify', "1")        
    if int(Addon.get_setting('notify')) == 1:
        xbmcgui.Dialog().notification('Like ' + addonname + ' Private?','Keep it Private!',addon_logo,5000,False)
    elif int(Addon.get_setting('notify')) == 9:
        Addon.set_setting('notify', "0")
    
if mode == 'ustvnow':
    channels = tvtime.TVtime().get_channels(quality)
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel'];
            rURL = "plugin://plugin.video.tvtime.private/?channel=" + channel + "&mode=play&rand=" + Addon.random_generator()
            if channel == 'BBCA':
                channel = 'BBC America'
            if channel == 'ESPN2':
                channel = 'ESPN 2'
            if channel == 'NBCSNHD':
                channel = 'NBCSN'
            if channel == 'The Learning Channel':
                channel = 'TLC'
            if channel == 'Universal HD':
               channel = 'Universal'
            if channel == 'USA Network':
                channel = 'USA'
            logo = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', channel +'.png'))
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            title = '%s - %s' % (Addon.cleanChannel(channel), title)
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            if quality == 3:
                quality_name = 'High';
            elif quality == 2:
                quality_name = 'High';
            elif quality == 1:
                quality_name = 'Medium';
            else:
                quality_name = 'Low';
            Addon.add_video_item(rURL, {'title': title}, img=logo, playable=True, HD=quality_name, cm=cm_menu, cm_replace=False)

if mode == 'tvguide':
    xbmc.executebuiltin("RunAddon(script.ftvguide.custom)")
    exit()

##Begin ArconaiTV##
if mode == 'arconaitv':
    arconaitv_menu = tvtime.TVtime()._get_json('/menus/arconaitv' + base64.b64decode('LnBocA=='), {'key': access_key})
    arconaitv_menu_results = arconaitv_menu['results'];
    for i in arconaitv_menu_results: 
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['mode']+'.jpg')))

if mode == 'arconaitv_live':
    channels = tvtime.TVtime().get_arconaitv_channels()
    if channels:
        for c in sorted(channels, reverse=False):
            if c['status'] == "on":
                channel = c['channel'];
                id = c['id'];
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
                logo = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', c['img']))
                cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
                cm_menu = [cm_refresh]
                Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu, cm_replace=False)

if mode == 'tv_show_channels':
    channels = tvtime.TVtime().get_arconaitv_tv_shows()
    if channels:
        for c in sorted(channels, reverse=False):
            if c['status'] == "on":
                channel = c['channel'];
                id = c['id'];
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
                logo = c['img'];
                cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
                cm_menu = [cm_refresh]
                Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu, cm_replace=False)

if mode == 'movie_channels':
    channels = tvtime.TVtime().get_arconaitv_movies()
    if channels:
        for c in sorted(channels, reverse=False):
            if c['status'] == "on":
                channel = c['channel'];
                id = c['id'];
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
                cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
                cm_menu = [cm_refresh]
                Addon.add_video_item(rURL, {'title': channel}, playable=True, HD="Medium", cm=cm_menu, cm_replace=False)

if mode == 'sky':
    channels = tvtime.TVtime().get_sky_channels()
    if channels:
        for c in sorted(channels, reverse=False):
            if c['status'] == "on":
                channel = c['channel'];
                id = c['id'];
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_sky&rand=" + Addon.random_generator()
                logo = c['img']
                cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
                cm_menu = [cm_refresh]
                Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu, cm_replace=False)
##End ArconaiTV##

if mode == 'greenlie':
    channels = tvtime.TVtime().get_greenlie_channels()
    if channels:
        for c in sorted(channels, reverse=False):
            if c['status'] == "on":
                channel = c['channel'];
                id = c['id'];
                rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_greenlie&rand=" + Addon.random_generator()
                logo = c['img']
                cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
                cm_menu = [cm_refresh]
                Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu, cm_replace=False)

##Begin Movies On Demand##
if mode == 'movies_on_demand':
    movies_menu = tvtime.TVtime()._get_json('/menus/movies' + base64.b64decode('LnBocA=='), {'key': access_key})
    movies_menu_results = movies_menu['results'];
    for i in movies_menu_results: 
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'movies', i['mode']+'.jpg')))

if mode == 'movie_genres':
    genres = tvtime.TVtime()._get_json('/menus/movie_genres' + base64.b64decode('LnBocA=='), {'key': access_key})
    genres_results = genres['results'];
    for i in genres_results: 
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'])


if mode == 'movies_recent':
    channels = tvtime.TVtime().get_ondemand_movies('recent')
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)

if mode == 'movies_trending':
    channels = tvtime.TVtime().get_ondemand_movies('trending')
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_popular':
    channels = tvtime.TVtime().get_ondemand_movies('popular')
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_oscars':
    channels = tvtime.TVtime().get_ondemand_movies('oscars')
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_action':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_adventure':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_animation':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_biography':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_comedy':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_crime':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_drama':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)	
    
if mode == 'movies_family':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_fantasy':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_history':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_horror':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_music':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_musical':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_mystery':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_romance':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_sci_fi':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_sport':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_thriller':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_war':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_western':
    channels = tvtime.TVtime().get_ondemand_movies_genre(mode.replace(mode[:7], ''))
    if channels:
        for c in channels:
            title = c["title"].replace("&amp;", "&").replace('&quot;','"');
            imdb = c['imdb'];
            plot = c['plot'];
            director = c['director'];
            writer = c['writer'];
            year = c['year'];
            genre = c['genre'];
	    mpaa = c['mpaa'];
            rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
            logo = c["poster"];
            fanart = c["fanart"];
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
    xbmcplugin.setContent(Addon.plugin_handle, 'movies')
    xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    
if mode == 'movies_search':
    search = dlg.input('Search Movies On Demand', type=xbmcgui.INPUT_ALPHANUM)
    if len(search) != 0: 
        channels = tvtime.TVtime().get_ondemand_movies_search(search)
        if channels:
            for c in channels:
                title = c["title"].replace("&amp;", "&").replace('&quot;','"');
                title = title.replace("&amp;", "&");
                imdb = c['imdb'];
                plot = c['plot'];
                director = c['director'];
                writer = c['writer'];
                year = c['year'];
                genre = c['genre'];
	        mpaa = c['mpaa'];
                rURL = "plugin://plugin.video.tvtime.private/?title=" + title + "&mode=play_ondemand_movie"
                logo = c["poster"];
                fanart = c["fanart"];
                cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
                cm_menu = [cm_refresh]
                Addon.add_video_item(rURL,
                                 {'title': title, 'plot': plot, 'director': director, 'writer': writer, 'genre': genre, 'year': year, 'mpaa': mpaa},
                                 img=logo, fanart=fanart, playable=True, HD='High', cm=cm_menu, cm_replace=False)
        xbmcplugin.setContent(Addon.plugin_handle, 'movies')
        xbmc.executebuiltin("Container.SetViewMode(%s)" % movies_view)
    else:
        xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.tvtime.private/?mode=movies_on_demand)")
##End Movies On Demand##

elif mode == 'refresh':
    xbmc.executebuiltin('Container.Refresh')

##Begin Play Functions##
elif mode == 'play':
    channel = Addon.plugin_queries['channel']
    channels = tvtime.TVtime().get_link(channel, quality)
    if channels:
        for c in channels:
            if c['channel'] == channel:
                url = c['url']
                item = xbmcgui.ListItem(path=url)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

elif mode == 'play_ondemand_movie':
    title = Addon.plugin_queries['title']
    channels = tvtime.TVtime().get_link_ondemand_movie(title,"alternate")
    if channels:
        for c in channels:
            url = c['url']
            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

elif mode == 'play_arconaitv':
    id = Addon.plugin_queries['id']
    r = requests.get('https://www.arconaitv.xyz/stream.php?id='+id)
    html_text = r.text.encode('ascii', 'ignore')
    soup = BeautifulSoup(html_text, 'html.parser')
    scripts = soup.find_all('script')
    for script in scripts:
		if script.string is not None:
			if "document.getElementsByTagName('video')[0].volume = 1.0;" in script.string:
				idx = script.string.index("var")
				code = script.string[idx:]
				params = code[code.index('return r}(')+10:code.rfind('))')]
				params = params.replace('"','')
				params = params.split(',')
				for idx,param in enumerate(params):
					if param.isdigit():
						params[idx] = int(param)
				code = hunter(*params)
    unpacked = packer.unpack(code)
    video_location = unpacked[unpacked.rfind('http'):unpacked.rfind('m3u8')+4]
    play_item = xbmcgui.ListItem(path=video_location+'|User-Agent=%s' % urllib2.quote(USER_AGENT, safe=''))
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

elif mode == 'play_sky':
    id = Addon.plugin_queries['id']
    channels = tvtime.TVtime().get_link_sky(id)
    if channels:
        for c in channels:
            unblocked_proxy_stream(c['url'])

elif mode == 'play_greenlie':
    id = Addon.plugin_queries['id']
    channels = tvtime.TVtime().get_link_greenlie(id)
    if channels:
        for c in channels:
            unblocked_proxy_stream(c['url'])
##End Play Functions##

elif mode == 'tvcatchup':
    tvcatchup_main()

##Begin Live News##
elif mode == 'livenews_main':
    livenews_menu = tvtime.TVtime()._get_json('/menus/livenews' + base64.b64decode('LnBocA=='), {'key': access_key, 'rand': Addon.random_generator()})
    livenews_menu_results = livenews_menu['results'];
    for i in sorted(livenews_menu_results, reverse=False):
        if i['status'] == 'on':
            Addon.addLink_live(i['label'],"",i['url'],i['mode'],i['img'])
##End Live News##

##Begin US TV Catchup##
elif mode == 'us_tvcatchup':
    us_tvcatchup_menu = tvtime.TVtime()._get_json('/menus/us_tvcatchup' + base64.b64decode('LnBocA=='), {'key': access_key, 'rand': Addon.random_generator()})
    us_tvcatchup_menu_results = us_tvcatchup_menu['results'];
    for i in us_tvcatchup_menu_results: 
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['mode']+'.jpg')))

elif mode == 'sundancetv_main':
    sundancetv_main()

elif mode == 'hgtv_main':
    hgtv_main()

elif mode == 'travel_main':
    travel_main()

elif mode == 'diy_main':
    diy_main()

elif mode == 'cooking_main':
    cooking_main()

elif mode == 'food_main':
    food_main()

elif mode == 'smith_main':
    smith_main()

elif mode == 'freeform_main':
    freeform_main()

elif mode == 'abc_main':
    abc_main()

elif mode == 'nbc_main':
    nbc_main()

elif mode == 'pbs_main':
    pbs_main()
##End US TV Catchup##

elif mode == 'unblockedsports_main':
    unblockedsports_main()

elif mode == 'proxyportal_main':
    proxyportal_main()

elif mode == 'settings':
    Addon.show_settings()

##Begin FilmOn##
datapath = xbmc.translatePath(addon.getAddonInfo('profile'))
cookie_path = os.path.join(datapath, 'cookies')

if os.path.exists(cookie_path) == False:
    os.makedirs(cookie_path)

cookie_jar = os.path.join(cookie_path, "FilmOn.lwp")
    
def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Magic Browser')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def open_tvcatchup_url(url):
	req      = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
	response = urllib2.urlopen(req)
	link     = response.read()
	link     = cleanHex(link)
	response.close()
	return link

def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))
    
def categories():
    url='http://www.filmon.com/group'
    net.set_cookies(cookie_jar)
    html = net.http_GET(url).content
    link = html.encode('ascii', 'ignore')
    match=re.compile('<li class="group-item">.+?<a href="(.+?)">.+?"logo" src="(.+?)" title="(.+?)"',re.DOTALL).findall(link)
    for url, iconimage , name in match:
        if name == "ENTERTAINMENT" or name == "MUSIC" or name == "COMEDY" or name == "KIDS" or name == "BUSINESS TV" or name == "DOCUMENTARY" or name == "NEWS TV" or name == "EXTREME SPORTS" or name == "URBAN" or name == "PARTY TV" or name == "LIFESTYLE" or name == "BODY &amp; SOUL" or name == "FILMON EXCLUSIVE" or name == "FASHION" or name == "SCIENCE &amp; TECHNOLOGY TV" or name == "GERMAN TV" or name == "RUSSIAN TV" or name == "INDIAN TV" or name == "ITALIAN TV" or name == "MIDDLE EASTERN TV" or name == "MOVIES" or name == "SWISS TV" or name == "HUNGARIAN TV" or name == "LATINO TV" or name == "CLASSIC TV" or name == "SHORT FILMS" or name == "OUTDOORS" or name == "TRAVEL" or name == "SOMALI TV" or name == "GREEK LIVE TV" or name == "RELIGION" or name == "CELEBRITY TV" or name == "FOOD AND WINE" or name == "CARS &amp; AUTO" or name == "EDUCATION" or name == "SHOPPING TV" or name == "CARIBBEAN CHANNELS" or name == "ASIAN TV" or name == "AFRICAN TV" or name == "KAZAKH TV" or name == "HORROR":
            xbmcplugin.addSortMethod(int(sys.argv[1]), 1)
            addDir(name.title().replace('Tv','TV').replace('Uk','UK').replace('Uk','UK').replace('&Amp;','&'),url,3,iconimage,'',name)
                
def channels(url,name,group):
    r='<li class="channel i-box-sizing".+?channel_id="(.+?)">.+?"channel_logo" src="(.+?)" title="(.+?)"'
    net.set_cookies(cookie_jar)
    html = open_url('http://www.filmon.com'+url)
    match=re.compile(r,re.DOTALL).findall(html)
    for id , iconimage , name in match:
        if id != '1240' and id != '1078' and id != '1426' and id != '2146'and id != '2230' and id != '2236' and id != '2206' and id != '2233' and id != '4463' and id != '4931' and id != '2188' and id != '2152' and id != '2170' and id != '1426' and id != '1367' and id != '1310' and id != '1325' and id != '1336' and id != '1114' and id != '1111' and id != '1108' and id != '1099' and id != '1198' and id != '1102' and id != '1285' and id != '1287' and id != '3191' and id != '29' and id != '1289' and id != '1282' and id != '1286' and id != '1281' and id != '1172' and id != '2786' and id != '5672' and id != '93' and id != '1759' and id != '2218' and id != '1483' and id != '1254' and id != '1487' and id != '1345' and id != '1358' and id != '5366' and id != '1753' and id != '1536' and id != '1248' and id != '1266' and id != '1255' and id != '1258' and id != '1271' and id != '1256' and id != '2086' and id != '1272' and id != '1257' and id != '1262' and id != '1976' and id != '2044' and id != '2119' and id != '2128' and id != '2134' and id != '1129' and id != '1535' and id != '1507' and id != '1429' and id != '1524' and id != '1410' and id != '1526' and id != '1500' and id != '1505' and id != '1424' and id != '2245' and id != '1546' and id != '1506' and id != '2756' and id != '1738' and id != '1981' and id != '1735' and id != '1741' and id != '1744' and id != '3704' and id != '445' and id != '379' and id != '1778' and id != '1781' and id != '1796' and id != '1775' and id != '1772' and id != '79' and id != '1565' and id != '1558' and id != '1559' and id != '1561' and id != '1563' and id != '1562' and id != '1732' and id != '1213' and id != '1212' and id != '1217' and id != '1218' and id != '1219' and id != '1179' and id != '1238' and id != '1221' and id != '1237' and id != '1239' and id != '1233' and id != '1232' and id != '1222' and id != '1223' and id != '1224' and id != '1225' and id != '1226' and id != '1419' and id != '2242' and id != '1459' and id != '1461' and id != '1451' and id != '1793':
            addDir(name.replace(' New','New'),'http://www.filmon.com'+url.replace('channel','tv').replace('tvs','channels'),2,iconimage,id,group)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
                
def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
    else:
        r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
    return r
        
def play_stream(name,url,iconimage,description):
    import datetime
    streamerlink = net.http_GET(url).content.encode("utf-8").rstrip()
    net.save_cookies(cookie_jar)
    swfplay = 'http://www.filmon.com' + regex_from_to(streamerlink, '"streamer":"', '",').replace("\/", "/")

    name = name.replace('[COLOR cyan]','').replace('[/COLOR]','')
    dp = xbmcgui.DialogProgress()
    dp.create(Addon.get_string(5000) + ' - Opening ' + name.upper())
    utc_now = datetime.datetime.now()
    channel_name=name
    net.set_cookies(cookie_jar)
    url='http://www.filmon.com/channel/%s' % (description)
    link = net.http_GET(url,headers={'Accept':'application/json, text/javascript, */*; q=0.01'}).content
    link = json.loads(link)
    link = str(link)
	
    next_p = regex_from_to(link, "next_playing'", "u'title")
    try:
        n_start_time = datetime.datetime.fromtimestamp(int(regex_from_to(next_p, "startdatetime': u'", "',")))
        n_end_time = datetime.datetime.fromtimestamp(int(regex_from_to(next_p, "enddatetime': u'", "',")))
        n_programme_name = regex_from_to(next_p, "programme_name': u'", "',")
        n_start_t = n_start_time.strftime('%H:%M')
        n_end_t = n_end_time.strftime('%H:%M')
        n_p_name = "[COLOR cyan]Next: %s (%s-%s)[/COLOR]" % (n_programme_name, n_start_t, n_end_t)
    except:
        n_p_name = ""
		
    now_p = regex_from_to(link, "now_playing':", "u'tvguide")
    try:
        start_time = datetime.datetime.fromtimestamp(int(regex_from_to(now_p, "startdatetime': u'", "',")))
        end_time = datetime.datetime.fromtimestamp(int(regex_from_to(now_p, "enddatetime': u'", "',")))
        programme_name = regex_from_to(now_p, "programme_name': u'", "',")
        description = ""
        start_t = start_time.strftime('%H:%M')
        end_t = end_time.strftime('%H:%M')
        p_name = "%s (%s-%s)" % (programme_name, start_t, end_t)
        dp.update(50, p_name)
    except:
        try:
            p_name = programme_name
        except:
            p_name = name
    streams = regex_from_to(link, "streams'", "u'tvguide")
    hl_streams = regex_get_all(streams, '{', '}')
    url = regex_from_to(hl_streams[1], "url': u'", "',")
    name = regex_from_to(hl_streams[1], "name': u'", "',")

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    handle = str(sys.argv[1])
    try:
        listitem = xbmcgui.ListItem(p_name + ' ' + n_p_name, iconImage=iconimage, thumbnailImage=iconimage, path=url)
        if handle != "-1":	
            listitem.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        else:
            xbmcPlayer = xbmc.Player()
            xbmcPlayer.play(url,listitem)
    except:
        listitem = xbmcgui.ListItem(channel_name, iconImage=iconimage, thumbnailImage=iconimage, path=url)
        if handle != "-1":
            listitem.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        else:
            xbmcPlayer = xbmc.Player()
            xbmcPlayer.play(url,listitem)
    dp.close()

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r
           
def get_params():
                param=[]
                paramstring=sys.argv[2]
                if len(paramstring)>=2:
                                params=sys.argv[2]
                                cleanedparams=params.replace('?','')
                                if (params[len(params)-1]=='/'):
                                    params=params[0:len(params)-2]
                                pairsofparams=cleanedparams.split('&')
                                param={}
                                for i in range(len(pairsofparams)):
                                    splitparams={}
                                    splitparams=pairsofparams[i].split('=')
                                    if (len(splitparams))==2:
                                        param[splitparams[0]]=splitparams[1]
                                                                
                return param

def addDir(name,url,mode,iconimage,description,group):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)+"&group="+urllib.quote_plus(group)+"&rand=" + Addon.random_generator()
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name })
    if mode==2:
        liz.setProperty("IsPlayable", "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
                                            
params=get_params()
if mode != 'filmon':
    url = 'null'
else:
    url = None
name = None
mode = None
iconimage = None
description = None
group = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    group = urllib.unquote_plus(params["group"])
except:
    pass

if mode == 'filmon' or url == None or len(url) <1 :
    categories()               

elif mode == 2:
    play_stream(name,url,iconimage,description)
                
elif mode == 3:
    channels(url,name,group)
##End FilmOn##

##This is for the TVCatchup.com stuff##
elif mode == 5: tvcatchup(url)

##This is for the HGTV stuff##
elif mode == 6: hgtv_episodes(url)

##This is for the HGTV stuff##
elif mode == 7: hgtv_stream(url)

##This is for the Travel Channel stuff##
elif mode == 8: travel_episodes(url)

##This is for the Travel Channel stuff##
elif mode == 9: travel_stream(url)

##This is for the DIY Network stuff##
elif mode == 10: diy_episodes(url)

##This is for the DIY Network stuff##
elif mode == 11: diy_stream(url)

##This is for the Cooking Channel stuff##
elif mode == 12: cooking_episodes(url)

##This is for the Cooking Channel stuff##
elif mode == 13: cooking_stream(url)

##This is for the Food Network stuff##
elif mode == 14: food_episodes(url)

##This is for the Food Network stuff##
elif mode == 15: food_stream(url)

##This is for the SundanceTV stuff##
elif mode == 16: sundancetv_episodes(url)

##This is for the SundanceTV stuff##
elif mode == 17: sundancetv_stream(url)

##This is for the SundanceTV stuff##
elif mode == 18: sundancetv_movies(url)

##This is for the SundanceTV stuff##
elif mode == 19: sundancetv_stream_movie(url)

##This is for the Smithsonian Channel stuff##
elif mode == 20: smith_stream(url)

##This is for the Freeform stuff##
elif mode == 21: freeform_episodes(url)

##This is for the Freeform stuff##
elif mode == 22: freeform_stream(url)

##This is for the Freeform stuff##
elif mode == 23: freeform_movies(url)

##This is for the ABC stuff##
elif mode == 24: abc_seasons(url, name, iconimage)

##This is for the ABC stuff##
elif mode == 25: abc_episodes(url)

##This is for the ABC stuff##
elif mode == 26: abc_stream(url)

##This is for the NBC stuff##
elif mode == 27: nbc_episodes(url)

##This is for the NBC stuff##
elif mode == 28: nbc_stream(url)

##This is for the PBS stuff##
elif mode == 29: pbs_episodes(url)

##This is for the PBS stuff##
elif mode == 30: pbs_stream(url)

##This is for the any unblocked and proxyportal streams##
elif mode == 99: unblocked_proxy_stream(url)

##These are for the Live News Streams##
elif mode == 100: livenews_stream(url, name)

Addon.end_of_directory()
