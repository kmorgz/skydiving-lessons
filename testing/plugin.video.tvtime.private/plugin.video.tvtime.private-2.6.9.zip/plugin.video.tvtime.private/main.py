"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import json
import os
import urllib
import xbmc
import xbmcplugin
import xbmcgui
import re
from datetime import datetime, timedelta
import time
from resources.lib import common
from resources.lib import channels
import urlresolver
import m7lib

mode = common.TVTime().plugin_queries['mode']

key_check = common.TVTime().check_access_key(common.TVTime().access_key)

if key_check == 'offline':
    common.dlg.ok(common.addonname, common.get_string(90000))
    exit()

if key_check != 'success':
    try:
    # Enter Access Key
        retval = common.dlg.input(common.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if retval and len(retval) > 0:
            common.set_setting('access_key', str(retval))
            access_key = common.get_setting('access_key')
            key_check = common.TVTime().check_access_key(common.TVTime().access_key)
        if len(common.get_setting('access_key')) > 0 and key_check == 'success':
            common.dlg.ok(common.addonname, common.get_string(70000))
        else:
            common.dlg.ok(common.addonname, common.get_string(80000))
            exit()
    except StandardError:
        common.dlg_oops(common.addonname)

if mode == 'main':
    try:
        url = common.TVTime().BASE + "/menus/main" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key
        main_menu = m7lib.Common.open_url(url)
        main_menu_results = json.loads(main_menu)['results']

        for i in main_menu_results:
            if i['status'] == 'on':
                icon = common.get_section_logo(i["icon"])
                m7lib.Common.add_section(i['mode'], icon, common.FANART, i['label'])

        if len(common.get_setting('notify')) > 0:
            common.set_setting('notify', str(int(common.get_setting('notify')) + 1))
        else:
            common.set_setting('notify', "1")
        if int(common.get_setting('notify')) == 1:
            common.dlg.notification('Like ' + common.addonname + ' Private?', 'Keep it Private!', common.ICON, 5000, False)
        elif int(common.get_setting('notify')) == 9:
            common.set_setting('notify', "0")
    except StandardError:
        common.dlg_oops(common.addonname)

# Begin ArconaiTV #
elif mode == 'arconaitv':
    try:
        url = common.TVTime().BASE + "/menus/arconaitv" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key
        arconaitv_menu = m7lib.Common.open_url(url)
        arconaitv_menu_results = json.loads(arconaitv_menu)['results']

        for i in arconaitv_menu_results:
            if i['status'] == 'on':
                icon = common.get_section_logo(i["icon"])
                m7lib.Common.add_section(i['mode'], icon, common.FANART, i['label'])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_live':
    try:
        for channel in channels.Channel().get_arconaitv_channels('Cable'):
            channel_logo = channels.Channel().get_channel_logo(channel["name"].strip())
            m7lib.Common.add_channel(channel["url"] + "_play-arconaitv", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_tv_show_channels':
    try:
        for channel in channels.Channel().get_arconaitv_channels('Shows'):
            channel_logo = channels.Channel().get_channel_poster(channel["name"].replace(" ", "").strip())
            m7lib.Common.add_channel(channel["url"] + "_play-arconaitv", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_movie_channels':
    try:
        for channel in channels.Channel().get_arconaitv_channels('Movies'):
            if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/arconaitv.png'))):
                channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/arconaitv.png'))
            else:
                channel_logo = common.ICON
            m7lib.Common.add_channel(channel["url"] + "_play-arconaitv", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif "_play-arconaitv" in mode:
    try:
        url = mode.split('_')[0]
        channels.Channel().play_arconaitv(url)
    except StandardError:
        common.dlg_oops(common.addonname)
# End ArconaiTV #

# End Pokemon Fire #
elif mode == 'pokemon_fire':
    icon = common.SKIN_PATH + "/" + "pokemon_fire.png"
    m7lib.Common.add_section("pokemon_seasons", icon, common.FANART, "TV")
    m7lib.Common.add_section("pokemon_movies", icon, common.FANART, "Movies")

elif mode == "pokemon_seasons":
    try:
        season_path_base = "https://www.pokemonfire.com/seasons/"
        link = m7lib.Common.open_url(season_path_base)
        match = re.compile('<img src="(.+?)" alt="Pok.+?mon: Season (.+?)">').findall(link)
        match = list(reversed(match))
        for thumb, season in match:
            name = 'Season %s' % season
            url = 'https://www.pokemonfire.com/seasons/pokemon-season-%s/' % season
            m7lib.Common.add_section(url + "_pokemon-season", thumb, common.FANART, name)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "_pokemon-season" in mode:
    try:
        url = mode.split('_')[0]
        link = m7lib.Common.open_url(url)
        match = re.compile(
            '<div class="imagen"><a href="(.+?)"><img src="(.+?)"></a></div>\n	<div class="numerando">(.+?)</div>\n	<div class="episodiotitle">\n	<a href=".+?">(.+?)</a>\n	<span class="date">(.+?)</span>').findall(link)
        for url, thumb, episode, title, date in match:
            name = '[B]%s |[/B] %s' % (episode, title)
            m7lib.Common.add_channel(url + "_play-pokemon", thumb, common.FANART, name, live=False)

    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "pokemon_movies":
    try:
        link = m7lib.Common.open_url("https://www.pokemonfire.com/movies/")
        match = re.compile(
            '<div class="poster">\n		<img src="(.+?)" alt="(.+?)">\n		<div class="rating"><span class="icon-star2"></span>.+?</div>\n						<a href="(.+?)"><div class="see"></div></a>\n	</div>\n	<div class="data">\n		<h3>\n		<a href=".+?">.+?</a>\n		</h3>\n				<span>(.+?)</span>\n			</div>').findall(link)
        match = list(reversed(match))
        for thumb, title, url, year in match:
            name = '%s (%s)' % (title, year)
            name = name.replace('&#8211;', '-')
            m7lib.Common.add_channel(url + "_play-pokemon", thumb, common.FANART, name, live=False)

    except StandardError:
        common.dlg_oops(common.addonname)

elif "_play-pokemon" in mode:
    url = mode.split('_')[0]
    channels.Channel().play_pokemon(url)
# End Pokemon Fire #

# Begin Fluxus IPTV #
elif mode == 'fluxus_main':
    try:
        # Set protect flag.
        common.set_setting('protect', "true")
        url = common.TVTime().BASE + "/menus/fluxus" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key
        fluxus_menu = m7lib.Common.open_url(url)
        fluxus_menu_results = json.loads(fluxus_menu)['results']

        for i in fluxus_menu_results:
            if i['status'] == 'on':
                icon = common.get_section_logo(i["icon"])
                m7lib.Common.add_section(i['mode'], icon, common.FANART, i['label'])

        if common.get_setting('enable_adult_sections') == 'true':
            if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/fluxus_tv.png'))):
                icon = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/fluxus_tv.png'))
            else:
                icon = common.ICON
            m7lib.Common.add_section("fluxus_lust", icon, common.FANART, "Fluxus Lust")
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'fluxus_iptv':
    try:
        url = common.TVTime().BASE + "/fluxus/v1/get_list" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key + "&list=" + mode.replace("fluxus_", "")
        fluxus_menu = m7lib.Common.open_url(url)
        fluxus_menu_results = json.loads(fluxus_menu)

        # Get Updated Date
        for i in sorted(fluxus_menu_results):
            try:
                if "- Playlist Update" in i['tvgroup']:
                    tvtitle = str("[COLOR lightskyblue]" + "** Updated:" + i['tvtitle'] + " **[/COLOR]").replace(":-", ":")
                    if "tvlogo" not in tvtitle:
                        if i['tvlogo'] == "":
                            img = 'https://i.imgur.com/CvQCnwZ.png'
                        else:
                            img = i['tvlogo']
                        m7lib.Common.add_channel("noop", img, common.FANART, tvtitle)
            except KeyError:
                pass

        # Get Streams
        for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
            try:
                if i['tvgroup'] == "USA" or \
                        i['tvgroup'] == "USA LOCAL" or \
                        i['tvgroup'] == "UK" or \
                        i['tvgroup'] == "CANADA" or \
                        i['tvgroup'] == "AUSTRALIA":
                    tvtitle = json.dumps(i['tvtitle']).replace('"','')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    m7lib.Common.add_channel(i['tvmedia'] + "_play-iptv", img, common.FANART, tvtitle)
            except KeyError:
                pass
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'fluxus_cctv' or mode == 'fluxus_faith' or mode == 'fluxus_lust':
    try:
        def get_fluxus():
            url = common.TVTime().BASE + "/fluxus/v1/get_list" + base64.b64decode(
                'LnBocA==') + "?key=" + common.TVTime().access_key + "&list=" + mode.replace("fluxus_", "")
            fluxus_menu = m7lib.Common.open_url(url)
            fluxus_menu_results = json.loads(fluxus_menu)

            # Get Updated Date
            for i in sorted(fluxus_menu_results):
                try:
                    if "- Playlist Update" in i['tvgroup']:
                        tvtitle = str("[COLOR lightskyblue]" + "** Updated:" + i['tvtitle'] + " **[/COLOR]").replace(":-", ":")
                        if i['tvlogo'] == "":
                            img = 'https://i.imgur.com/CvQCnwZ.png'
                        else:
                            img = i['tvlogo']
                        m7lib.Common.add_channel("noop", img, common.FANART, tvtitle)
                except KeyError:
                    pass

            # Get Streams
            for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
                try:
                    if i['tvgroup'] != "INFO" and i['tvgroup'] != "LABEL" and "* Fluxus Lust" not in i['tvtitle']\
                            and "* Fluxus.tv > Play On!" not in i['tvgroup'] and "+ Fluxus" not in i['tvtitle'] \
                            and "- Playlist Update" not in i['tvgroup'] and "+ " not in i['tvtitle']:
                        tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                        if i['tvlogo'] == "":
                            img = 'https://i.imgur.com/CvQCnwZ.png'
                        else:
                            img = i['tvlogo']
                        m7lib.Common.add_channel(i['tvmedia'] + "_play-iptv", img, common.FANART, tvtitle)
                except KeyError:
                    pass

        if mode == 'fluxus_lust':
            # Access Key Protection
            if str(common.get_setting('protect')) == 'true':
                retval = common.dlg.input(common.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                lock_check = common.TVTime().check_access_key(retval)

                if lock_check == 'success':
                    # Set protect flag. This will be set back to true once use 'backs out' of Fluxus Lust section.
                    common.set_setting('protect', "false")

                    common.dlg.ok(common.addonname, common.get_string(900004))

                    get_fluxus()

                else:
                    common.dlg.ok(common.addonname, common.get_string(80000))
                    exit()

            elif str(common.get_setting('protect')) == 'false':
                get_fluxus()

        else:
            get_fluxus()
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'fluxus_cinema':
    try:
        url = common.TVTime().BASE + "/fluxus/v1/get_list" + base64.b64decode(
            'LnBocA==') + "?key=" + common.TVTime().access_key + "&list=" + mode.replace("fluxus_", "")
        fluxus_menu = m7lib.Common.open_url(url)
        fluxus_menu_results = json.loads(fluxus_menu)

        for i in sorted(fluxus_menu_results, reverse=False):
            try:
                if i['tvgroup'] == "MOVIES" or "=" in i['tvtitle']:
                    if "=" in i['tvtitle']:
                        tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                    else:
                        tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    m7lib.Common.add_channel("noop", img, common.FANART, tvtitle)
            except KeyError:
                pass
    except StandardError:
        common.dlg_oops(common.addonname)
# End Fluxus IPTV #

# End Lodge TV IPTV #
elif mode == 'lodge_tv_main':
    try:
        url = common.TVTime().BASE + "/lodgetv/v1/get_list" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key + "&list=english"
        lodgetv_menu = m7lib.Common.open_url(url)
        lodgetv_menu_results = json.loads(lodgetv_menu)

        # Get Updated Date
        for i in sorted(lodgetv_menu_results):
            if "~" not in i['tvtitle'] and "=" in i['tvtitle']:
                tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                img = i['tvlogo']

                m7lib.Common.add_channel("noop", img, common.FANART, tvtitle)

        # Get Streams
        for i in sorted(lodgetv_menu_results, key=lambda k: k['tvtitle']):
            if "~" not in i['tvtitle'] and "=" not in i['tvtitle'] and ">" not in i['tvtitle'] and "LODGE" not in i['tvtitle']:
                img = i['tvlogo']

                m7lib.Common.add_channel(i['tvmedia'] + "_play-iptv", img, common.FANART, i['tvtitle'])
    except StandardError:
        common.dlg_oops(common.addonname)
# End Lodge TV IPTV #

# End Stratus TV IPTV #
elif mode == 'stratus_tv_main':
    try:
        url = common.TVTime().BASE + "/stratustv/v1/get_list" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key + "&list=english"
        stratustv_menu = m7lib.Common.open_url(url)
        stratustv_menu_results = json.loads(stratustv_menu)

        for i in sorted(stratustv_menu_results, key=lambda k: k['tvtitle']):
            try:
                tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                img = i['tvlogo']
                m7lib.Common.add_channel(i['tvmedia'] + "_play-iptv", img, common.FANART, tvtitle)
            except KeyError:
                pass
    except StandardError:
        common.dlg_oops(common.addonname)
# End Stratus TV IPTV #

# Begin IPTV (Fluxus, Lodge TV, and Stratus TV Play modes #
elif "_play-iptv" in mode:
    try:
        url = mode.split('_')[0]
        m7lib.Common.play(url)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "noop":
    try:
        common.dlg.ok(common.addonname, common.get_string(100004))
        exit()
    except StandardError:
        common.dlg_oops(common.addonname)
# End IPTV (Fluxus, Lodge TV, and Stratus TV Play modes #


# Begin YouTube Channels #
elif mode == 'youtube_channels':
    try:
        youtube_channels = channels.Channel().get_youtube_channels()["results"]

        for channel in youtube_channels:
            if channel["status"] == 'on':
                m7lib.Common.add_section(
                    channel["mode"],
                    channels.Channel().get_channel_logo(channel["mode"]),
                    common.FANART, channel["label"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode in channels.Channel().get_youtube_channel_modes():
    try:
        playlists = channels.Channel().build_youtube_main(mode)
        if playlists:
            for c in sorted(playlists):
                m7lib.Common.add_section(c['title'] + "-youtube-channel_" + mode, c['img'], common.FANART, c['title'])
        else:
            common.dlg_oops(common.addonname)
    except StandardError:
        common.dlg_oops(common.addonname)
        exit()

elif "youtube-channel_" in mode:
    try:
        ymode = mode.split('_', 1)[-1]
        playlists = channels.Channel().build_youtube_main(ymode)
        if playlists:
            for c in playlists:
                channels.Channel().show_youtube_streams(c['title'], c['playlist_id'], mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif '_play-youtube' in mode:
    try:
        videoId = mode.split('_')[0]
        url = common.TVTime().BASE + "/ytpowered/v1/check" + base64.b64decode('LnBocA==') + "?id=" + videoId

        stream_status = json.loads(m7lib.Common.open_url(url))['status']

        if stream_status == 'true':
            channels.Channel().play_youtube(videoId)
        else:
            common.dlg_oops(common.addonname)
            exit()
    except StandardError:
        common.dlg_oops(common.addonname)
# End YouTube Channels #

# Begin Xumo TV & Movies #
elif mode == "xumo_direct_main":
    try:
        req = m7lib.Common().open_url(channels.Channel().XUMO_BASE_API%"channels/list/10006.json?q=genreid:195")
        stations_json = json.loads(req)
        stations = stations_json["channel"]["item"]

        for i in sorted(stations, key=lambda k: k['title']):
            logo = channels.Channel().XUMO_BASE_LOGO % (i["guid"]["value"])
            if i["title"] != "Docurama":
                m7lib.Common.add_section(i["title"] + "-xumo-channel_" + i["guid"]["value"], logo, common.FANART, i["title"])
            else:
                m7lib.Common.add_channel("xumo-stream_XM0CHNSP1IRFM6", logo, common.FANART, i["title"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif "xumo-channel_" in mode:
    try:
        channel_id = mode.split('_', 1)[-1]
        req = m7lib.Common().open_url(channels.Channel().XUMO_BASE_API%"channels/channel/%s/categories.json" % channel_id)
        categories_json = json.loads(req)
        categories = categories_json["categories"]

        for i in sorted(categories, key=lambda k: k['title']):
            title = i["title"].replace("&", "and")
            if ":" not in title:
                cat_id = i["categoryId"]
                logo = channels.Channel().XUMO_BASE_LOGO % channel_id
                m7lib.Common.add_section(channel_id + "-xumo-category_" + cat_id, logo, common.FANART, title)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "-xumo-category_" in mode:
    try:
        cat_id = mode.split('_', 1)[-1]
        channel_id = mode.split('-')[0]
        req = m7lib.Common().open_url(channels.Channel().XUMO_BASE_API%"categories/category/%s.json?f=asset.title&f=asset.episodeTitle" % cat_id)

        movies_json = json.loads(req)
        movies = movies_json["results"]

        # Create Xumo cache directory #
        xumo_path = xbmc.translatePath('special://home/userdata/addon_data/' + common.addonid + '/xumo/')
        if not os.path.exists(xumo_path):
            os.mkdir(xumo_path)

        # Clean Xumo cache if cache is older than 30 days #
        if common.get_setting('xumo_cache') != "0":
            if datetime(*(time.strptime(common.get_setting('xumo_cache'), "%Y-%m-%d %H:%M:%S.%f")[0:6])) < datetime.now():
                common.set_setting('xumo_cache', "0")
                if os.path.exists(xumo_path):
                    for root, dirs, files in os.walk(xumo_path):
                        for currentFile in files:
                            os.remove(os.path.join(root, currentFile))

        # Xumo cache progress #
        progress = [1]
        progress_heading = common.get_string(100008)
        progress_message = common.get_string(100009)

        for i in sorted(movies, key=lambda k: k['title']):
            logo_cache_path = xumo_path + i['id'] + '.jpg'
            if common.exists_local(logo_cache_path):
                if common.is_non_zero_file(logo_cache_path):
                    logo = logo_cache_path
                else:
                    logo = channels.Channel().XUMO_BASE_LOGO % channel_id
            else:
                # Set Xumo cache date #
                if common.get_setting('xumo_cache') == "0":
                    common.set_setting('xumo_cache', str(datetime.now() + timedelta(days=30)))

                # Create Xumo progress bar #
                common.dlg_progress.create(progress_heading)

                # If Xumo progress dialog is canceled exit #
                if common.dlg_progress.iscanceled():
                    exit()
                urllib.urlretrieve(channels.Channel().XUMO_BASE_THUMB % i["id"], logo_cache_path)

                # Increment progress bar #
                progress.append(1)

                if common.exists_local(logo_cache_path):
                    if common.is_non_zero_file(logo_cache_path):
                        logo = logo_cache_path
                    else:
                        logo = channels.Channel().XUMO_BASE_LOGO % channel_id
                else:
                    logo = channels.Channel().XUMO_BASE_LOGO % channel_id

                # Update Xumo progress bar #
                common.dlg_progress.update(int(len(progress) * (100 / len(movies))), progress_message, " ", "Images cached: [COLOR lightskyblue]" +
                                           str(len(progress) - 1) + "[/COLOR] of [COLOR lightskyblue]" + str(len(movies)) + "[/COLOR]")

            m7lib.Common.add_channel("xumo-stream_" + i["id"], logo, common.FANART, i["title"], live=False)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "xumo-stream_" in mode:
    try:
        stream_id = mode.split('_', 1)[-1]
        req = m7lib.Common().open_url(channels.Channel().XUMO_BASE_API%"/assets/asset/%s.json?f=title&f=providers" % stream_id)

        stream_json = json.loads(req)
        stream = m7lib.Common.rebase(stream_json["providers"][0]["sources"][0]["uri"])
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_oops(common.addonname)
    except StandardError:
        common.dlg_oops(common.addonname)
# End Xumo TV & Movies #

# Begin Free Live TV (Extra) #
elif mode == 'free_livetv_direct_main':
    try:
        # Generate Section List
        for section in sorted(m7lib.Common.get_sections(), reverse=False):
            m7lib.Common.add_section(section, m7lib.Common.get_logo(section, "section"), common.FANART)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "All Channels":
    try:
        common.dlg.notification(common.addonname, common.get_string(100007), common.addonname, False, False)

        channel_list = []

        m7lib_channels = m7lib.Common.get_channels()

        # Get channels from m7lib
        for channel in m7lib_channels:
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "m7lib"})

        # Add extra channels
        for channel in channels.Channel().free_live_tv_extra_channels:
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "extra"})

        # Add ustvgo channels
        for channel in channels.Channel().get_ustvgo_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "ustvgo"})

        # Add usnewslive channels
        for channel in channels.Channel().get_usnewslive_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "usnewslive"})

        # Add easyview channels
        for channel in channels.Channel().get_easyview_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "easyview"})

        # Build channel list
        for channel in sorted(channel_list):
            channel_logo = channels.Channel().get_channel_logo(channel["name"])
            if channel["source"] == "extra":
                m7lib.Common.add_channel(channel["name"], channel_logo, common.FANART)
            elif channel["source"] == "ustvgo" or channel["source"] == "usnewslive":
                m7lib.Common.add_channel(channel["url"] + "_play-ustvgo", channel_logo, common.FANART, channel["name"])
            elif channel["source"] == "easyview":
                m7lib.Common.add_channel(channel["url"] + "_play-easyview", channel_logo, common.FANART, channel["name"])
            else:
                channel_logo = m7lib.Common.get_logo(channel["name"])
                m7lib.Common.add_channel(channel["name"] + "_play-m7lib", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "Genres":
    try:
        # Generate Genre List
        genres = channels.Channel().get_genres()
        for genre in sorted(genres, reverse=False):
            if genre == "Network TV" or genre == "Misc":
                logo = xbmc.translatePath(os.path.join(common.GENRE_PATH + '/' + genre + '.png'))
            else:
                logo = m7lib.Common.get_logo(genre, "genre")
            m7lib.Common.add_section(genre, logo, common.FANART)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode in channels.Channel().get_genres():
    try:
        common.dlg.notification(common.addonname, common.get_string(100007), common.addonname, False, False)

        channel_list = []

        m7lib_channels = m7lib.Common.get_channels()

        # Get channels from m7lib
        for channel in m7lib_channels:
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "m7lib"})

        # Add extra channels
        for channel in channels.Channel().free_live_tv_extra_channels:
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": None, "source": "extra"})

        # Add ustvgo channels
        for channel in channels.Channel().get_ustvgo_channels():
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "ustvgo"})

        # Add usnewslive channels
        for channel in channels.Channel().get_usnewslive_channels():
            channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "usnewslive"})

        # Add easyview channels
        for channel in channels.Channel().get_easyview_channels():
            if mode in channel["type"]:
                channel_list.append({"name": channel["name"], "type": channel["type"], "url": channel["url"], "source": "easyview"})

        # Build channel list within given genre
        for channel in sorted(channel_list):
            channel_logo = channels.Channel().get_channel_logo(channel["name"])
            if channel["source"] == "extra":
                m7lib.Common.add_channel(channel["name"], channel_logo, common.FANART)
            elif channel["source"] == "ustvgo" or channel["source"] == "usnewslive":
                m7lib.Common.add_channel(channel["url"] + "_play-ustvgo", channel_logo, common.FANART, channel["name"])
            elif channel["source"] == "easyview":
                m7lib.Common.add_channel(channel["url"] + "_play-easyview", channel_logo, common.FANART, channel["name"])
            else:
                channel_logo = m7lib.Common.get_logo(channel["name"])
                m7lib.Common.add_channel(channel["name"] + "_play-m7lib", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif "_play-m7lib" in mode:
    try:
        mode = mode.split('_')[0]
        m7lib.Common.get_stream_and_play(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "_play-ustvgo" in mode:
    try:
        url = mode.split('_')[0]
        channels.Channel().play_ustvgo(url)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "_play-easyview" in mode:
    try:
        url = mode.split('_')[0]
        channels.Channel().play_easyview(url)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'ET Live':
    try:
        channels.Channel().play_et_live(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'ABC News':
    try:
        channels.Channel().play_abc_news(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "CBS Sports HQ":
    try:
        channels.Channel().play_cbs_sports_hq(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "HLN":
    try:
        channels.Channel().play_hln(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'CBSN':
    try:
        channels.Channel().play_cbs_news(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'CBSN New York':
    try:
        channels.Channel().play_cbs_news_ny(mode)
    except StandardError:
        common.dlg_oops(common.addonname)
# End Free Live TV (Extra) #

# Begin OpenLoad Movies #
elif mode == "open_load_direct":
    if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))):
        channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))
    else:
        channel_logo = common.ICON
    m7lib.Common.add_section("popular_apollo-json", channel_logo, common.FANART, "Most Popular")
    m7lib.Common.add_section("trending_apollo-json", channel_logo, common.FANART, "Trending")
    m7lib.Common.add_section("box_apollo-json", channel_logo, common.FANART, "Box Office")
    m7lib.Common.add_section("oscars_apollo-json", channel_logo, common.FANART, "Oscar Winners")
    m7lib.Common.add_section("theaters_apollo-json", channel_logo, common.FANART, "In Theaters")
    m7lib.Common.add_section("search_apollo", channel_logo, common.FANART, "Search")

elif "_apollo-json" in mode:
    try:
        list = mode.split('_')[0]
        url = common.TVTime().OPL_BASE_JSON + "list/movie/" + list + ".json"
        open_url = m7lib.Common.open_url(url)
        json_results = json.loads(open_url)['result']
        for i in json_results:
            m7lib.Common.add_channel(i["imdb"] + "_play-apollo", i["poster"], i["fanart"], i["title"], live=False)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "_play-apollo" in mode:
    try:
        if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))):
            channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))
        else:
            channel_logo = common.ICON
        imdb = mode.split('_')[0]
        openload_link = m7lib.Common.open_url(common.TVTime().OPL_BASE_IMDB + imdb)
        url = m7lib.Common.rebase(m7lib.Common.find_single_match(openload_link, 'id="odbIframe" src="(.+?)"'))
        if len(url.replace("?rebase=on", "")) != 0:
            common.dlg.notification(common.addonname, common.get_string(100006), channel_logo, 10000, False)
            stream = urlresolver.resolve(url)
            m7lib.Common.play(stream)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "search_apollo":
    try:
        if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))):
            channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/openload.png'))
        else:
            channel_logo = common.ICON
        search = common.dlg.input('Search OpenLoad', type=xbmcgui.INPUT_ALPHANUM)
        if len(search) != 0:
            embed = m7lib.Common.open_url(common.TVTime().OPL_BASE_TITLE + str(search))
            url = m7lib.Common.rebase(m7lib.Common.find_single_match(embed, 'id="odbIframe" src="(.+?)"'))
            if len(url.replace("?rebase=on", "")) != 0:
                common.dlg.notification(common.addonname, common.get_string(100006), channel_logo, 10000, False)
                stream = urlresolver.resolve(url)
                m7lib.Common.play(stream, xbmc_player=True)
                exit()
            else:
                common.dlg.ok(common.addonname, common.get_string(100002))
                exit()
        else:
            common.dlg.ok(common.addonname, common.get_string(100003))
            exit()
    except StandardError:
        common.dlg_oops(common.addonname)
# End OpenLoad Movies #

# Begin Misc Mods #
elif mode == "settings":
    try:
        # Channel Selection
        source = xbmcgui.Dialog().select("Options", [
            "[COLOR lightskyblue][I]Configure TV Time[/I][/COLOR]",
            "[COLOR lightskyblue][I]View Changelog[/I][/COLOR]"
        ])
        if source == 0:
            common.show_settings()
        elif source == 1:
            common.show_changelog()
            exit()
        else:
            exit()
    except StandardError:
        common.dlg_oops(common.addonname)
# End Misc Mods #

xbmcplugin.endOfDirectory(common.TVTime().plugin_handle, cacheToDisc=False)
