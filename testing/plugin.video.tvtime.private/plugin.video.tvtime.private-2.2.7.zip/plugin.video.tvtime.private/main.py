"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import json
import os
import re
import sys
import urllib
import urllib2

import jsbeautifier.unpackers.packer as packer
import requests
import urlresolver
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup

from resources.lib import Addon, tvtime
from resources.modules import net
from resources.lib import channels

net = net.Net()

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')

Addon.plugin_url = sys.argv[0]
Addon.plugin_handle = int(sys.argv[1])
Addon.plugin_queries = Addon.parse_query(sys.argv[2][1:])

dlg = xbmcgui.Dialog()

addon_logo = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))

mode = Addon.plugin_queries['mode']

access_key = str(Addon.get_setting('access_key'))

key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})['status']

if key_check == 'offline':
    dlg.ok(Addon.get_string(5000), Addon.get_string(90000))
    exit()

if key_check != 'success':
    # Enter Access Key
    retval = dlg.input(Addon.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if retval and len(retval) > 0:
        Addon.set_setting('access_key', str(retval))
        access_key = Addon.get_setting('access_key')
        key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})[
            'status']
    if len(Addon.get_setting('access_key')) > 0 and key_check == 'success':
        dlg.ok(Addon.get_string(5000), Addon.get_string(70000))
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(80000))
        exit()


def youtube_stream(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url


##Begin Live News##
def livenews_stream(url, name):
    if "youtube" in url:
        stream = Addon.youtube_resolve(url)
    else:
        stream = url + '|Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
    item = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def cnn_stream(url, name):
    # Get Stream
    link = Addon.open_url(url)
    stream = Addon.find_single_match(link, "file: '(.+?)'")
    if "m3u8" in stream:
        Addon.play_generic(stream)
    else:
        dlg.ok(name, "Unable to get stream. Please try again later.")


def foxnews_stream(url, name):
    # Get Stream
    link = Addon.open_url(url)
    stream = Addon.find_single_match(link, "file: '(.+?)'")
    if "m3u8" in stream:
        Addon.play_generic(stream)
    else:
        dlg.ok(name, "Unable to get stream. Please try again later.")


def msnbc_stream(url, name):
    # Get Stream
    link = Addon.open_url(url)
    stream = Addon.find_single_match(link, "file: '(.+?)'")
    if "m3u8" in stream:
        Addon.play_generic(stream)
    else:
        dlg.ok(name, "Unable to get stream. Please try again later.")


def cspan_stream(url, name):
    Addon.play_generic(url)

##End Live News##

##Begin Pokemon Fire##
def pokemon_fire_seasons(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link, '<div class="imagen">(.*?)</li>')

    for entry in matches:
        name = Addon.find_single_match(entry, '/">(.+?)</a>', 1).encode('latin-1')
        description = Addon.find_single_match(entry, '<span class="date">(.+?)</span>')
        url = Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry, '<img src="(.+?)"')

        Addon.addLink(name, description, url, 501, iconimage)


def pokemon_fire_play(url):
    player_match_string = '<iframe class="metaframe rptss" src="(.*?)"'
    stream_match_string = 'file: \'(.*?)\''

    # Get Player
    req = Addon.open_url(url)
    player_url = Addon.find_single_match(req, player_match_string, 1)

    # Get Stream
    req = Addon.open_url(player_url)
    stream = Addon.find_single_match(req, stream_match_string)

    if 'mp4' in stream:
        Addon.play(stream)
    else:
        dlg.ok("TV Time Private", "Unable to get stream. Please try again later.")
##End Pokemon Fire##

# Start YouTube Playlist Channels #
def show_streams(title, playlist_id):
    if title in mode:
        streams = tvtime.TVtime().get_streams(playlist_id)
        if streams:
            for c in streams:
                title = c['title']
                channel = c['title']
                videoId = c['videoId']
                img = c['img']
                rURL = Addon.plugin_url + "?channel=" + channel + "&videoId=" + videoId + "&mode=play-youtube"
                Addon.add_video_item(rURL, {'title': title}, img=img)
# End YouTube Playlist Channels #

if mode == 'main':
    main_menu = tvtime.TVtime()._get_json('/menus/main' + base64.b64decode('LnBocA=='), {'key': access_key})
    main_menu_results = main_menu['results']
    for i in main_menu_results:
        if i['status'] == 'on':
            if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
            Addon.add_directory({'mode': i['mode']}, i['label'], img=icon)

    if len(Addon.get_setting('notify')) > 0:
        Addon.set_setting('notify', str(int(Addon.get_setting('notify')) + 1))
    else:
        Addon.set_setting('notify', "1")
    if int(Addon.get_setting('notify')) == 1:
        xbmcgui.Dialog().notification('Like ' + addonname + ' Private?', 'Keep it Private!', addon_logo, 5000, False)
    elif int(Addon.get_setting('notify')) == 9:
        Addon.set_setting('notify', "0")

##Begin ArconaiTV##
if mode == 'arconaitv':
    arconaitv_menu = tvtime.TVtime()._get_json('/menus/arconaitv' + base64.b64decode('LnBocA=='), {'key': access_key})
    arconaitv_menu_results = arconaitv_menu['results']
    for i in arconaitv_menu_results:
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg')))

if mode == 'arconaitv_live':
    channels = tvtime.TVtime().get_arconaitv_streams('Cable')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', c['img']))
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)

if mode == 'tv_show_channels':
    channels = tvtime.TVtime().get_arconaitv_streams('Shows')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = c['img']
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)

if mode == 'movie_channels':
    channels = tvtime.TVtime().get_arconaitv_streams('Movies')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)
##End ArconaiTV##

# Begin Live Channels#
if mode == 'catholic_tv':
    channels.Channel().play_catholic_tv()

if mode == 'charge':
    channels.Channel().play_charge()

if mode == 'comet':
    channels.Channel().play_comet()

if mode == 'tbd':
    channels.Channel().play_tbd()

if mode == 'tuff':
    channels.Channel().play_campfire(mode)

if mode == 'radiou':
    channels.Channel().play_campfire(mode)

if mode == 'spirit_tv':
    channels.Channel().play_campfire(mode)

if mode == 'hsn':
    channels.Channel().play_hsn()

if mode == 'pbs_kids':
    channels.Channel().play_pbs_kds()

if mode == 'qvc':
    channels.Channel().play_qvc()

if mode == 'tcn':
    channels.Channel().play_the_country_network()

if mode == 'revn':
    channels.Channel().play_revn_tv()

if mode == 'lighttv':
    channels.Channel.play_light_tv()

if mode == '247_retro':
    channels.Channel().play_247retro()

if mode == 'buzzr':
    channels.Channel().play_buzzr()

if mode == 'mlb_network':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nfl_now':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_network':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_arizona':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_bay':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_los':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_mountain':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_oregon':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_washington':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_bayarea':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_chicago':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_northwest':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_philly':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_phillyplus':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_cali':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_boston':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbc_golf':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'stadium':
    channels.Channel().play_stadium()
# End Live Channels#

# End Pokemon Fire #
if mode == 'pokemon_fire':
    Addon.addDir("Season 1", "", 'https://www.pokemonfire.com/seasons/pokemon-season-1/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg')
    Addon.addDir("Season 2", "", 'https://www.pokemonfire.com/seasons/pokemon-season-2/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/xQDFEDLKeNoMUblTCVHGdqDTZHh-185x278.jpg')
    Addon.addDir("Season 3", "", 'https://www.pokemonfire.com/seasons/pokemon-season-3/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/piTE2EIhMNeV1aHiTnq36tUc5eB-185x278.jpg')
    Addon.addDir("Season 4", "", 'https://www.pokemonfire.com/seasons/pokemon-season-4/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/yjAq5sILzVzIBfWtVLdxD8AEjGM-185x278.jpg')
    Addon.addDir("Season 5", "", 'https://www.pokemonfire.com/seasons/pokemon-season-5/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/4Tr6pjlKidQbSPp6wKf855Sq3L1-185x278.jpg')
    Addon.addDir("Season 6", "", 'https://www.pokemonfire.com/seasons/pokemon-season-6/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/1dNnm3ghzcnxM9M80NnBnDGmnZI-185x278.jpg')
    Addon.addDir("Season 7", "", 'https://www.pokemonfire.com/seasons/pokemon-season-7/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/mziBTfCtoeXTUAefm4hordE7OaQ-185x278.jpg')
    Addon.addDir("Season 8", "", 'https://www.pokemonfire.com/seasons/pokemon-season-8/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/kJ5s8pS0FkgqZvMvKz2dlEoZsqz-185x278.jpg')
    Addon.addDir("Season 9", "", 'https://www.pokemonfire.com/seasons/pokemon-season-9/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/6BDDH5EHiAHjfVGhi8FQc2xuDG0-185x278.jpg')
    Addon.addDir("Season 10", "", 'https://www.pokemonfire.com/seasons/pokemon-season-10/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/9abTHX6IcyiZAXiVDQMM5jKWQDy-185x278.jpg')
    Addon.addDir("Season 11", "", 'https://www.pokemonfire.com/seasons/pokemon-season-11/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/ny1FRSXWEtLCeevlCyq3DuVO4wF-185x278.jpg')
    Addon.addDir("Season 12", "", 'https://www.pokemonfire.com/seasons/pokemon-season-12/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/1vBe4qmVe3R5UBLocan15WFuIJk-185x278.jpg')
    Addon.addDir("Season 13", "", 'https://www.pokemonfire.com/seasons/pokemon-season-13/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/l5GEKuCEV27tKdZV42GWJT4i7m4-185x278.jpg')
    Addon.addDir("Season 14", "", 'https://www.pokemonfire.com/seasons/pokemon-season-14/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/kmfsJG0y9q6y27whVTs8PZWKq4L-185x278.jpg')
    Addon.addDir("Season 15", "", 'https://www.pokemonfire.com/seasons/pokemon-season-15/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/87N3UhDUIBSm2WtmqbJuPMzUDNx-185x278.jpg')
    Addon.addDir("Season 16", "", 'https://www.pokemonfire.com/seasons/pokemon-season-16/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/onYS1yKCej8QNjDamw7qUqmrtD-185x278.jpg')
    Addon.addDir("Season 17", "", 'https://www.pokemonfire.com/seasons/pokemon-season-17/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/Ac69nFUz9mTx6wDCHgxUucvAPph-185x278.jpg')
    Addon.addDir("Season 18", "", 'https://www.pokemonfire.com/seasons/pokemon-season-18/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/w7gdyFjkcJPEmjXe51Lzdd9NxoB-185x278.jpg')
    Addon.addDir("Season 19", "", 'https://www.pokemonfire.com/seasons/pokemon-season-19/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/hS4z6hh38C7WkbBzGIvicnYFvqp-185x278.jpg')
    Addon.addDir("Season 20", "", 'https://www.pokemonfire.com/seasons/pokemon-season-20/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/am5cZ8RVs3HkKGsST0MFuqvDsLh-185x278.jpg')
    Addon.addDir("Season 21", "", 'https://www.pokemonfire.com/seasons/pokemon-season-21/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg')

elif mode == 'refresh':
    xbmc.executebuiltin('Container.Refresh')
# End Pokemon Fire #

##Begin Play Functions##
elif mode == 'play_arconaitv':
    id = Addon.plugin_queries['id']
    r = requests.get('https://www.arconaitv.us/stream.php?id=' + id)
    html_text = r.text
    soup = BeautifulSoup(html_text, 'html.parser')
    scripts = soup.find_all('script')
    for script in scripts:
        if script.string is not None:
            if "document.getElementsByTagName('video')[0].volume = 1.0;" in script.string:
                code = script.string
                startidx = code.find('eval(function(p,a,c,k,e,')
                endidx = code.find('hunterobfuscator =')
                code = code[startidx: endidx]

                if not code.replace(' ', '').startswith('eval(function(p,a,c,k,e,'):
                    code = 'fail'
                break
            else:
                code = 'fail'
        else:
            code = 'fail'

    if code != 'fail':
        USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36'
        addon_handle = int(sys.argv[1])
        unpacked = packer.unpack(code)
        video_location = unpacked[unpacked.rfind('http'): unpacked.rfind('m3u8') + 4]
        play_item = xbmcgui.ListItem(path=video_location + '|User-Agent=%s' % urllib2.quote(USER_AGENT, safe=''))
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90004))

if mode == 'play-youtube':
    videoId = Addon.plugin_queries['videoId']
    stream_status = tvtime.TVtime()._get_json_u('/check' + base64.b64decode('LnBocA=='), {'id': videoId})['status']
    if stream_status == 'true':
        channels.play_youtube(videoId)
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(900024))
        exit()
##End Play Functions##

##Begin Live News##
elif mode == 'livenews_main':
    livenews_menu = tvtime.TVtime()._get_json('/menus/livenews' + base64.b64decode('LnBocA=='), {'key': access_key})
    livenews_menu_results = livenews_menu['results']
    for i in sorted(livenews_menu_results, reverse=False):
        if i['status'] == 'on' and i['label'] != 'France 24' and i['label'] != 'RT News':
            Addon.addLink_live(i['label'], "", i['url'], i['mode'], i['img'])
        elif i['status'] == 'on':
            Addon.add_video_item(
                'plugin://plugin.video.tvtime.private/?mode=' + i['mode'] + "&rand=" + Addon.random_generator(),
                {'title': i['label']}, img=i['img'], playable=True)
##End Live News##

##Begin Fluxus IPTV##
elif mode == 'fluxus_main':
    # Set protect flag.
    Addon.set_setting('protect', "true")

    fluxus_menu = tvtime.TVtime()._get_json('/menus/fluxus' + base64.b64decode('LnBocA=='), {'key': access_key})
    fluxus_menu_results = fluxus_menu['results']
    for i in fluxus_menu_results:
        if i['status'] == 'on':
            if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
            Addon.add_directory({'mode': i['mode']}, i['label'], img=icon)

    if Addon.get_setting('enable_adult_sections') == 'true':
        if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))):
            icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))
        else:
            icon = xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
        Addon.add_directory({'mode': "fluxus_lust"}, "Fluxus Lust", img=icon)

elif mode == 'fluxus_iptv':
    fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                            {'key': access_key, 'list': mode.replace("fluxus_","")})
    fluxus_menu_results = fluxus_menu

    # Get Updated Date
    for i in sorted(fluxus_menu_results):
        try:
            if "=" in i['tvtitle']:
                tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass

    # Get Streams
    for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
        try:
            if i['tvgroup'] == "USA" or \
                    i['tvgroup'] == "USA LOCAL" or \
                    i['tvgroup'] == "UK" or \
                    i['tvgroup'] == "CANADA" or \
                    i['tvgroup'] == "AUSTRALIA":
                tvtitle = json.dumps(i['tvtitle']).replace('"','')
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass

elif mode == 'fluxus_cctv' or mode == 'fluxus_faith' or mode == 'fluxus_lust':
    def get_fluxus():
        fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                                {'key': access_key, 'list': mode.replace("fluxus_", "")})
        fluxus_menu_results = fluxus_menu

        # Get Updated Date
        for i in sorted(fluxus_menu_results):
            try:
                if "=" in i['tvtitle']:
                    tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass

        # Get Streams
        for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
            try:
                if i['tvgroup'] != "INFO" and i['tvgroup'] != "LABEL":
                    tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass

    if mode == 'fluxus_lust':
        # Access Key Protection
        if str(Addon.get_setting('protect')) == 'true':
            retval = dlg.input(Addon.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            lock_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': retval})[
                'status']

            if lock_check == 'success':
                # Set protect flag. This will be set back to true once use 'backs out' of Fluxus Lust section.
                Addon.set_setting('protect', "false")

                dlg.ok(Addon.get_string(5000), Addon.get_string(900028))

                get_fluxus()

            else:
                dlg.ok(Addon.get_string(5000), Addon.get_string(80000))
                exit()

        elif str(Addon.get_setting('protect')) == 'false':
            get_fluxus()

    else:
        get_fluxus()

elif mode == 'fluxus_cinema':
    fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                            {'key': access_key, 'list': mode.replace("fluxus_","")})
    fluxus_menu_results = fluxus_menu
    for i in sorted(fluxus_menu_results, reverse=False):
        try:
            if i['tvgroup'] == "MOVIES" or "=" in i['tvtitle']:
                if "=" in i['tvtitle']:
                    tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                else:
                    tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass
##End Fluxus IPTV##

##End Lodge TV IPTV##
elif mode == 'lodge_tv_main':
    stratustv_menu = tvtime.TVtime()._get_json('/lodgetv/v1/get_list' + base64.b64decode('LnBocA=='),
                                               {'key': access_key, 'list': 'english'})
    stratustv_menu_results = stratustv_menu

    # Get Updated Date
    for i in sorted(stratustv_menu_results):
        if "~" not in i['tvtitle'] and "=" in i['tvtitle']:
            tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
            img = i['tvlogo']

            Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)

    # Get Streams
    for i in sorted(stratustv_menu_results, key=lambda k: k['tvtitle']):
        if "~" not in i['tvtitle'] and "=" not in i['tvtitle'] and ">" not in i['tvtitle']:
            img = i['tvlogo']

            Addon.addLink_live(i['tvtitle'], '', i['tvmedia'], 400, img)
##End Lodge TV IPTV##

##End Stratus TV IPTV##
elif mode == 'stratus_tv_main':
    stratustv_menu = tvtime.TVtime()._get_json('/stratustv/v1/get_list' + base64.b64decode('LnBocA=='),
                                               {'key': access_key, 'list': 'english'})
    stratustv_menu_results = stratustv_menu
    for i in sorted(stratustv_menu_results, key=lambda k: k['tvtitle']):
        try:
            tvtitle = json.dumps(i['tvtitle']).replace('"', '')
            img = i['tvlogo']
            Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass
##End Stratus TV IPTV##

##Begin Live TV Direct##
elif mode == 'livetv_direct_main':
    livetv_direct_menu = tvtime.TVtime()._get_json('/menus/livetv_direct' + base64.b64decode('LnBocA=='),
                                                   {'key': access_key})
    livetv_direct_menu_results = livetv_direct_menu['results']
    for i in livetv_direct_menu_results:
        if i['status'] == 'on':
            Addon.add_video_item(
                'plugin://plugin.video.tvtime.private/?mode=' + i['mode'] + "&rand=" + Addon.random_generator(),
                {'title': i['label']}, img=xbmc.translatePath(
                    os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.png')),
                playable=True)
##End Live TV Direct##

##Begin Live Sports Direct##
elif mode == 'livesports_direct_main':
    livesports_direct_menu = tvtime.TVtime()._get_json('/menus/livesports_direct' + base64.b64decode('LnBocA=='),
                                                       {'key': access_key})
    livesports_direct_menu_results = livesports_direct_menu['results']
    for i in livesports_direct_menu_results:
        if i['status'] == 'on':
            if "nbcs" in i['mode']:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'nbc_sports.jpg'))
            elif "pac" in i['mode']:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'pac_12.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.jpg'))
            Addon.add_video_item(
                'plugin://plugin.video.tvtime.private/?mode=' + i['mode'] + "&rand=" + Addon.random_generator(),
                {'title': i['label']}, img=icon, playable=True)
##End Live Sports Direct##

# Begin YouTube Channels #
elif mode == 'youtube_channels':
    youtube_channels_menu = tvtime.TVtime()._get_json('/menus/youtube_channels' + base64.b64decode('LnBocA=='),
                                                      {'key': access_key})
    youtube_channels_menu_results = youtube_channels_menu['results']
    for i in youtube_channels_menu_results:
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.jpg')))

elif mode == 'biography_channel':
    try:
        playlists = tvtime.TVtime().build_biograpy_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'BIOCHANNEL'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "BIOCHANNEL" in mode:
    playlists = tvtime.TVtime().build_biograpy_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'ufo_tv':
    try:
        playlists = tvtime.TVtime().build_ufo_tv_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'UFOTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "UFOTV" in mode:
    playlists = tvtime.TVtime().build_ufo_tv_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'blr':
    try:
        playlists = tvtime.TVtime().build_blr_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'BLRTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "BLRTV" in mode:
    playlists = tvtime.TVtime().build_blr_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'funnyordie':
    try:
        playlists = tvtime.TVtime().build_funnyordie_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'FUNNYORDIETV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "FUNNYORDIETV" in mode:
    playlists = tvtime.TVtime().build_funnyordie_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'joy_of_painting':
    try:
        playlists = tvtime.TVtime().build_joy_of_painting_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'JOYOFPAINTINGTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "JOYOFPAINTINGTV" in mode:
    playlists = tvtime.TVtime().build_joy_of_painting_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'last_week_tonight':
    try:
        playlists = tvtime.TVtime().build_last_week_tonight_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'LASTWEEKTONIGHTTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "LASTWEEKTONIGHTTV" in mode:
    playlists = tvtime.TVtime().build_last_week_tonight_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'mr_bean':
    try:
        playlists = tvtime.TVtime().build_mr_bean_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MRBEANTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MRBEANTV" in mode:
    playlists = tvtime.TVtime().build_mr_bean_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'soul_pancake':
    try:
        playlists = tvtime.TVtime().build_soul_pancake_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'SOULPANCAKETV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "SOULPANCAKETV" in mode:
    playlists = tvtime.TVtime().build_soul_pancake_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'thomas_the_train':
    try:
        playlists = tvtime.TVtime().build_thomas_the_train_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'THOMASTHETRAINTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "THOMASTHETRAINTV" in mode:
    playlists = tvtime.TVtime().build_thomas_the_train_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'missouri_star':
    try:
        playlists = tvtime.TVtime().build_missouri_star()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MISSOURISTARTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MISSOURISTARTV" in mode:
    playlists = tvtime.TVtime().build_missouri_star()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'maverick_movies':
    try:
        playlists = tvtime.TVtime().build_maverick_movies()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MAVERICKMOVIESTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MAVERICKMOVIESTV" in mode:
    playlists = tvtime.TVtime().build_maverick_movies()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])
# End YouTube Channels #

elif mode == 'settings':
    Addon.show_settings()

# Begin TubiTV #
md = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'media', '\\/'))

MUA = 'Mozilla/5.0 (Linux; Android 5.0.2; bg-bg; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19'
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:62.0) Gecko/20100101 Firefox/62.0'


def tubi_categories():
    req = urllib2.Request('http://tubitv.com/oz/containers/')
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'https://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())

    # addDirTubi('Search', 'http://tubitv.com/oz/search/', 'Search Tubi TV', 2, md + 'DefaultAddonsSearch.png')
    try:
        for categories in range(0, len(jsonrsp['list'])):
            try:
                desc = jsonrsp['hash'][jsonrsp['list'][categories]]['description'].decode('utf8', 'ignore').encode(
                    'utf8', 'ignore')
            except:
                desc = ' '
            try:
                Cover = 'http:' + jsonrsp['hash'][jsonrsp['list'][categories]]['thumbnail']
            except:
                Cover = md + 'DefaultFolder.png'
            addDirTubi(jsonrsp['hash'][jsonrsp['list'][categories]]['title'], jsonrsp['list'][categories], desc, 1,
                       Cover)
    except:
        pass


def tubi_index(url):
    try:
        req = urllib2.Request('http://tubitv.com/oz/containers/' + url + '/content?cursor=1&limit=200')
        req.add_header('User-Agent', UA)
        req.add_header('Referer', 'https://tubitv.com/')
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        # print jsonrsp

        for movie in jsonrsp['contents'].keys():
            try:
                if jsonrsp['contents'][movie]['type'] == 'v':
                    try:
                        addLinkTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'],
                                    str(jsonrsp['contents'][movie]['duration']),
                                    jsonrsp['contents'][movie]['description'].decode('utf8', 'ignore').encode('utf8',
                                                                                                              'ignore'),
                                    jsonrsp['contents'][movie]['year'],
                                    jsonrsp['contents'][movie]['ratings'][0]['value'],
                                    jsonrsp['contents'][movie]['actors'], jsonrsp['contents'][movie]['directors'], 3,
                                    'http:' + jsonrsp['contents'][movie]['posterarts'][0])
                    except:
                        addLinkTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'],
                                    str(jsonrsp['contents'][movie]['duration']), '', jsonrsp['contents'][movie]['year'],
                                    jsonrsp['contents'][movie]['ratings'][0]['value'],
                                    jsonrsp['contents'][movie]['actors'], jsonrsp['contents'][movie]['directors'], 3,
                                    'http:' + jsonrsp['contents'][movie]['posterarts'][0])
                elif jsonrsp['contents'][movie]['type'] == 's':
                    try:
                        addDirTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'],
                                   jsonrsp['contents'][movie]['description'].decode('utf8', 'ignore').encode('utf8',
                                                                                                             'ignore'),
                                   4, 'http:' + jsonrsp['contents'][movie]['posterarts'][0])
                    except:
                        addDirTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'], '', 4,
                                   'http:' + jsonrsp['contents'][movie]['posterarts'][0])
            except:
                pass
            xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
    except:
        xbmcgui.Dialog().ok('Tubi TV', 'This is geo-blocked content!',
                            'You must have USA IP address in order to access this content or services.')


def tubi_search_content(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'http://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())

    for movie in range(0, len(jsonrsp)):
        try:
            if jsonrsp[movie]['type'] == 'v':
                addLinkTubi(jsonrsp[movie]['title'], jsonrsp[movie]['id'], str(jsonrsp[movie]['duration']),
                            jsonrsp[movie]['description'].decode('utf8', 'ignore').encode('utf8', 'ignore'),
                            jsonrsp[movie]['year'], jsonrsp[movie]['ratings'][0]['value'], jsonrsp[movie]['actors'],
                            jsonrsp[movie]['directors'], 3, 'http:' + jsonrsp[movie]['posterarts'][0])
            elif jsonrsp[movie]['type'] == 's':
                addDirTubi(jsonrsp[movie]['title'], jsonrsp[movie]['id'],
                           jsonrsp[movie]['description'].decode('utf8', 'ignore').encode('utf8', 'ignore'), 4,
                           'http:' + jsonrsp[movie]['posterarts'][0])
        except:
            pass
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)


def tubi_episodes(url):
    req = urllib2.Request('http://tubitv.com/oz/videos/0' + url + '/content')
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'http://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())
    # print jsonrsp['k'][0]

    for season in range(0, len(jsonrsp['children'])):
        for episode in range(0, len(jsonrsp['children'][season]['children'])):
            try:
                addLinkTubi(jsonrsp['children'][season]['children'][episode]['title'],
                            jsonrsp['children'][season]['children'][episode]['id'],
                            str(jsonrsp['children'][season]['children'][episode]['duration']),
                            jsonrsp['children'][season]['children'][episode]['description'].decode('utf8',
                                                                                                   'ignore').encode(
                                'utf8', 'ignore'), jsonrsp['children'][season]['children'][episode]['year'],
                            jsonrsp['children'][season]['children'][episode]['ratings'][0]['value'],
                            jsonrsp['children'][season]['children'][episode]['actors'],
                            jsonrsp['children'][season]['children'][episode]['directors'], 3,
                            'http:' + jsonrsp['children'][season]['children'][episode]['thumbnails'][0])
            except:
                pass


def tubi_search(url):
    keyb = xbmc.Keyboard('', 'Search Tubi TV')
    keyb.doModal()
    searchText = ''
    if (keyb.isConfirmed()):
        searchText = urllib.quote_plus(keyb.getText())
        searchText = searchText.replace(' ', '+')
        if searchText == '':
            exit()
            xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.tvtime.private/?mode=tubitv)")
        searchurl = url + searchText
        searchurl = searchurl.encode('utf-8')
        tubi_search_content(searchurl)
    else:
        exit()
        xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.tvtime.private/?mode=tubitv)")


def tubi_play(name, url):
    req = urllib2.Request('http://tubitv.com/oz/videos/' + url + '/content')
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'http://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())

    li = xbmcgui.ListItem(iconImage='http:' + jsonrsp['thumbnails'][0],
                          thumbnailImage='http:' + jsonrsp['thumbnails'][0],
                          path='http:' + jsonrsp['url'] + '|User-Agent=stagefright&Referer=http://tubitv.com')
    li.setInfo(type="Video", infoLabels={"Title": name, "Plot": jsonrsp[
        'description']})  # .decode('utf8', 'ignore').encode('utf8', 'ignore')
    try:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    except:
        xbmc.executebuiltin("Notification('Tubi TV','Video Not Found!')")


    xbmc.Player().showSubtitles(False)


def addLinkTubi(name, url, vd, plot, year, mpaa, cast, director, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setArt({'thumb': iconimage, 'poster': iconimage, 'banner': iconimage, 'fanart': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setInfo(type="Video", infoLabels={"Duration": vd, "Plot": plot})
    liz.setInfo(type="Video", infoLabels={"Year": year, "Mpaa": mpaa})
    liz.setInfo(type="Video", infoLabels={"Cast": cast, "Director": director})
    liz.addStreamInfo('video', {'aspect': 1.78, 'codec': 'h264'})
    liz.addStreamInfo('audio', {'codec': 'aac', 'channels': 2})
    liz.setProperty("IsPlayable", "true")
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok


def addDirTubi(name, url, desc, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": desc})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
# End Tubi TV #


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()
if mode != 'tubitv':
    url = 'null'
else:
    url = None
name = None
mode = None
iconimage = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    name = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

##This is for the Tubi TV stuff##
if mode == 'tubitv' or url == None or len(url) < 1:
    tubi_categories()

##This is for the TubiTV stuff##
elif mode == 1:
    tubi_index(url)

##This is for the TubiTV stuff##
elif mode == 2:
    tubi_search(url)

##This is for the TubiTV stuff##
elif mode == 3:
    tubi_play(name, url)

##This is for the TubiTV stuff##
elif mode == 4:
    tubi_episodes(url)

##These are for the Live News Streams##
elif mode == 100:
    livenews_stream(url, name)
elif mode == 101:
    channels.Channel().play_cbs_news()
elif mode == 102:
    channels.Channel().play_newsy()
elif mode == 103:
    channels.Channel().play_sky_news()
elif mode == 104:
    channels.Channel().play_aljazeera()
elif mode == 105:
    cnn_stream(url, name)
elif mode == 106:
    foxnews_stream(url, name)
elif mode == 107:
    msnbc_stream(url, name)
elif mode == 108:
    channels.Channel().play_cheddar()
elif mode == 110:
    channels.Channel().play_rt()
elif mode == 111:
    channels.Channel().play_newsmax_tv()
elif mode == 112:
    cspan_stream(url, name)
elif mode == 113:
    cspan_stream(url, name)

##Fluxus, Lodge TV, and Stratus TV IPTV##
elif mode == 400:
    Addon.play_generic(url)

elif mode == 500:
    pokemon_fire_seasons(url)

elif mode == 501:
    pokemon_fire_play(url)

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass
try:
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:
    group = urllib.unquote_plus(params["group"])
except:
    pass


Addon.end_of_directory()
