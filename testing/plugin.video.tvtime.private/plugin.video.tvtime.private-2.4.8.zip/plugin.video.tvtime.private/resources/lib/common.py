"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import cgi
import os
import random
import re
import string
import sys
import urllib
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests

reload(sys)
sys.setdefaultencoding('utf8')

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')
ICON = os.path.join(plugin_path, 'icon.png')
FANART = os.path.join(plugin_path, 'fanart.jpg')
dlg = xbmcgui.Dialog()
dlg_progress = xbmcgui.DialogProgress()
stream_failed = "Unable to get stream. Please try again later."
oops = "Oops something went wrong. Please try again."


def dlg_stream_failed(mode):
    dlg.ok(mode, stream_failed)
    exit()


def dlg_oops(mode):
    dlg.ok(mode, oops)
    exit()


def get_setting(setting):
    return addon.getSetting(setting)


def set_setting(setting, string):
    return addon.setSetting(setting, string)


def exists_url(path):
    r = requests.head(path)
    return r.status_code == requests.codes.ok


def exists_local(path):
    return os.path.isfile(path)


def is_non_zero_file(path):
    return os.path.getsize(path) > 0


def get_string(string_id):
    return addon.getLocalizedString(string_id)


def add_video_item(url, infolabels, img=ICON, fanart=FANART, total_items=0,
                   cm=[], cm_replace=False, HD='Low', playable=True):
    infolabels = decode_dict(infolabels)
    if url.find('://') == -1:
        url = build_plugin_url({'play': url})
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img,
                                thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    if playable:
        listitem.setProperty('IsPlayable', 'true')
    else:
        listitem.setProperty('IsPlayable', 'false')
    listitem.setArt({'fanart': fanart, 'icon': img})
    if HD == 'High':
        listitem.addStreamInfo('video', {'width': 1280, 'height': 720})
    if HD == 'Medium':
        listitem.addStreamInfo('video', {'width': 640, 'height': 480})
    else:
        listitem.addStreamInfo('video', {'width': 600, 'height': 320})
    if cm:
        listitem.addContextMenuItems(cm, cm_replace)
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem,
                                isFolder=False, totalItems=total_items)


def add_directory(url_queries, title, img=ICON, fanart=FANART, total_items=0):
    url = build_plugin_url(url_queries)
    listitem = xbmcgui.ListItem(decode(title), iconImage=img, thumbnailImage=img)
    if not fanart:
        fanart = addon.getAddonInfo('path') + '/fanart.jpg'
    listitem.setProperty('fanart_image', fanart)
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem,
                                isFolder=True, totalItems=total_items)


def end_of_directory():
    xbmcplugin.endOfDirectory(plugin_handle, cacheToDisc=False)


def build_query(queries):
    return '&'.join([k + '=' + urllib.quote(str(v)) for (k, v) in queries.items()])


def build_plugin_url(queries):
    url = plugin_url + '?' + build_query(queries)
    return url


def parse_query(query, clean=True):
    queries = cgi.parse_qs(query)
    q = {}
    for key, value in queries.items():
        q[key] = value[0]
    if clean:
        q['mode'] = q.get('mode', 'main')
        q['play'] = q.get('play', '')

    return q


def show_settings():
    addon.openSettings()
    # workaround to return to main section. silent error is thrown
    exit()


# http://stackoverflow.com/questions/1208916/decoding-html-entities-with-python/1208931#1208931
def _callback(matches):
    id = matches.group(1)
    try:
        return unichr(int(id))
    except:
        return id


def decode(data):
    return re.sub("&#(\d+)(;|(?=\s))", _callback, data).strip()


def decode_dict(data):
    for k, v in data.items():
        if type(v) is str or type(v) is unicode:
            data[k] = decode(v)
    return data


def random_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for x in range(size))


def add_link(name, description, url, mode, iconimage):
    cm = [(get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (plugin_url))]
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty('fanart_image', addon.getAddonInfo('path') + '/fanart.jpg')
    liz.setProperty("IsPlayable", "true")
    liz.addContextMenuItems(cm, 1)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok


def addlink_live(name, description, url, mode, iconimage):
    cm = [(get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (plugin_url))]
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
        name) + "&rand=" + random_generator()
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty('fanart_image', addon.getAddonInfo('path') + '/fanart.jpg')
    liz.setProperty("IsPlayable", "true")
    liz.addContextMenuItems(cm, 1)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok


def add_dir(name, description, url, mode, iconimage):
    cm = [(get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (plugin_url))]
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
        name) + "&iconimage=" + urllib.quote_plus(iconimage)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty('fanart_image', addon.getAddonInfo('path') + '/fanart.jpg')
    liz.addContextMenuItems(cm, 1)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


# Parse string and extracts multiple matches using regular expressions
def find_multiple_matches(text, pattern):
    matches = re.findall(pattern, text, re.DOTALL)

    return matches


# Parse string and extracts first match as a string
def find_single_match(text, pattern, number=0):
    result = ""
    try:
        matches = re.findall(pattern, text, flags=re.DOTALL)
        result = matches[number]
    except:
        result = ""

    return result
