"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
import urllib
import urllib2
import common
import base64
import m7lib


class TVtime:

    def __init__(self):
        self.BASE = base64.b64decode('aHR0cHM6Ly90dnRpbWUudmVsdmV0aG90ZG9nLmNvbS9hcGkv')
        self.access_key = str(common.get_setting('access_key'))

        # Begin Xumo TV & Movies #
        self.XUMO_BASE_API = 'https://valencia-app-mds.xumo.com/v2/%s'
        self.XUMO_BASE_LOGO = 'https://image.xumo.com/v1/channels/channel/%s/512x512.png?type=color_onBlack'
        self.XUMO_BASE_THUMB = 'https://image.xumo.com/v1/assets/asset/%s/512x512.jpg'
        # End Xumo TV & Movies #

    # Begin ArconaiTV #
    def get_arconaitv_streams(self, type):
        content = self._get_json('/arconaitv/v1/get_streams' + base64.b64decode('LnBocA=='),
                                 {'key': self.access_key, 'type': type, 'rand': common.random_generator()})
        channels = []
        results = content['results']
        if results:
            for i in results:
                channels.append({
                    'id': i['id'],
                    'channel': i['channel'],
                    'img': i['img']

                })
            return channels
        else:
            common.dlg.ok(common.get_string(5000), common.get_string(90004))
            exit()

    def get_link_arconaitv(self, id):
        content = self._get_json('/arconaitv/v1/get_stream' + base64.b64decode('LnBocA=='),
                                 {'key': self.access_key, 'id': id, 'rand': common.random_generator()})
        channels = []
        results = content['results']
        if results:
            for i in results:
                channels.append({
                    'url': i['stream']
                })
            return channels
        else:
            common.dlg.ok(common.get_string(5000), common.get_string(90004))
            exit()
    # End ArconaiTV #

    # Begin Pokemon Fire #
    def pokemon_fire_seasons(self, url):
        link = m7lib.Common.open_url(url)
        matches = common.find_multiple_matches(link, '<div class="imagen">(.*?)</li>')

        for entry in matches:
            name = common.find_single_match(entry, '/">(.+?)</a>', 1).encode('latin-1')
            description = common.find_single_match(entry, '<span class="date">(.+?)</span>')
            url = common.find_single_match(entry, '<a href="(.+?)"')
            iconimage = common.find_single_match(entry, '<img src="(.+?)"')

            common.add_link(name, description, url, 501, iconimage)

    def pokemon_fire_play(self, url):
        player_match_string = '<iframe class="metaframe rptss" src="(.*?)"'
        stream_match_string = 'file: \'(.*?)\''

        # Get Player
        req = m7lib.Common.open_url(url)
        player_url = common.find_single_match(req, player_match_string, 1)

        # Get Stream
        req = m7lib.Common.open_url(player_url)
        stream = common.find_single_match(req, stream_match_string)

        if 'mp4' in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg.ok("TV Time Private", "Unable to get stream. Please try again later.")
    # End Pokemon Fire #

    # Begin YouTube Channels #
    def get_youtube_channels(self):
        try:
            youtube_channels = []
            youtube_channels_list = self._get_json('/menus/youtube_channels' + base64.b64decode('LnBocA=='),
                                                              {'key': self.access_key})
            youtube_channels_list_results = youtube_channels_list['results']

            for i in youtube_channels_list_results:
                youtube_channels.append(i["mode"])
            return youtube_channels
        except:
            common.dlg_oops(common.addonname)

    def get_youtube_streams(self, playlist_id):
        try:
            content = self._get_json('/ytpowered/v1/get_streams' + base64.b64decode('LnBocA=='), {'id': playlist_id})
            streams = []
            results = content['results']
            for i in results:
                if "Movie Trailer" not in i['title'] and \
                        "trailer" not in i['title'] and \
                        "trailer" not in i['title'] and \
                        "Trailer" not in i['title'] and \
                        "Coming Soon" not in i['title'] and \
                        "Coming soon" not in i['title'] and \
                        "coming Soon" not in i['title'] and \
                        "Watch Maverick Movies" not in i['title']:
                    title = i['title']
                    streams.append({
                        'channel': i['title'],
                        'title': title,
                        'videoId': i['id'],
                        'img': i['img']
                    })

            return streams
        except:
            common.dlg_oops(common.addonname)

    def show_youtube_streams(self, title, playlist_id, mode):
        try:
            if title in mode:
                streams = self.get_youtube_streams(playlist_id)
                if streams:
                    for c in streams:
                        title = c['title']
                        channel = c['title']
                        videoId = c['videoId']
                        img = c['img']
                        rURL = common.plugin_url + "?channel=" + channel + "&videoId=" + videoId + "&mode=play-youtube"
                        common.add_video_item(rURL, {'title': title}, img=img)
        except:
            common.dlg_oops(common.addonname)

    def build_youtube_main(self, mode):
        try:
            content = self._get_json('/ytpowered/v1/get_playlists' + base64.b64decode('LnBocA=='),
                                     {'mode': mode})
            playlists = []
            results = content['results']
            for i in results:
                if "Trailer" not in i['title'] and \
                        "My Top Videos" not in i['title'] and \
                        "420 STONER MOVIES" not in i['title'] and \
                        "TRAILER" not in i['title'] and \
                        "Indie Scene" not in i['title'] and \
                        "TERRIFYING THURSDAYS" not in i['title'] and \
                        "For Rent" not in i['title'] and \
                        "Buzz Extras" not in i['title'] and \
                        "After Dark Double Features" not in i['title'] and \
                        "Geek Week" not in i['title'] and \
                        "Maverick On The Oscars" not in i['title'] and \
                        "for Rent" not in i['title'] and \
                        "Meet The Actors" not in i['title'] and \
                        "Weekly Updates" not in i['title'] and \
                        "Teasers" not in i['title'] and "2012 MAVERICK RELEASES" not in i['title']:
                    playlists.append({
                        'channel': i['title'],
                        'title': i['title'],
                        'playlist_id': i['playlist_id'],
                        'img': i['img']
                    })
            return playlists
        except:
            common.dlg_oops(common.addonname)
    # End YouTube Channels #

    # Begin Base Functions #
    def _build_url(self, path, queries={}):
        if queries:
            query = common.build_query(queries)
            return '%s/%s?%s' % (self.BASE, path, query)
        else:
            return '%s/%s' % (self.BASE, path)

    def _build_json(self, path, queries={}):
        if queries:
            query = urllib.urlencode(queries)
            return '%s/%s?%s' % (self.BASE, path, query)
        else:
            return '%s/%s' % (self.BASE, path)

    def _fetch(self, url, form_data=False):
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]
        if form_data:
            req = urllib2.Request(url, form_data)
        else:
            req = url
        try:
            response = opener.open(req)
            return response
        except urllib2.URLError, e:
            return False

    def _get_json(self, path, queries={}):
        content = False
        url = self._build_json(path, queries)
        response = self._fetch(url)
        if response:
            content = json.loads(response.read())
        else:
            content = False
        return content

    def _get_html(self, path, queries={}):
        html = False
        url = self._build_url(path, queries)

        response = self._fetch(url)
        if response:
            html = response.read()
        else:
            html = False
        return html
    # End Base Functions #
