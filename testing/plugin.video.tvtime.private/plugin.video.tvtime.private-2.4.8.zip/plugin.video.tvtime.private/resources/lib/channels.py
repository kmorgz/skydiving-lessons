"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import xbmcaddon
import xbmcplugin
import xbmcgui
import sys
import os
import common
import tvtime
import m7lib

access_key = str(common.get_setting('access_key'))


def get_channel_logo(channel):
    return os.path.join(common.plugin_path, 'resources', 'images', 'logos', channel + '.png')


def play_youtube(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


class Channel():

    def __init__(self):
        # Begin Live TV Direct #
        self.free_live_tv_extra_channels = [
            {"name": "ABC News", "type": "News"},
            {"name": "CBSN", "type": "News"},
            {"name": "CBSN New York", "type": "News"},
            {"name": "CBS Sports HQ", "type": "Sports"},
            {"name": "CNN", "type": "News"},
            {"name": "ET Live", "type": "Celebrity"},
            {"name": "FOX News", "type": "News"},
            {"name": "FX", "type": "Comedy, Thriller, Movies"},
            {"name": "FOX Business", "type": "News"},
            {"name": "MSNBC", "type": "News"},
            {"name": "The Weather Channel", "type": "News"},
            {"name": "Starz", "type": "Movies"},
            {"name": "USA Network", "type": "Comedy, Movies"},
            {"name": "SYFY", "type": "Sci-Fi"},
            {"name": "BBC America", "type": "Special Interest"},
            {"name": "PBS", "type": "Special Interest"},
            {"name": "National Geographic", "type": "Curiosity"},
            {"name": "Nat Geo Wild", "type": "Curiosity"},
            {"name": "Animal Planet", "type": "Curiosity"},
            {"name": "Comedy Central", "type": "Comedy"},
            {"name": "Freeform", "type": "Family"},
            {"name": "Lifetime", "type": "Lifestyle, Movies"},
            {"name": "Food Network", "type": "Lifestyle"},
            {"name": "TLC", "type": "Curiosity"},
            {"name": "Travel Channel", "type": "Curiosity, Lifestyle"},
            {"name": "Bravo", "type": "Lifestyle"},
            {"name": "TV Land", "type": "Retro, Comedy"},
            {"name": "TBS", "type": "Comedy, Movies"},
            {"name": "NBC Golf", "type": "Sports"},
            {"name": "NFL Network", "type": "Sports"},
            {"name": "NBC Sports", "type": "Sports"},
            {"name": "A&E", "type": "Movies"},
            {"name": "Hallmark Movies & Mysteries", "type": "Family, Retro, Movies"},
            {"name": "Hallmark Channel", "type": "Family, Retro, Movies"},
            {"name": "Disney Channel", "type": "Family, Kids"},
            {"name": "Investigation Discovery", "type": "Crime, Curiosity"},
            {"name": "Nickelodeon", "type": "Kids"},
            {"name": "Cartoon Network", "type": "Kids"},
            {"name": "The CW", "type": "Network TV"},
            {"name": "HGTV", "type": "Lifestyle"},
            {"name": "AMC", "type": "Movies"},
            {"name": "Discovery Channel", "type": "Curiosity"},
            {"name": "History", "type": "Curiosity"},
            {"name": "ABC", "type": "Network TV"},
            {"name": "NBC", "type": "Network TV"},
            {"name": "FOX", "type": "Network TV"},
        ]
        # End Live TV Direct #

    @staticmethod
    def get_genres():
        genres = m7lib.Common.get_genres()
        genres.append("Network TV")
        return  genres

    @staticmethod
    def play_abc_news(mode):
        try:
            link = m7lib.Common.open_url("https://www.livenewson.com/american/abc-news-2.html")
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, 'file: "(.+?)"'))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_news(mode):
        try:
            site_url = "https://www.cbsnews.com/live/"
            match_string = '"contentUrl":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_news_ny(mode):
        try:
            site_url = "https://www.cbsnews.com/live/cbsn-local-ny/"
            match_string = '"video":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_sports_hq(mode):
        try:
            site_url = "https://www.cbsnews.com/live/cbs-sports-hq/"
            match_string = '"video":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_et_live(mode):
        try:
            site_url = "https://www.cbsnews.com/live/et-live/"
            match_string = '"video":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_ustvgo(mode, slug):
        try:
            url = "http://ustvgo.net/" + slug
            link = m7lib.Common.open_url(url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, "file: '(.+?)'"))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)