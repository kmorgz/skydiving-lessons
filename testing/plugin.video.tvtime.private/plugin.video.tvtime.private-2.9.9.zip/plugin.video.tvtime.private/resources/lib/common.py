"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import requests
import base64
import json
import m7lib
try:
    # Python 3
    from urllib.parse import parse_qs
except ImportError:
    # Python 2
    from urlparse import parse_qs

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')
ICON = os.path.join(plugin_path, 'icon.png')
FANART = os.path.join(plugin_path, 'fanart.jpg')
SKIN_PATH = os.path.join(plugin_path, 'resources', 'images', 'skin', 'default')
GENRE_PATH = os.path.join(plugin_path, 'resources', 'images', 'genres')
dlg = xbmcgui.Dialog()
dlg_progress = xbmcgui.DialogProgress()
dlg_progressBG = xbmcgui.DialogProgressBG()


class TVTime:
    def __init__(self):
        self.access_key = str(get_setting('access_key'))
        self.BASE = base64.b64decode('aHR0cHM6Ly90dnRpbWUuZGV2L2FwaS8=')
        self.OPL_BASE_TITLE = base64.b64decode('aHR0cHM6Ly9hcGkub2RiLnRvL2VtYmVkP3RpdGxlPQ==')
        self.OPL_BASE_IMDB = base64.b64decode('aHR0cHM6Ly9hcGkub2RiLnRvL2VtYmVkP2ltZGJfaWQ9')
        self.OPL_BASE_JSON = base64.b64decode('aHR0cHM6Ly9qc29uLnZwbm1hdGUuY29tLw==')
        self.plugin_url = sys.argv[0]
        self.plugin_handle = int(sys.argv[1])
        self.plugin_queries = parse_query(sys.argv[2][1:])

    def check_access_key(self, access_key):
        key_check_url = self.BASE + "/check_key" + base64.b64decode('LnBocA==') + "?key=" + access_key
        return json.loads(m7lib.Common.open_url(key_check_url))['status']


def location_check():
    try:
        url = "http://ip-api.com/json/"
        req = m7lib.Common.open_url(url)
        country_code = json.loads(req)["countryCode"]
    except StandardError:
        country_code = "US"
    return country_code


def get_location():
    if get_setting("geo") == "OZ" or get_setting("geo") == "" or int(get_setting("geo_check")) > 1000:
        set_setting("geo", location_check())
        set_setting("geo_check", str(0))

    set_setting("geo_check", str(int(get_setting("geo_check")) + 1))
    return get_setting("geo")


def reset_location():
    set_setting("geo", location_check())
    set_setting("geo_check", str(0))
    dlg.ok(addonname, get_string(40003))
    exit()


def get_section_logo(section):
    icon = os.path.join(SKIN_PATH + "/" + section + '.png')
    if os.path.isfile(icon):
        return icon
    return ICON


def dlg_stream_failed(heading):
    dlg.ok(heading, get_string(100000), " ", get_string(100005))
    exit()


def dlg_oops(heading):
    dlg.ok(heading, get_string(100001), " ", get_string(100005))
    exit()


def get_setting(setting):
    return addon.getSetting(setting)


def set_setting(setting, string):
    return addon.setSetting(setting, string)


def exists_url(path):
    r = requests.head(path)
    return r.status_code == requests.codes.ok


def exists_local(path):
    return os.path.isfile(path)


def is_non_zero_file(path):
    return os.path.getsize(path) > 0


def get_string(string_id):
    return addon.getLocalizedString(string_id)


def parse_query(query, clean=True):
    queries = parse_qs(query)

    q = {}
    for key, value in queries.items():
        q[key] = value[0]
    if clean:
        q['mode'] = q.get('mode', 'main')
    return q


def show_settings():
    addon.openSettings()
    exit()


def clean_channel_name(channel):
    channel = channel.replace("Live", "") \
        .replace("LIVE", "") \
        .replace(" Free", "")\
        .replace("Streaming", "") \
        .replace(" Stream", "") \
        .replace("Networks", "") \
        .replace("HD", "") \
        .replace("#038;", "") \
        .replace("Tv", "").replace("?", "") \
        .replace("NASA", "NASA TV") \
        .replace("Fox", "FOX") \
        .replace("Fox", "FOX") \
        .replace("FOX Channel", "FOX") \
        .replace("FOX Business Network", "FOX Business") \
        .replace("Golf Channel", "NBC Golf") \
        .replace("Syfy Channel", "Syfy") \
        .replace("Bravo Channel", "Bravo") \
        .replace("FX Channel", "FX") \
        .replace("Lifetime Channel", "Lifetime") \
        .replace("History Channel", "History") \
        .replace("Starz Channel", "Starz") \
        .replace("Freeform Channel", "Freeform") \
        .replace("TBS Channel", "TBS") \
        .replace("FX Channel", "FX") \
        .replace("History Channel", "History") \
        .replace("ESPN Channel", "ESPN") \
        .replace("The Weather Channel", "Weather Channel") \
        .replace("Weather Channel", "The Weather Channel") \
        .replace("One America News Network", "OAN") \
        .replace("Sports", "Sky Sports") \
        .strip()
    return channel


def set_channel_genre(channel):
    news_channels = ["News", "CNBC", "CNN", "OAN", "FOX News", "FOX Business", "The Weather Channel", "MSNBC", "BBC News", "BBC Parliament"]
    sports_channels = ["Sports", "ESPN", "ESPN2", "NFL Network", "NBC Golf", "TBS", "Sky Sports", "Premier League"]
    network_channels = ["ABC", "CBS", "NBC", "FOX", "The CW"]
    movie_channels = ["Starz", "Hallmark Movies & Mysteries", "Hallmark Channel", "FX", "HBO", "Showtime", "Turner Classic Movies"]
    curiosity_channels = ["Discovery Channel", "Animal Planet", "National Geographic", "Nat Geo Wild", "Really", "TLC", "History"]
    lifestyle_channels = ["Lifetime", "HGTV", "Bravo", "Food Network", "Travel Channel"]
    retro_channels = ["TV Land"]
    crime_channels = ["Investigation Discovery"]
    scifi_channels = ["Syfy"]
    kids_channels = ["CBBC", "CBeebies", "Nickelodeon", "Disney Channel", "CITV", "Cartoon Network"]
    family_channels = ["Freeform"]
    comedy_channels = ["Comedy Central"]

    if channel in news_channels:
        genre = "News"
    elif channel in sports_channels:
        genre = "Sports"
    elif channel in network_channels:
        genre = "Network TV"
    elif channel in movie_channels:
        genre = "Movies"
    elif channel in curiosity_channels:
        genre = "Curiosity"
    elif channel in lifestyle_channels:
        genre = "Lifestyle"
    elif channel in retro_channels:
        genre = "Retro"
    elif channel in crime_channels:
        genre = "Crime"
    elif channel in scifi_channels:
        genre = "Sci-Fi"
    elif channel in kids_channels:
        genre = "Kids"
    elif channel in family_channels:
        genre = "Family"
    elif channel in comedy_channels:
        genre = "Comedy"
    else:
        genre = "Misc"

    return genre


def show_file(file, label):
    try:
        f = xbmcvfs.File(os.path.join(plugin_path, file))
        text = f.read(); f.close()

        id = 10147

        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(100)

        win = xbmcgui.Window(id)

        retry = 50
        while (retry > 0):
            try:
                xbmc.sleep(10)
                win.getControl(1).setLabel(label)
                win.getControl(5).setText(text)
                retry = 0
            except:
                retry -= 1

        return '1'
    except:
        return '1'