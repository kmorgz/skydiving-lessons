"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import json
import os
import urllib
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import re
from datetime import datetime, timedelta
import time
from resources.lib import common
from resources.lib import channels
import m7lib

mode = common.TVTime().plugin_queries['mode']
key_check = common.TVTime().check_access_key(common.TVTime().access_key)

if key_check == 'offline':
    common.dlg.ok(common.addonname, common.get_string(90000))
    exit()

if key_check != 'success':
    try:
        # Enter Access Key
        retval = common.dlg.input(common.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if retval and len(retval) > 0:
            common.set_setting('access_key', str(retval))
            access_key = common.get_setting('access_key')
            key_check = common.TVTime().check_access_key(common.TVTime().access_key)
        if len(common.get_setting('access_key')) > 0 and key_check == 'success':
            common.dlg.ok(common.addonname, common.get_string(70000))
        else:
            common.dlg.ok(common.addonname, common.get_string(80000))
            exit()
    except StandardError:
        common.dlg_oops(common.addonname)

location = common.get_location()

if mode == 'main':
    try:
        url = common.TVTime().BASE + "menus/main" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key + "&geo=" + location
        main_menu = m7lib.Common.open_url(url)
        main_menu_results = json.loads(main_menu)['results']

        for i in main_menu_results:
            if i['status'] == 'on':
                icon = common.get_section_logo(i["icon"])
                m7lib.Common.add_section(i['mode'], icon, common.FANART, i['label'].encode("utf8"))

        if len(common.get_setting('notify')) > 0:
            common.set_setting('notify', str(int(common.get_setting('notify')) + 1))
        else:
            common.set_setting('notify', "1")
        if int(common.get_setting('notify')) == 1:
            common.dlg.notification('Like ' + common.addonname + ' Private?', 'Keep it Private!', common.ICON, 5000, False)
        elif int(common.get_setting('notify')) == 9:
            common.set_setting('notify', "0")
    except StandardError:
        common.dlg_oops(common.addonname)

# Begin ArconaiTV #
elif mode == 'arconaitv':
    try:
        url = common.TVTime().BASE + "menus/arconaitv" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key
        arconaitv_menu = m7lib.Common.open_url(url)
        arconaitv_menu_results = json.loads(arconaitv_menu)['results']

        for i in arconaitv_menu_results:
            if i['status'] == 'on':
                icon = common.get_section_logo(i["icon"])
                m7lib.Common.add_section(i['mode'], icon, common.FANART, i['label'])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_live':
    try:
        for channel in channels.Channel().get_arconaitv_channels('Cable'):
            channel_logo = channels.Channel().get_channel_logo(channel["name"].strip())
            m7lib.Common.add_channel(channel["url"] + "play-arconaitv", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_tv_show_channels':
    try:
        for channel in channels.Channel().get_arconaitv_channels('Shows'):
            channel_logo = channels.Channel().get_channel_poster(channel["name"].replace(" ", "").strip())
            m7lib.Common.add_channel(channel["url"] + "play-arconaitv", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'arconaitv_movie_channels':
    try:
        for channel in channels.Channel().get_arconaitv_channels('Movies'):
            if os.path.isfile(xbmc.translatePath(os.path.join(common.SKIN_PATH + '/arconaitv.png'))):
                channel_logo = xbmc.translatePath(os.path.join(common.SKIN_PATH + '/arconaitv.png'))
            else:
                channel_logo = common.ICON
            m7lib.Common.add_channel(channel["url"] + "play-arconaitv", channel_logo, common.FANART, channel["name"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif "play-arconaitv" in mode:
    try:
        url = mode.split('play-arconaitv')[0]
        channels.Channel().play_arconaitv(url)
    except StandardError:
        common.dlg_oops(common.addonname)
# End ArconaiTV #

# End Pokemon Fire #
elif mode == 'pokemon_fire':
    icon = common.SKIN_PATH + "/" + "pokemon_fire.png"
    m7lib.Common.add_section("pokemon_seasons", icon, common.FANART, "TV")
    m7lib.Common.add_section("pokemon_movies", icon, common.FANART, "Movies")

elif mode == "pokemon_seasons":
    try:
        season_path_base = "https://www.pokemonfire.com/seasons/"
        link = m7lib.Common.open_url(season_path_base)
        match = re.compile('<img src="(.+?)" alt="Pok.+?mon: Season (.+?)">').findall(link)
        match = list(reversed(match))
        for thumb, season in match:
            name = 'Season %s' % season
            url = 'https://www.pokemonfire.com/seasons/pokemon-season-%s/' % season
            m7lib.Common.add_section(url + "pokemon_season", thumb, common.FANART, name)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "pokemon_season" in mode:
    try:
        url = mode.split('pokemon_season')[0]
        link = m7lib.Common.open_url(url)
        match = re.compile(
            '<div class="imagen"><a href="(.+?)"><img src="(.+?)"></a></div>\n	<div class="numerando">(.+?)</div>\n	<div class="episodiotitle">\n	<a href=".+?">(.+?)</a>\n	<span class="date">(.+?)</span>').findall(link)
        for url, thumb, episode, title, date in match:
            name = '[B]%s |[/B] %s' % (episode, title)
            m7lib.Common.add_channel(url + "play-pokemon", thumb, common.FANART, name, live=False)

    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "pokemon_movies":
    try:
        link = m7lib.Common.open_url("https://www.pokemonfire.com/movies/")
        match = re.compile(
            '<div class="poster">\n		<img src="(.+?)" alt="(.+?)">\n		<div class="rating"><span class="icon-star2"></span>.+?</div>\n						<a href="(.+?)"><div class="see"></div></a>\n	</div>\n	<div class="data">\n		<h3>\n		<a href=".+?">.+?</a>\n		</h3>\n				<span>(.+?)</span>\n			</div>').findall(link)
        match = list(reversed(match))
        for thumb, title, url, year in match:
            name = '%s (%s)' % (title, year)
            name = name.replace('&#8211;', '-')
            m7lib.Common.add_channel(url + "play-pokemon", thumb, common.FANART, name, live=False)

    except StandardError:
        common.dlg_oops(common.addonname)

elif "play-pokemon" in mode:
    url = mode.split('play-pokemon')[0]
    channels.Channel().play_pokemon(url)
# End Pokemon Fire #

# Begin Fluxus IPTV #
elif mode == 'fluxus_main':
    try:
        url = common.TVTime().BASE + "fluxus/v1/get_list" + base64.b64decode('LnBocA==') + "?key=" + common.TVTime().access_key + "&list=" + mode.replace("fluxus_", "")
        fluxus_menu = m7lib.Common.open_url(url)
        fluxus_menu_results = json.loads(fluxus_menu)

        # Get Updated Date
        for i in sorted(fluxus_menu_results):
            try:
                if "- Update:" in i['tvgroup']:
                    tvtitle = str("[COLOR lightskyblue]" + "** Updated:" + i['tvgroup'] + " **[/COLOR]").replace("- Update:", "")
                    if "tvlogo" not in tvtitle:
                        if i['tvlogo'] == "":
                            img = 'https://i.imgur.com/CvQCnwZ.png'
                        else:
                            img = i['tvlogo']
                        m7lib.Common.add_channel("noop", img, common.FANART, tvtitle.encode("utf8"))
            except KeyError:
                pass

        # Get Streams
        for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
            try:
                if i['tvgroup'] == "USA" or \
                        i['tvgroup'] == "USA LOCAL" or \
                        i['tvgroup'] == "UK" or \
                        i['tvgroup'] == "CANADA" or \
                        i['tvgroup'] == "AUSTRALIA":
                    tvtitle = json.dumps(i['tvtitle']).replace('"','')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    m7lib.Common.add_channel(i['tvmedia'] + "play-iptv", img, common.FANART, tvtitle.encode("utf8"))
            except KeyError:
                pass
    except StandardError:
        common.dlg_oops(common.addonname)

# Begin IPTV (Fluxus TV Play modes #
elif "play-iptv" in mode:
    try:
        url = mode.split('play-iptv')[0]
        m7lib.Common.play(url)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "noop":
    try:
        common.dlg.ok(common.addonname, common.get_string(100004))
        exit()
    except StandardError:
        common.dlg_oops(common.addonname)
# End IPTV (Fluxus TV Play modes #

# Begin YouTube Channels #
elif mode == 'youtube_channels':
    try:
        youtube_channels = channels.Channel().get_youtube_channels()["results"]

        for channel in youtube_channels:
            if channel["status"] == 'on':
                m7lib.Common.add_section(
                    channel["mode"],
                    channels.Channel().get_channel_logo(channel["mode"]),
                    common.FANART, channel["label"])
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode in channels.Channel().get_youtube_channel_modes():
    try:
        playlists = channels.Channel().build_youtube_main(mode)
        if playlists:
            for c in sorted(playlists):
                title = c['title'].encode("utf8")
                m7lib.Common.add_section(title + "-youtube-channel" + mode, c['img'], common.FANART, title)
        else:
            common.dlg_oops(common.addonname)
    except StandardError:
        common.dlg_oops(common.addonname)
        exit()

elif "-youtube-channel" in mode:
    try:
        ymode = mode.split('-youtube-channel', 1)[-1]
        playlists = channels.Channel().build_youtube_main(ymode)
        if playlists:
            for c in playlists:
                channels.Channel().show_youtube_streams(c['title'].encode("utf8"), c['playlist_id'], mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif 'play-youtube' in mode:
    try:
        videoId = mode.split('play-youtube')[0]
        url = common.TVTime().BASE + "ytpowered/v1/check" + base64.b64decode('LnBocA==') + "?id=" + videoId

        stream_status = json.loads(m7lib.Common.open_url(url))['status']

        if stream_status == 'true':
            channels.Channel().play_youtube(videoId)
        else:
            common.dlg_oops(common.addonname)
            exit()
    except StandardError:
        common.dlg_oops(common.addonname)
# End YouTube Channels #

# Begin Xumo TV & Movies #
elif mode == "xumo_direct_main":
    try:
        channels.Channel.get_xumo_main()
    except StandardError:
        common.dlg_oops(common.addonname)

elif "xumo-channel" in mode:
    try:
        channels.Channel.get_xumo_channel(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "-xumo-category" in mode:
    try:
        channels.Channel.get_xumo_category(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "xumo-stream" in mode:
    try:
        channels.Channel.play_xumo(mode)
    except StandardError:
        common.dlg_oops(common.addonname)
# End Xumo TV & Movies #

# Begin Free Live TV (Extra) #
elif mode == 'free_livetv_direct_main':
    try:
        channels.Channel.get_free_live_tv_all()
    except StandardError:
        common.dlg_oops(common.addonname)

elif "play-m7lib" in mode:
    try:
        mode = mode.split('play-m7lib')[0]
        m7lib.Common.get_stream_and_play(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "play-ustvgo" in mode:
    try:
        url = mode.split('play-ustvgo')[0]
        channels.Channel().play_ustvgo(url)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'ET Live':
    try:
        channels.Channel().play_et_live()
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "CBS Sports HQ":
    try:
        channels.Channel().play_cbs_sports_hq()
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'CBSN':
    try:
        channels.Channel().play_cbs_news()
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'CBSN New York':
    try:
        channels.Channel().play_cbs_news_ny()
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == 'CBSN Los Angeles':
    try:
        channels.Channel().play_cbs_news_la()
    except StandardError:
        common.dlg_oops(common.addonname)
# End Free Live TV (Extra) #

# Begin Animal TV #
elif mode == "animal_tv":
    try:
        channels.Channel.get_animal_tv_streams()
    except StandardError:
        common.dlg_oops(common.addonname)

elif "play-animaltv" in mode:
    try:
        videoId = mode.split('play-animaltv')[0]
        channels.Channel.play_youtube(videoId)
    except StandardError:
        common.dlg_oops(common.addonname)
# End Animal TV #

# Begin Tubi TV #
elif mode == "tubitv_main":
    try:
        channels.Channel.tubitv_main()
    except StandardError:
        common.dlg_oops(common.addonname)

elif "tubitv-content" in mode:
    try:
        channels.Channel.tubitv_content(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif "tubitv-episodes" in mode:
    try:
        channels.Channel.tubitv_episodes(mode)
    except StandardError:
        common.dlg_oops(common.addonname)

elif mode == "tubitv-search":
    try:
        channels.Channel.search_tubitv()
    except StandardError:
        common.dlg_oops(common.addonname)

elif "play-tubitv" in mode:
    try:
        channels.Channel.play_tubitv(mode)
    except StandardError:
        common.dlg_oops(common.addonname)
# End Tubi TV #

# Begin Misc Mods #
elif mode == "settings":
    try:
        # Channel Selection
        source = xbmcgui.Dialog().select(common.get_string(40002), [
            common.get_string(20000),
            common.get_string(20001),
            common.get_string(20003),
            common.get_string(20004)
        ])
        if source == 0:
            common.show_settings()
        elif source == 1:
            common.reset_location()
            exit()
        elif source == 2:
            common.show_file("changelog.txt", '%s - %s - %s' % (xbmc.getLocalizedString(24054), xbmcaddon.Addon().getAddonInfo('name'), xbmcaddon.Addon().getAddonInfo('version')))
            exit()
        elif source == 3:
            common.show_file("help.txt", '%s - %s' % (common.get_string(40001), xbmcaddon.Addon().getAddonInfo('name')))
            exit()
        else:
            exit()
    except StandardError:
        common.dlg_oops(common.addonname)
# End Misc Mods #


xbmcplugin.endOfDirectory(common.TVTime().plugin_handle)
