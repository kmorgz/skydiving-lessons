"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
import urllib
import urllib2

import Addon
import base64
import urlresolver
import xbmcgui


class TVtime:

    def __init__(self):
        self.dlg = xbmcgui.Dialog()
        self.mBASE = base64.b64decode('aHR0cHM6Ly93d3cudml0YW1pbnNvY2tzLmNvbS90dnRpbWVfcHJpdmF0ZS8=')
        self.uBASE = base64.b64decode('aHR0cHM6Ly93d3cudml0YW1pbnNvY2tzLmNvbS95dHBvd2VyZWQv')
        self.access_key = str(Addon.get_setting('access_key'))

    def get_streams(self, playlist_id):
        content = self._get_json_u('/get_streams' + base64.b64decode('LnBocA=='), {'id': playlist_id})
        streams = []
        results = content['results']
        for i in results:
            if "Movie Trailer" not in i['title'] and \
                    "trailer" not in i['title'] and \
                    "trailer" not in i['title'] and \
                    "Trailer" not in i['title'] and \
                    "Coming Soon" not in i['title'] and \
                    "Coming soon" not in i['title'] and \
                    "coming Soon" not in i['title'] and \
                    "Watch Maverick Movies" not in i['title']:
                title = i['title'].replace("Biography Documentary Channel - ", "").replace("Biography Documentary Channel  - ", "").replace("Mobsters,  ", "")
                streams.append({
                    'channel': i['title'],
                    'title': title,
                    'videoId': i['id'],
                    'img': i['img']
                })

        return streams

    def get_arconaitv_streams(self, type):
        content = self._get_json('/arconaitv/v2/get_streams' + base64.b64decode('LnBocA=='),
                                 {'key': self.access_key, 'type': type, 'rand': Addon.random_generator()})
        channels = []
        results = content['results']
        if results:
            for i in results:
                channels.append({
                    'id': i['id'],
                    'channel': i['channel'],
                    'img': i['img']

                })
            return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    def get_link_arconaitv(self, id):
        content = self._get_json('/arconaitv/v2/get_stream' + base64.b64decode('LnBocA=='),
                                 {'key': self.access_key, 'id': id, 'rand': Addon.random_generator()})
        channels = []
        results = content['results']
        if results:
            for i in results:
                channels.append({
                    'url': i['stream']
                })
            return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    # Begin YouTube Channels #
    def build_biograpy_main(self):
        playlists = []

        # Unofficial Playlists
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUN1dXQzZV9na3RkSTBlZ0pHYXBrZEVB')})
        results = content['results']
        for i in results:
            if "Biography" in i['title']:
                playlists.append({
                    'channel': i['title'],
                    'title': i['title'],
                    'playlist_id': i['playlist_id'],
                    'img': i['img']
                })

        # Unofficial Playlists
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUNFSlBvdWFlbUhYZ2g5ZC1VMmpBZjdn')})
        results = content['results']
        for i in results:
            if "Biography" in i['title']:
                playlists.append({
                    'channel': i['title'],
                    'title': i['title'],
                    'playlist_id': i['playlist_id'],
                    'img': i['img']
                })

        # Official Playlists
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUN6VGZLb2VLY1FpclM3d2pNUFpjOEx3')})
        results = content['results']
        for i in results:
            if "Biography" in i['title']:
                playlists.append({
                    'channel': i['title'],
                    'title': i['title'],
                    'playlist_id': i['playlist_id'],
                    'img': i['img']
                })

        return playlists

    def build_ufo_tv_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUNhYXNGb1k5eVlRcE9mTDAwTjNuU3hn')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_blr_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUM2N2YyUWY3RllodG9VSUY0U2YyOWNB')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_funnyordie_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUN6UzMtNjVZOTFKaE94RmlNN2o2Z3Jn')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_joy_of_painting_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUN4Y25zcjFSNUdlX2ZiVHU1YWp0OERR')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_last_week_tonight_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUMzWFR6VnphSFFFZDMwclFidXZDdFRR')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_mr_bean_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUNrQUdySENMRm1sSzNIMmtkNmlzaXBn')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_soul_pancake_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUNhRFZjR0RNa3ZjUmI0cUdBUmtXbHln')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_thomas_the_train_main(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUMwcXJjS3VheXZiTXRQai1XWE5GeWxB')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_missouri_star(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUNXbmhSN3JheFZGREhtRFhxQ0l6dUF3')})
        playlists = []
        results = content['results']
        for i in results:
            playlists.append({
                'channel': i['title'],
                'title': i['title'],
                'playlist_id': i['playlist_id'],
                'img': i['img']
            })
        return playlists

    def build_maverick_movies(self):
        content = self._get_json_u('/get_playlists' + base64.b64decode('LnBocA=='),
                                 {'id': base64.b64decode('VUMydTNSM3BqT2lQWnU0THRUbEtreGR3')})
        playlists = []
        results = content['results']
        for i in results:
            if "Trailer" not in i['title'] and \
                    "My Top Videos" not in i['title'] and \
                    "420 STONER MOVIES" not in i['title'] and \
                    "TRAILER" not in i['title'] and \
                    "Indie Scene" not in i['title'] and \
                    "TERRIFYING THURSDAYS" not in i['title'] and \
                    "For Rent" not in i['title'] and \
                    "Buzz Extras" not in i['title'] and \
                    "After Dark Double Features" not in i['title'] and \
                    "Geek Week" not in i['title'] and \
                    "Maverick On The Oscars" not in i['title'] and \
                    "for Rent" not in i['title'] and \
                    "Meet The Actors" not in i['title'] and \
                    "Weekly Updates" not in i['title'] and \
                    "Teasers" not in i['title'] and "2012 MAVERICK RELEASES" not in i['title']:
                playlists.append({
                    'channel': i['title'],
                    'title': i['title'],
                    'playlist_id': i['playlist_id'],
                    'img': i['img']
                })
        return playlists
# End YouTube Channels #

    def _build_url(self, path, queries={}):
        if queries:
            query = Addon.build_query(queries)
            return '%s/%s?%s' % (self.mBASE, path, query)
        else:
            return '%s/%s' % (self.mBASE, path)

    def _build_json(self, path, queries={}):
        if queries:
            query = urllib.urlencode(queries)
            return '%s/%s?%s' % (self.mBASE, path, query)
        else:
            return '%s/%s' % (self.mBASE, path)

    def _build_json_u(self, path, queries={}):
        if queries:
            query = urllib.urlencode(queries)
            return '%s/%s?%s' % (self.uBASE, path, query)
        else:
            return '%s/%s' % (self.mBASE, path)

    def _fetch(self, url, form_data=False):
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]
        if form_data:
            req = urllib2.Request(url, form_data)
        else:
            req = url
        try:
            response = opener.open(req)
            return response
        except urllib2.URLError, e:
            return False

    def _get_json(self, path, queries={}):
        content = False
        url = self._build_json(path, queries)
        response = self._fetch(url)
        if response:
            content = json.loads(response.read())
        else:
            content = False
        return content

    def _get_json_u(self, path, queries={}):
        content = False
        url = self._build_json_u(path, queries)
        response = self._fetch(url)
        if response:
            content = json.loads(response.read())
        else:
            content = False
        return content

    def _get_html(self, path, queries={}):
        html = False
        url = self._build_url(path, queries)

        response = self._fetch(url)
        if response:
            html = response.read()
        else:
            html = False
        return html
