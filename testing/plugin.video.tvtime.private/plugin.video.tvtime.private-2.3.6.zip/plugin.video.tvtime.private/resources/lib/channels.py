"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
import base64
import re
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import sys
import urllib2

import Addon, tvtime


import m7lib

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')

access_key = str(Addon.get_setting('access_key'))


# Parse string and extracts multiple matches using regular expressions
def find_multiple_matches(text, pattern):
    matches = re.findall(pattern, text, re.DOTALL)
    return matches


def clean_hex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x":
            return unichr(int(text[3:-1], 16)).encode('utf-8')
        else:
            return unichr(int(text[2:-1])).encode('utf-8')

    try:
        return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:
        return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))


# Parse string and extracts first match as a string
def find_single_match(text, pattern):
    result = ""
    try:
        matches = re.findall(pattern, text, flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""

    return result


def play(url):
    resolved = url + '|User-Agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
    item = xbmcgui.ListItem(path=resolved)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def play_m7lib(stream, channel=None):
    item = xbmcgui.ListItem(channel, path=stream)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def play_youtube(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_playable_url(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url


def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
    response = urllib2.urlopen(req)
    link = response.read()
    link = clean_hex(link)
    response.close()
    return link


# Add rebase=on to stream URL
def rebase(stream):
    rebase = 'rebase=on'
    if '?' in stream:
        return stream + '&' + rebase
    return stream + '?' + rebase

stream_failed = "Unable to get stream. Please try again later."


def dlg_failed(mode):
    dlg.ok(mode, stream_failed)
    exit()


class Channel():

    @staticmethod
    def play_247retro():
        try:
            stream = m7lib.Stream().twenty_four_seven_retro()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_aljazeera():
        try:
            stream = m7lib.Stream().aljazeera()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_bloomberg():
        try:
            stream = m7lib.Stream().bloomberg()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_buzzr():
        try:
            stream = m7lib.Stream().buzzr()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_catholic_tv():
        try:
            stream = m7lib.Stream().catholic_tv()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_cbs_news(url):
        try:
            site_url = url
            match_string = '"contentUrl":"(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string)
            if "m3u8" in stream:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_cbs_news_ny(url):
        try:
            site_url = url
            match_string = '"video":"(.+?)"'

            req = open_url(site_url)
            stream = find_single_match(req, match_string)
            if "m3u8" in stream:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_cbs_sports_hq():
        try:
            site_url = "https://www.cbsnews.com/live/cbs-sports-hq/"
            match_string = '"video":"(.+?)"'

            req = open_url(site_url)
            stream = rebase(find_single_match(req, match_string))
            if "m3u8" in stream:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_celebrity_page_network():
        try:
            stream = m7lib.Stream().celebrity_page_network()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_charge():
        try:
            stream = m7lib.Stream().charge()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_cheddar():
        # Channel Selection
        source = xbmcgui.Dialog().select("Choose Channel", [
            "[COLOR blue]Cheddar[/COLOR]",
            "[COLOR blue]Cheddar Big News[/COLOR]"
        ])
        if source == 0:
            # Get stream 0
            cheddar_json = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                                   {'key': access_key, 'id': 'cheddar'})
            stream = cheddar_json['results'][0]["stream"]

        if source == 1:
            # Get stream 1
            cheddar_json = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                                   {'key': access_key, 'id': 'cheddar_big_news'})
            stream = cheddar_json['results'][0]["stream"]
        if source < 0:
            exit()

        # Play Cheddar stream depending on Channel Selection
        play_m7lib(stream)

    @staticmethod
    def play_comet():
        try:
            stream = m7lib.Stream().comet()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_et_live():
        try:
            site_url = "https://www.cbsnews.com/live/et-live/"
            match_string = '"video":"(.+?)"'

            req = open_url(site_url)
            stream = rebase(find_single_match(req, match_string))
            if "m3u8" in stream:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_hsn():
        try:
            stream = m7lib.Stream().hsn()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_light_tv():
        try:
            stream = m7lib.Stream().light_tv()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_nasa_tv():
        try:
            stream = m7lib.Stream().nasa_tv()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_newsmax_tv():
        try:
            stream = m7lib.Stream().newsmax_tv()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_pbs_kds():
        try:
            stream = m7lib.Stream().pbs_kids()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_qvc():
        try:
            stream = m7lib.Stream().qvc()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_radiou():
        try:
            stream = m7lib.Stream().radiou()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_revn_tv():
        try:
            stream = m7lib.Stream().revn_tv()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_rt():
        try:
            stream = m7lib.Stream().rt()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_sky_news():
        try:
            stream = m7lib.Stream().sky_news()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_spirittv():
        try:
            stream = m7lib.Stream().spirittv()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_stadium():
        try:
            stream = m7lib.Stream().stadium()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_tbd():
        try:
            stream = m7lib.Stream().tbd()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

    @staticmethod
    def play_the_country_network():
        try:
            stream = m7lib.Stream().the_country_network()
            if stream is not None:
                play_m7lib(stream)
            else:
                dlg_failed(addon_name)
        except:
            dlg_failed(addon_name)

