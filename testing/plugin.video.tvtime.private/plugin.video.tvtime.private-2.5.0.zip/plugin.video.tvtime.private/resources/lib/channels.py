"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmcplugin
import xbmcgui
import sys
import os
import common
import m7lib

access_key = str(common.get_setting('access_key'))


def get_channel_logo(channel):
    return os.path.join(common.plugin_path, 'resources', 'images', 'logos', channel + '.png')


def play_youtube(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


class Channel():

    def __init__(self):
        # Begin Live TV Direct #
        self.free_live_tv_extra_channels = [
            {"name": "ABC News", "type": "News"},
            {"name": "CBSN", "type": "News"},
            {"name": "CBSN New York", "type": "News"},
            {"name": "CBS Sports HQ", "type": "Sports"},
            {"name": "CNN", "type": "News"},
            {"name": "ET Live", "type": "Celebrity"},
            {"name": "HLN", "type": "News"},
            {"name": "FOX News", "type": "News"},
            {"name": "FX", "type": "Comedy, Thriller, Movies"},
            {"name": "FOX Business", "type": "News"},
            {"name": "MSNBC", "type": "News"},
            {"name": "The Weather Channel", "type": "News"},
            {"name": "Starz", "type": "Movies"},
            {"name": "USA Network", "type": "Comedy, Movies"},
            {"name": "SYFY", "type": "Sci-Fi"},
            {"name": "BBC America", "type": "Special Interest"},
            {"name": "PBS", "type": "Special Interest"},
            {"name": "National Geographic", "type": "Curiosity"},
            {"name": "Nat Geo Wild", "type": "Curiosity"},
            {"name": "Animal Planet", "type": "Curiosity"},
            {"name": "Comedy Central", "type": "Comedy"},
            {"name": "Freeform", "type": "Family"},
            {"name": "Lifetime", "type": "Lifestyle, Movies"},
            {"name": "Food Network", "type": "Lifestyle"},
            {"name": "TLC", "type": "Curiosity"},
            {"name": "Travel Channel", "type": "Curiosity, Lifestyle"},
            {"name": "Bravo", "type": "Lifestyle"},
            {"name": "TV Land", "type": "Retro, Comedy"},
            {"name": "TBS", "type": "Comedy, Movies"},
            {"name": "NBC Golf", "type": "Sports"},
            {"name": "NFL Network", "type": "Sports"},
            {"name": "NBC Sports", "type": "Sports"},
            {"name": "A&E", "type": "Movies"},
            {"name": "Hallmark Movies & Mysteries", "type": "Family, Retro, Movies"},
            {"name": "Hallmark Channel", "type": "Family, Retro, Movies"},
            {"name": "Disney Channel", "type": "Family, Kids"},
            {"name": "Investigation Discovery", "type": "Crime, Curiosity"},
            {"name": "Nickelodeon", "type": "Kids"},
            {"name": "Cartoon Network", "type": "Kids"},
            {"name": "The CW", "type": "Network TV"},
            {"name": "HGTV", "type": "Lifestyle"},
            {"name": "AMC", "type": "Movies"},
            {"name": "Discovery Channel", "type": "Curiosity"},
            {"name": "History", "type": "Curiosity"},
            {"name": "ABC", "type": "Network TV"},
            {"name": "NBC", "type": "Network TV"},
            {"name": "FOX", "type": "Network TV"},
        ]
        # End Live TV Direct #

        # Begin Pokemon Seasons #
        self.pokemon_seasons = [
            {"name": "Season 1", "season": "pokemon-season-1/",
             "icon": "2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg"},
            {"name": "Season 2", "season": "pokemon-season-2/",
             "icon": "2017/10/xQDFEDLKeNoMUblTCVHGdqDTZHh-185x278.jpg"},
            {"name": "Season 3", "season": "pokemon-season-3/",
             "icon": "2017/10/piTE2EIhMNeV1aHiTnq36tUc5eB-185x278.jpg"},
            {"name": "Season 4", "season": "pokemon-season-4/",
             "icon": "2017/10/yjAq5sILzVzIBfWtVLdxD8AEjGM-185x278.jpg"},
            {"name": "Season 5", "season": "pokemon-season-5/",
             "icon": "2017/10/4Tr6pjlKidQbSPp6wKf855Sq3L1-185x278.jpg"},
            {"name": "Season 6", "season": "pokemon-season-6/",
             "icon": "2017/10/1dNnm3ghzcnxM9M80NnBnDGmnZI-185x278.jpg"},
            {"name": "Season 7", "season": "pokemon-season-7/",
             "icon": "2017/10/mziBTfCtoeXTUAefm4hordE7OaQ-185x278.jpg"},
            {"name": "Season 8", "season": "pokemon-season-8/",
             "icon": "2017/10/kJ5s8pS0FkgqZvMvKz2dlEoZsqz-185x278.jpg"},
            {"name": "Season 9", "season": "pokemon-season-9/",
             "icon": "2017/10/6BDDH5EHiAHjfVGhi8FQc2xuDG0-185x278.jpg"},
            {"name": "Season 10", "season": "pokemon-season-10/",
             "icon": "2017/10/9abTHX6IcyiZAXiVDQMM5jKWQDy-185x278.jpg"},
            {"name": "Season 11", "season": "pokemon-season-11/",
             "icon": "2017/10/ny1FRSXWEtLCeevlCyq3DuVO4wF-185x278.jpg"},
            {"name": "Season 12", "season": "pokemon-season-12/",
             "icon": "2017/10/1vBe4qmVe3R5UBLocan15WFuIJk-185x278.jpg"},
            {"name": "Season 13", "season": "pokemon-season-13/",
             "icon": "2017/10/l5GEKuCEV27tKdZV42GWJT4i7m4-185x278.jpg"},
            {"name": "Season 14", "season": "pokemon-season-14/",
             "icon": "2017/10/kmfsJG0y9q6y27whVTs8PZWKq4L-185x278.jpg"},
            {"name": "Season 15", "season": "pokemon-season-15/",
             "icon": "2017/10/87N3UhDUIBSm2WtmqbJuPMzUDNx-185x278.jpg"},
            {"name": "Season 16", "season": "pokemon-season-16/",
             "icon": "2017/10/onYS1yKCej8QNjDamw7qUqmrtD-185x278.jpg"},
            {"name": "Season 17", "season": "pokemon-season-17/",
             "icon": "2017/10/Ac69nFUz9mTx6wDCHgxUucvAPph-185x278.jpg"},
            {"name": "Season 18", "season": "pokemon-season-18/",
             "icon": "2017/10/w7gdyFjkcJPEmjXe51Lzdd9NxoB-185x278.jpg"},
            {"name": "Season 19", "season": "pokemon-season-19/",
             "icon": "2017/10/hS4z6hh38C7WkbBzGIvicnYFvqp-185x278.jpg"},
            {"name": "Season 20", "season": "pokemon-season-01/",
             "icon": "2017/10/am5cZ8RVs3HkKGsST0MFuqvDsLh-185x278.jpg"},
            {"name": "Season 21", "season": "pokemon-season-21/",
             "icon": "2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg"}
        ]
        # End Pokemon Seasons #

    @staticmethod
    def get_genres():
        genres = m7lib.Common.get_genres()
        genres.append("Network TV")
        return  genres

    @staticmethod
    def play_abc_news(mode):
        try:
            link = m7lib.Common.open_url("https://www.livenewson.com/american/abc-news-2.html")
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, 'file: "(.+?)"'))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_news(mode):
        try:
            site_url = "https://www.cbsnews.com/live/"
            match_string = '"contentUrl":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_news_ny(mode):
        try:
            site_url = "https://www.cbsnews.com/live/cbsn-local-ny/"
            match_string = '"video":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_sports_hq(mode):
        try:
            site_url = "https://www.cbsnews.com/live/cbs-sports-hq/"
            match_string = '"video":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_hln(mode):
        try:
            site_url = "https://www.livenewswatch.com/hln.html"
            match_string = 'file: "(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_et_live(mode):
        try:
            site_url = "https://www.cbsnews.com/live/et-live/"
            match_string = '"video":"(.+?)"'

            req = m7lib.Common.open_url(site_url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_ustvgo(mode, slug):
        try:
            url = "http://ustvgo.net/" + slug
            link = m7lib.Common.open_url(url)
            stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, "file: '(.+?)'"))
            if "m3u8" in stream:
                m7lib.Common.play(stream, mode)
            else:
                common.dlg_stream_failed(common.addonname)
        except:
            common.dlg_stream_failed(common.addonname)