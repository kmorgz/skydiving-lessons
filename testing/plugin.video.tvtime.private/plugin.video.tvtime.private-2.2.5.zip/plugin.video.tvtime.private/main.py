"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import json
import os
import re
import sys
import urllib
import urllib2

import jsbeautifier.unpackers.packer as packer
import requests
import urlresolver
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup

from resources.lib import Addon, tvtime
from resources.modules import net
from resources.lib import channels

net = net.Net()

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')

Addon.plugin_url = sys.argv[0]
Addon.plugin_handle = int(sys.argv[1])
Addon.plugin_queries = Addon.parse_query(sys.argv[2][1:])

dlg = xbmcgui.Dialog()

addon_logo = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))

mode = Addon.plugin_queries['mode']

access_key = str(Addon.get_setting('access_key'))

key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})['status']

if key_check == 'offline':
    dlg.ok(Addon.get_string(5000), Addon.get_string(90000))
    exit()

if key_check != 'success':
    # Enter Access Key
    retval = dlg.input(Addon.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if retval and len(retval) > 0:
        Addon.set_setting('access_key', str(retval))
        access_key = Addon.get_setting('access_key')
        key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})[
            'status']
    if len(Addon.get_setting('access_key')) > 0 and key_check == 'success':
        dlg.ok(Addon.get_string(5000), Addon.get_string(70000))
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(80000))
        exit()


def youtube_stream(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url


##Begin Live News##
def livenews_stream(url, name):
    if "youtube" in url:
        stream = Addon.youtube_resolve(url)
    else:
        stream = url + '|Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
    item = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def cnn_stream(url, name):
    # Get Stream
    link = Addon.open_url(url)
    stream = Addon.find_single_match(link, "file: '(.+?)'")
    if "m3u8" in stream:
        Addon.play_generic(stream)
    else:
        dlg.ok(name, "Unable to get stream. Please try again later.")


def foxnews_stream(url, name):
    # Get Stream
    link = Addon.open_url(url)
    stream = Addon.find_single_match(link, "file: '(.+?)'")
    if "m3u8" in stream:
        Addon.play_generic(stream)
    else:
        dlg.ok(name, "Unable to get stream. Please try again later.")


def msnbc_stream(url, name):
    # Get Stream
    link = Addon.open_url(url)
    stream = Addon.find_single_match(link, "file: '(.+?)'")
    if "m3u8" in stream:
        Addon.play_generic(stream)
    else:
        dlg.ok(name, "Unable to get stream. Please try again later.")


def cspan_stream(url, name):
    Addon.play_generic(url)
##End Live News##


##Begin HGTV##
def hgtv_main():
    link = Addon.open_url('http://www.hgtv.com/shows/full-episodes/')
    matches = Addon.find_multiple_matches(link,'<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</h4>')
    for entry in matches:
        name = Addon.find_single_match(entry,'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'").strip()
        description = ""
        url = "http:" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry,'data-src="(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'hgtv_main.jpg'))
        videos = Addon.find_single_match(entry,'<span class="m-MediaBlock__a-AssetInfo">(.+?) Videos</span>')
        if videos != "0":
            Addon.addDir(name,description,url,6,iconimage)


def hgtv_episodes(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link, '"id" : "(.*?)},')

    for entry in matches:
        name = Addon.find_single_match(entry, '"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'").strip()
        description = Addon.find_single_match(entry, '"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry, '"releaseUrl" : "(.+?)"')
        iconimage = "http://hgtv.com/" + Addon.find_single_match(entry, '"thumbnailUrl" : "(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'hgtv_main.jpg'))
        if "http" in url:
            Addon.addLink(name, description, url, 7, iconimage)


def hgtv_stream(url):
    link = Addon.open_url(url)
    url = Addon.find_single_match(link, '<video src="(.*?)"')
    Addon.play(url)
##End HGTV##


##Begin Travel Channel##
def travel_main():
    link = Addon.open_url('http://www.travelchannel.com/shows/video/full-episodes')
    matches = Addon.find_multiple_matches(link,'<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</h4>')

    for entry in matches:
        name = Addon.find_single_match(entry,'title="(.+?)"').replace("&amp;", "&")
        description=""
        url = "http:" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry,'data-src="(.+?)"').replace("http://cook.home.sndimg.com", "http://travel.home.sndimg.com")
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'travel_main.jpg'))
        videos = Addon.find_single_match(entry,'<span class="m-MediaBlock__a-AssetInfo">(.+?) Videos</span>')
        if videos != "0":
            Addon.addDir(name,description,url,8,iconimage)


def travel_episodes(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link, '"id" : "(.*?)},')

    for entry in matches:
        name = Addon.find_single_match(entry, '"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry, '"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry, '"releaseUrl" : "(.+?)"')
        iconimage = "http://travelchannel.com/" + Addon.find_single_match(entry, '"thumbnailUrl" : "(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'travel_main.jpg'))
        if "http" in url:
            Addon.addLink(name, description, url, 9, iconimage)


def travel_stream(url):
    link = Addon.open_url(url)
    url = Addon.find_single_match(link, '<video src="(.*?)"')
    Addon.play(url)
##End Travel Channel##

##Begin DIY Network##
def diy_main():
    link = Addon.open_url('http://www.diynetwork.com/shows/full-episodes')
    matches = Addon.find_multiple_matches(link,
                                          '<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</h4>')

    for entry in matches:
        name = Addon.find_single_match(entry, 'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http:" + Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry, 'data-src="(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'diy_main.jpg'))
        videos = Addon.find_single_match(entry, '<span class="m-MediaBlock__a-AssetInfo">(.+?) Videos</span>')
        if videos != "0":
            Addon.addDir(name, description, url, 10, iconimage)


def diy_episodes(url):
    if url == "null":
        url = "http://www.diynetwork.com/shows/full-episodes"
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link, '"id" : "(.*?)},')

    for entry in matches:
        name = Addon.find_single_match(entry, '"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry, '"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry, '"releaseUrl" : "(.+?)"')
        iconimage = "http://diynetwork.com/" + Addon.find_single_match(entry, '"thumbnailUrl" : "(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'diy_main.jpg'))
        if "http" in url:
            Addon.addLink(name, description, url, 11, iconimage)


def diy_stream(url):
    link = Addon.open_url(url)
    url = Addon.find_single_match(link, '<video src="(.*?)"')
    Addon.play(url)
##End DIY Network##


##Begin Cooking Channel##
def cooking_main():
    link = Addon.open_url('http://www.cookingchanneltv.com/videos/players/full-episodes-player')
    matches = Addon.find_multiple_matches(link, '<html >(.*?)</html>')

    for entry in matches:
        name = Addon.find_single_match(entry, '<span class="m-VideoPlayer__a-HeadlineText">(.+?)</span>').replace(
            "&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "null"
        iconimage = "http://cookingchanneltv.com/" + Addon.find_single_match(entry, '"thumbnailUrl" : "(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'cooking_main.jpg'))
        if name is not "":
            Addon.addDir(name, description, url, 12, iconimage)

    matches = Addon.find_multiple_matches(link, 'data-module="editorial-promo">(.*?)</div>')

    for entry in matches:
        name = Addon.find_single_match(entry, 'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http:" + Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry, 'data-src="(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'cooking_main.jpg'))
        if name is not "":
            Addon.addDir(name, description, url, 12, iconimage)


def cooking_episodes(url):
    if url == "null":
        url = "http://www.cookingchanneltv.com/videos/players/full-episodes-player"
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link,'"id" : "(.*?)},')

    for entry in matches:
        name = Addon.find_single_match(entry,'"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry,'"releaseUrl" : "(.+?)"')
        iconimage = "http://cookingchanneltv.com" + Addon.find_single_match(entry,'"thumbnailUrl" : "(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'cooking_main.jpg'))
        if "http" in url:
            Addon.addLink(name,description,url,13,iconimage)


def cooking_stream(url):
    link = Addon.open_url(url)
    url = Addon.find_single_match(link, '<video src="(.*?)"')
    Addon.play(url)
##End Cooking Channel##


##Begin Food Network##
def food_main():
    link = Addon.open_url('http://www.foodnetwork.com/videos/full-episodes')
    matches = Addon.find_multiple_matches(link,
                                          '<div class="m-MediaBlock o-Capsule__m-MediaBlock m-MediaBlock--playlist">(.*?)</div>')

    for entry in matches:
        name = Addon.find_single_match(entry, 'title="(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        url = "http:" + Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry, 'data-src="(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'food_main.jpg'))
        Addon.addDir(name, description, url, 14, iconimage)


def food_episodes(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link, '"id" : "(.*?)},')

    for entry in matches:
        name = Addon.find_single_match(entry, '"title" : "(.+?)"').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry, '"description" : "(.+?)"').replace("<p>", "").replace("<\/p>", "")
        url = Addon.find_single_match(entry, '"releaseUrl" : "(.+?)"')
        iconimage = "http://foodnetwork.com/" + Addon.find_single_match(entry, '"thumbnailUrl" : "(.+?)"')
        if ".jpg" not in iconimage:
            iconimage = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'food_main.jpg'))
        if "http" in url:
            Addon.addLink(name, description, url, 15, iconimage)


def food_stream(url):
    link = Addon.open_url(url)
    url = Addon.find_single_match(link, '<video src="(.*?)"')
    Addon.play(url)
##End Food Network##


##Begin Smithsonian Channel##
def smith_main():
    link = Addon.open_url('http://www.smithsonianchannel.com/full-episodes')
    matches = Addon.find_multiple_matches(link, '<li class="mix free" data-premium="false">(.*?)</li>')

    for entry in matches:
        name = Addon.find_single_match(entry, '<h3 class="promo-series-name">(.+?)</h3>').replace("&amp;", "&").replace(
            "&#39;", "'")
        description = Addon.find_single_match(entry, '<h2 class="promo-show-name">(.+?)</h2>').replace("&amp;",
                                                                                                       "&").replace(
            "&#39;", "'")
        url = "http://www.smithsonianchannel.com/" + Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = "http:" + Addon.find_single_match(entry, '<source srcset="(.+?)"')
        if len(name) > 0 and "http" in url:
            Addon.addLink(name, description, url, 20, iconimage)


def smith_stream(url):
    link = Addon.open_url(url)
    url = Addon.find_single_match(link, '<meta name="twitter:player:stream" content="(.*?)"')
    Addon.play(url)
##End Smithsonian Channel##


##Begin Freeform##
def freeform_main():
    link = Addon.open_url('http://freeform.go.com/shows')
    matches = Addon.find_multiple_matches(link,'<div class="col-xs-4 shows-grid">(.*?)/p>')
    for entry in matches:
        name = Addon.find_single_match(entry,'<h3>(.+?)</h3>').replace("&amp;", "&").replace("&#39;", "'")
        description = Addon.find_single_match(entry,'<p>(.+?)<').replace("&amp;", "&").replace("&#39;", "'")
        url = "http://freeform.go.com" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'<img src="(.+?)"')
        if "http" in url:
            Addon.addDir(name,description,url,21,iconimage)


def freeform_episodes(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link,'<hr />(.*?)<p class="m-t-1">')

    episodelist = []
    for entry in matches:
        name = Addon.find_single_match(entry,'<h1 class="text-hover">(.+?)</h1>').replace("&amp;", "&").replace("&#39;", "'").strip()
        description = Addon.find_single_match(entry,'"ResultDescription":(.+?)"').replace("<p>", "").replace("<\/p>", "").strip().replace("&#39;", "'").replace("&quot;", '"')
        url = "http://freeform.go.com" + Addon.find_single_match(entry,'<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry,'<img src="(.+?)"')
        lock = Addon.find_single_match(entry,'data-sign-in-padlock data-requires-sign-in="(.+?)"').strip()
        if "http" in url and lock == "False":
            episodelist.append(name)
        if len(episodelist) > 0:
            Addon.addLink(name,description,url,22,iconimage)
        else:
            dlg.ok(addonname, "No episodes found.")
            exit()


def freeform_movies(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link, '<div class="movies-grid col-xs-6 col-md-4 col-lg-3">(.*?)</a>')

    for entry in matches:
        name = Addon.find_single_match(entry, '<h3 class="m-b-0">(.+?)</h3>').replace("&amp;", "&").replace("&#39;",
                                                                                                            "'").strip()
        description = Addon.find_single_match(entry, '<p>(.+?)</p>').replace("<p>", "").replace("<\/p>",
                                                                                                "").strip().replace(
            "&#39;", "'").replace("&quot;", '"')
        url = "http://freeform.go.com" + Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry, '<img src="(.+?)"')
        lock = Addon.find_single_match(entry, 'data-sign-in-padlock data-requires-sign-in="(.+?)"').strip()
        if "http" in url and lock == "False":
            Addon.addLink(name, description, url, 22, iconimage)


def freeform_stream(url):
    link = Addon.open_url(url)
    vd = Addon.find_single_match(link,"VDKA(.+?)\"")
    url = 'https://api.entitlement.watchabc.go.com/vp2/ws-secure/entitlement/2020/authorize.json'
    udata = 'video%5Fid=VDKA'+str(vd)+'&device=001&video%5Ftype=lf&brand=002'
    uheaders = Addon.defaultHeaders.copy()
    uheaders['Content-Type'] = 'application/x-www-form-urlencoded'
    uheaders['Accept'] = 'application/json'
    uheaders['X-Requested-With'] = 'ShockwaveFlash/24.0.0.194'
    uheaders['Origin'] = 'http://cdn1.edgedatg.com'
    uheaders['DNT'] = '1'
    uheaders['Referer'] = 'http://cdn1.edgedatg.com/aws/apps/datg/web-player-unity/1.0.6.13/swf/player_vod.swf'
    uheaders['Pragma'] = 'no-cache'
    uheaders['Connection'] = 'keep-alive'
    uheaders['Cache-Control'] = 'no-cache'
    html = Addon.getRequest(url, udata, uheaders)
    a = json.loads(html)
    if a.get('uplynkData', None) is None:
        return

    sessionKey = a['uplynkData']['sessionKey']
    oid = Addon.find_single_match(html,'&oid=(.+?)&')
    eid = Addon.find_single_match(html,'&eid=(.+?)&')
    url = 'http://content.uplynk.com/ext/%s/%s.m3u8?%s' % (oid, eid, sessionKey)

    Addon.play(url)
##End freeform##


##Begin ABC##
def abc_main():
    link = Addon.open_url('http://abc.go.com/shows')
    matches = Addon.find_multiple_matches(link,'<li  data-sm-id=""(.*?)/li>')
    for entry in matches:
        name = Addon.find_single_match(entry,'<div class="tile-show-name truncate">(.+?)</div>').replace("&amp;", "&").replace("&#39;", "'")
        description = ""
        path = Addon.find_single_match(entry,'<a href="(.+?)"').replace("/index", "")
        if name == "The Neighbors":
            url = "http://abc.go.com" + path + "/episode-guide/season-01"
        else:
            url = "http://abc.go.com" + path + "/episode-guide"
        iconimage = Addon.find_single_match(entry,'srcset="(.+?) ')
        if "http" in url and name != "":
            Addon.addDir(name,description,url,24,iconimage)


def abc_seasons(url, name, iconimage):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link,'<option(.*?)option>')

    if matches == []:
        abc_episodes(url)
    else:
        seasonlist = []

        for entry in matches:
            name = Addon.find_single_match(entry,'>(.+?)</').replace("&amp;", "&").replace("&#39;", "'").strip()
            description = ""
            path = Addon.find_single_match(entry,'value="(.+?)"').replace("/index", "")
            url = "http://abc.go.com" + path
            if len(path) > 0:
                seasonlist.append(path)
            if len(seasonlist) > 0:
                Addon.addDir(name,description,url,25,iconimage)
            else:
                dlg.ok(addonname, "No episodes found.")
                exit()


def abc_episodes(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link,'<div class="m-episode-copy medium-8 large-6 columns nogutter ">(.*?)</picture>')

    if len(matches) > 0:
        episodelist = []

        for entry in matches:
            season = Addon.find_single_match(entry,'<span class="season-number light">(.+?)</span>').replace("&amp;", "&").replace("&#39;", "'").strip()
            season = re.sub('<[^<]+?>', '', season).strip()
            episode = Addon.find_single_match(entry,'<span class="episode-number">(.+?)</a>').replace("&amp;", "&").replace("&#39;", "'").strip()
            episode = re.sub('<[^<]+?>', '', episode).strip()
            name = season + " " + episode
            description = Addon.find_single_match(entry,'<p>(.+?)</p>').replace("&amp;", "&").replace("&#39;", "'").strip()
            description = re.sub('<[^<]+?>', '', description).strip()
            path = Addon.find_single_match(entry,'<a class="dark-text" href="(.+?)">Watch</a>')
            url = "http://abc.go.com" + path
            iconimage = Addon.find_single_match(entry,'srcset="(.+?) ')
            if len(path) > 0:
                episodelist.append(path)
            if len(episodelist) > 0:
                Addon.addLink(name,description,url,26,iconimage)
            else:
                dlg.ok(addonname, "No episodes found.")
                exit()
    else:
        dlg.ok(addonname, "No episodes found.")
        exit()


def abc_stream(url):
    link = Addon.open_url(url)
    vd = Addon.find_single_match(link,"VDKA(.+?)\"")
    url = 'https://api.entitlement.watchabc.go.com/vp2/ws-secure/entitlement/2020/authorize.json'
    udata = 'video%5Fid=VDKA'+str(vd)+'&device=001&video%5Ftype=lf&brand=001'
    uheaders = Addon.defaultHeaders.copy()
    uheaders['Content-Type'] = 'application/x-www-form-urlencoded'
    uheaders['Accept'] = 'application/json'
    uheaders['X-Requested-With'] = 'ShockwaveFlash/22.0.0.209'
    uheaders['Origin'] = 'http://cdn1.edgedatg.com'
    html = Addon.getRequest(url, udata, uheaders)
    a = json.loads(html)
    if a.get('uplynkData', None) is None:
        return

    sessionKey = a['uplynkData']['sessionKey']
    if not '&cid=' in sessionKey:
        oid = Addon.find_single_match(html,'&oid=(.+?)&')
        eid = Addon.find_single_match(html,'&eid=(.+?)&')
        url = 'http://content.uplynk.com/ext/%s/%s.m3u8?%s' % (oid, eid, sessionKey)
    else:
        cid = Addon.find_single_match(html,'&cid=(.+?)&')
        url = 'http://content.uplynk.com/%s.m3u8?%s' % (cid, sessionKey)

    Addon.play(url)
##End ABC##


##Begin NBC##
def nbc_main():
    link = Addon.open_url('http://www.nbc.com/shows/all')
    html = Addon.find_single_match(link,'<script>PRELOAD=(.*?)</script>')
    a = json.loads(html)
    a = a['lists']['allShows']['items']
    for b in a:
        if b['tuneIn'] != 'WATCH VIDEOS' and b['tuneIn'] != 'COMING SOON' and b['tuneIn'] != 'LEARN MORE' and b['tuneIn'] != 'WATCH HIGHLIGHTS' and b['tuneIn'] != 'WATCH VIDEO' and 'SERIES PREMIERE' not in str(b['tuneIn']):
            name = b['title']
            description = ""
            url = 'http://www.nbc.com/' + b['urlAlias'] + '?nbc=1'
            iconimage = b['image']['path']
            if "Coming Soon" not in name:
                Addon.addDir(name,description,url,27,iconimage)


def nbc_episodes(url):
    link = Addon.open_url(url)
    id = re.compile(',"listKey"\:\"(.+?)"', re.DOTALL).search(link)
    if id is not None:
        id = id.group(1)
        id = id.rsplit('-', 1)[0]

        html = Addon.open_url('https://api.nbc.com/v3.14/videos?fields%5Bvideos%5D=title%2Cdescription%2Ctype%2Cgenre%2CvChipRating%2CvChipSubRatings%2Cguid%2Cpublished%2CrunTime%2Cairdate%2Cavailable%2CseasonNumber%2CepisodeNumber%2Cexpiration%2Centitlement%2CtveAuthWindow%2CnbcAuthWindow%2CexternalAdId%2CuplynkStatus%2CdayPart%2CinternalId%2Ckeywords%2Cpermalink%2CembedUrl%2Ccredits%2CselectedCountries%2Ccopyright&fields%5Bshows%5D=active%2Ccategory%2Ccolors%2CcreditTypeLabel%2Cdescription%2Cfrontends%2Cgenre%2CinternalId%2CisCoppaCompliant%2Cname%2Cnavigation%2Creference%2CschemaType%2CshortDescription%2CshortTitle%2CshowTag%2Csocial%2CsortTitle%2CtuneIn%2Ctype%2CurlAlias&fields%5Bimages%5D=derivatives%2Cpath%2Cwidth%2Cattributes%2CaltText%2Clink&fields%5BaggregatesShowProperties%5D=videoEpisodeSeasons%2CvideoTypes&include=image%2Cshow.image%2Cshow.aggregates&filter%5Bpublished%5D=1&filter%5BsalesItem%5D=0&filter%5Bshow%5D='+id+'&filter%5Btype%5D%5Bvalue%5D=Full%20Episode&filter%5Btype%5D%5Boperator%5D=%3D&sort=airdate&page%5Bnumber%5D=1&page%5Bsize%5D=50')

        a = json.loads(html)
        episodelist = []

        for b in sorted(a['data']):
            entitlement = b['attributes'].get('entitlement')
            url = b['attributes'].get('embedUrl')
            url = url.split('guid/',1)[1]
            url = url.split('?',1)[0]
            url = 'http://link.theplatform.com/s/NnzsPC/media/guid/%s?format=preview' % url
            html = Addon.getRequest(url)
            if html == '':
                continue
            c = json.loads(html)
            name = c['title']
            description = c.get('description')
            iconimage = c.get('defaultThumbnailUrl')
            url = 'http://link.theplatform.com/s/NnzsPC/media/'+c['mediaPid']+'?policy=43674&player=NBC.com%20Instance%20of%3A%20rational-player-production&formats=m3u,mpeg4&format=SMIL&embedded=true&tracking=true'

            if b['attributes'].get('type') == "Full Episode" and entitlement == "free":
                episodelist.append(name)
            if len(episodelist) > 0:
                Addon.addLink(str(name),description,url,28,iconimage)
            else:
                dlg.ok(addonname, "No episodes found.")
                exit()
    else:
        dlg.ok(addonname, "No episodes found.")
        exit()


def nbc_stream(url):
    if not '&format=redirect' in url:
        html = Addon.getRequest(url)
        if 'video src="' in html:
            url = Addon.find_single_match(html,'video src="(.+?)"')
        else:
            url = Addon.find_single_match(html,'ref src="(.+?)"')
        if 'nbcvodenc' in url:
            html = Addon.getRequest(url)
            url = Addon.find_single_match(html,'http(.+?)\n')
            url = 'http'+url.strip()
        elif not (url.endswith(".mp4") or url.endswith(".flv")):
            headers = Addon.defaultHeaders.copy()
            headers['User-Agent']= 'Mozilla/5.0 (Linux; U; en-US) AppleWebKit/528.5+ (KHTML, like Gecko, Safari/528.5+) Version/4.0 Kindle/3.0 (screen 600X800; rotate)'
            html = Addon.getRequest(url, headers=headers)
            urls = Addon.find_multiple_matches(html,'BANDWIDTH=(.+?),.+?\n(.+?)\n')
            blast = 0
            for b,u in urls:
                b = int(b)
                if blast < b:
                    url = u
                    blast = b
            url += '|User-Agent='+urllib.quote(headers['User-Agent'])
        if "Unavailable.mp4" in url:
            dlg.ok(addonname, "Stream unavailable.")
            exit()
        else:
            Addon.play_generic(url)
##End NBC##


##Begin PBS##
def pbs_main():
    pg = Addon.open_url('http://pbskids.org/video/')
    a = re.compile('<dd class="category-list-button.+?data-slug="(.+?)">(.+?)<.+?src="(.+?)".+?</dd', re.DOTALL).findall(pg)
    for url, name, thumb in a:
        url = 'https://cms-tc.pbskids.org/pbskidsvideoplaylists/%s.json' % url

        name = name.replace("&amp;", "&").replace("&#039;", "'")
        description = name
        iconimage = thumb
        Addon.addDir(str(name),str(description),str(url),29,str(iconimage))


def pbs_episodes(url):
    link = Addon.open_url(url)
    a = json.loads(link)
    a = a['collections']['episodes']['content']
    if len(a) > 0:
        for b in a:
            url = b.get('mp4')
            if not url is None:
                name = b.get('title', 'no title')
                iconimage = b.get('images', {'x': None}).get('mezzanine', addon_logo)

                description = b.get('description')
                Addon.addLink(str(name),str(description),str(url),30,str(iconimage))
    else:
        dlg.ok(addonname, "No episodes found.")
        exit()


def pbs_stream(url):
    html = Addon.getRequest('%s?format=json' % url)
    a = json.loads(html)
    url = a.get('url')
    if url is not None:
        Addon.play(url)
##End PBS##


##Begin TVCatchup.com##
def tvcatchup_main():
    link = Addon.open_url('https://tvcatchup.com/')
    matches = Addon.find_multiple_matches(link, '<p class="channelsicon" style.+?>(.*?)</div>')

    for entry in sorted(matches, reverse=False):
        getchannel = Addon.find_single_match(entry, 'alt="Watch (.+?)"')
        gettitle = Addon.find_single_match(entry, '<br/> (.+?) </a>').replace("&#039;", "'").replace("&amp;", "&")
        name = getchannel + ' - ' + gettitle
        description = ""
        geturl = Addon.find_single_match(entry, '<a href="(.+?)"')
        url = 'http://tvcatchup.com' + geturl
        iconimage = base64.b64decode(
            'aHR0cHM6Ly9taGFuY29jNy5zb3VyY2Vjb2RlLmFnL3R2dGltZV9wcml2YXRlLw==') + "/tvcatchup/v1/icons/" + Addon.find_single_match(
            entry, 'alt="(.+?)"') + ".png"

        Addon.addLink_live(name, description, url, 5, iconimage)

def tvcatchup(url):
    link = Addon.open_url(url)
    link = link
    match = re.compile('<source src="(.+?)" type="application/x-mpegURL">').findall(link)
    for url in match:
        Addon.play(url)
##End TVCatchup.com##


##Begin Pokemon Fire##
def pokemon_fire_seasons(url):
    link = Addon.open_url(url)
    matches = Addon.find_multiple_matches(link, '<div class="imagen">(.*?)</li>')

    for entry in matches:
        name = Addon.find_single_match(entry, '/">(.+?)</a>', 1).encode('latin-1')
        description = Addon.find_single_match(entry, '<span class="date">(.+?)</span>')
        url = Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry, '<img src="(.+?)"')

        Addon.addLink(name, description, url, 501, iconimage)


def pokemon_fire_play(url):
    player_match_string = '<iframe class="metaframe rptss" src="(.*?)"'
    stream_match_string = 'file: \'(.*?)\''

    # Get Player
    req = Addon.open_url(url)
    player_url = Addon.find_single_match(req, player_match_string, 1)

    # Get Stream
    req = Addon.open_url(player_url)
    stream = Addon.find_single_match(req, stream_match_string)

    if 'mp4' in stream:
        Addon.play(stream)
    else:
        dlg.ok("TV Time Private", "Unable to get stream. Please try again later.")
##End Pokemon Fire##

# Start YouTube Playlist Channels #
def show_streams(title, playlist_id):
    if title in mode:
        streams = tvtime.TVtime().get_streams(playlist_id)
        if streams:
            for c in streams:
                title = c['title']
                channel = c['title']
                videoId = c['videoId']
                img = c['img']
                rURL = Addon.plugin_url + "?channel=" + channel + "&videoId=" + videoId + "&mode=play-youtube"
                Addon.add_video_item(rURL, {'title': title}, img=img)
# End YouTube Playlist Channels #

if mode == 'main':
    main_menu = tvtime.TVtime()._get_json('/menus/main' + base64.b64decode('LnBocA=='), {'key': access_key})
    main_menu_results = main_menu['results']
    for i in main_menu_results:
        if i['status'] == 'on':
            if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
            Addon.add_directory({'mode': i['mode']}, i['label'], img=icon)

    if len(Addon.get_setting('notify')) > 0:
        Addon.set_setting('notify', str(int(Addon.get_setting('notify')) + 1))
    else:
        Addon.set_setting('notify', "1")
    if int(Addon.get_setting('notify')) == 1:
        xbmcgui.Dialog().notification('Like ' + addonname + ' Private?', 'Keep it Private!', addon_logo, 5000, False)
    elif int(Addon.get_setting('notify')) == 9:
        Addon.set_setting('notify', "0")

##Begin ArconaiTV##
if mode == 'arconaitv':
    arconaitv_menu = tvtime.TVtime()._get_json('/menus/arconaitv' + base64.b64decode('LnBocA=='), {'key': access_key})
    arconaitv_menu_results = arconaitv_menu['results']
    for i in arconaitv_menu_results:
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg')))

if mode == 'arconaitv_live':
    channels = tvtime.TVtime().get_arconaitv_streams('Cable')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', c['img']))
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)

if mode == 'tv_show_channels':
    channels = tvtime.TVtime().get_arconaitv_streams('Shows')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = c['img']
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)

if mode == 'movie_channels':
    channels = tvtime.TVtime().get_arconaitv_streams('Movies')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)
##End ArconaiTV##

# Begin Live Channels#
if mode == 'catholic_tv':
    channels.Channel().play_catholic_tv()

if mode == 'charge':
    channels.Channel().play_charge()

if mode == 'comet':
    channels.Channel().play_comet()

if mode == 'tbd':
    channels.Channel().play_tbd()

if mode == 'tuff':
    channels.Channel().play_campfire(mode)

if mode == 'radiou':
    channels.Channel().play_campfire(mode)

if mode == 'spirit_tv':
    channels.Channel().play_campfire(mode)

if mode == 'hsn':
    channels.Channel().play_hsn()

if mode == 'pbs_kids':
    channels.Channel().play_pbs_kds()

if mode == 'qvc':
    channels.Channel().play_qvc()

if mode == 'tcn':
    channels.Channel().play_the_country_network()

if mode == 'revn':
    channels.Channel().play_revn_tv()

if mode == 'lighttv':
    channels.Channel.play_light_tv()

if mode == '247_retro':
    channels.Channel().play_247retro()

if mode == 'buzzr':
    channels.Channel().play_buzzr()

if mode == 'mlb_network':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nfl_now':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_network':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_arizona':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_bay':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_los':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_mountain':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_oregon':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'pac_washington':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_bayarea':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_chicago':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_northwest':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_philly':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_phillyplus':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_cali':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbcs_boston':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'nbc_golf':
    get_stream = tvtime.TVtime()._get_json('/livetv_direct/v1/get_stream' + base64.b64decode('LnBocA=='),
                                           {'key': access_key, 'id': mode})
    get_stream_results = get_stream['results']
    for i in get_stream_results:
        Addon.play(i['stream'])

if mode == 'stadium':
    channels.Channel().play_stadium()
# End Live Channels#

# End Pokemon Fire #
if mode == 'pokemon_fire':
    Addon.addDir("Season 1", "", 'https://www.pokemonfire.com/seasons/pokemon-season-1/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg')
    Addon.addDir("Season 2", "", 'https://www.pokemonfire.com/seasons/pokemon-season-2/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/xQDFEDLKeNoMUblTCVHGdqDTZHh-185x278.jpg')
    Addon.addDir("Season 3", "", 'https://www.pokemonfire.com/seasons/pokemon-season-3/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/piTE2EIhMNeV1aHiTnq36tUc5eB-185x278.jpg')
    Addon.addDir("Season 4", "", 'https://www.pokemonfire.com/seasons/pokemon-season-4/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/yjAq5sILzVzIBfWtVLdxD8AEjGM-185x278.jpg')
    Addon.addDir("Season 5", "", 'https://www.pokemonfire.com/seasons/pokemon-season-5/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/4Tr6pjlKidQbSPp6wKf855Sq3L1-185x278.jpg')
    Addon.addDir("Season 6", "", 'https://www.pokemonfire.com/seasons/pokemon-season-6/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/1dNnm3ghzcnxM9M80NnBnDGmnZI-185x278.jpg')
    Addon.addDir("Season 7", "", 'https://www.pokemonfire.com/seasons/pokemon-season-7/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/mziBTfCtoeXTUAefm4hordE7OaQ-185x278.jpg')
    Addon.addDir("Season 8", "", 'https://www.pokemonfire.com/seasons/pokemon-season-8/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/kJ5s8pS0FkgqZvMvKz2dlEoZsqz-185x278.jpg')
    Addon.addDir("Season 9", "", 'https://www.pokemonfire.com/seasons/pokemon-season-9/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/6BDDH5EHiAHjfVGhi8FQc2xuDG0-185x278.jpg')
    Addon.addDir("Season 10", "", 'https://www.pokemonfire.com/seasons/pokemon-season-10/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/9abTHX6IcyiZAXiVDQMM5jKWQDy-185x278.jpg')
    Addon.addDir("Season 11", "", 'https://www.pokemonfire.com/seasons/pokemon-season-11/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/ny1FRSXWEtLCeevlCyq3DuVO4wF-185x278.jpg')
    Addon.addDir("Season 12", "", 'https://www.pokemonfire.com/seasons/pokemon-season-12/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/1vBe4qmVe3R5UBLocan15WFuIJk-185x278.jpg')
    Addon.addDir("Season 13", "", 'https://www.pokemonfire.com/seasons/pokemon-season-13/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/l5GEKuCEV27tKdZV42GWJT4i7m4-185x278.jpg')
    Addon.addDir("Season 14", "", 'https://www.pokemonfire.com/seasons/pokemon-season-14/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/kmfsJG0y9q6y27whVTs8PZWKq4L-185x278.jpg')
    Addon.addDir("Season 15", "", 'https://www.pokemonfire.com/seasons/pokemon-season-15/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/87N3UhDUIBSm2WtmqbJuPMzUDNx-185x278.jpg')
    Addon.addDir("Season 16", "", 'https://www.pokemonfire.com/seasons/pokemon-season-16/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/onYS1yKCej8QNjDamw7qUqmrtD-185x278.jpg')
    Addon.addDir("Season 17", "", 'https://www.pokemonfire.com/seasons/pokemon-season-17/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/Ac69nFUz9mTx6wDCHgxUucvAPph-185x278.jpg')
    Addon.addDir("Season 18", "", 'https://www.pokemonfire.com/seasons/pokemon-season-18/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/w7gdyFjkcJPEmjXe51Lzdd9NxoB-185x278.jpg')
    Addon.addDir("Season 19", "", 'https://www.pokemonfire.com/seasons/pokemon-season-19/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/hS4z6hh38C7WkbBzGIvicnYFvqp-185x278.jpg')
    Addon.addDir("Season 20", "", 'https://www.pokemonfire.com/seasons/pokemon-season-20/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/am5cZ8RVs3HkKGsST0MFuqvDsLh-185x278.jpg')
    Addon.addDir("Season 21", "", 'https://www.pokemonfire.com/seasons/pokemon-season-21/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg')

elif mode == 'refresh':
    xbmc.executebuiltin('Container.Refresh')
# End Pokemon Fire #

##Begin Play Functions##
elif mode == 'play_arconaitv':
    id = Addon.plugin_queries['id']
    r = requests.get('https://www.arconaitv.us/stream.php?id=' + id)
    html_text = r.text
    soup = BeautifulSoup(html_text, 'html.parser')
    scripts = soup.find_all('script')
    for script in scripts:
        if script.string is not None:
            if "document.getElementsByTagName('video')[0].volume = 1.0;" in script.string:
                code = script.string
                startidx = code.find('eval(function(p,a,c,k,e,')
                endidx = code.find('hunterobfuscator =')
                code = code[startidx: endidx]

                if not code.replace(' ', '').startswith('eval(function(p,a,c,k,e,'):
                    code = 'fail'
                break
            else:
                code = 'fail'
        else:
            code = 'fail'

    if code != 'fail':
        USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36'
        addon_handle = int(sys.argv[1])
        unpacked = packer.unpack(code)
        video_location = unpacked[unpacked.rfind('http'): unpacked.rfind('m3u8') + 4]
        play_item = xbmcgui.ListItem(path=video_location + '|User-Agent=%s' % urllib2.quote(USER_AGENT, safe=''))
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90004))

if mode == 'play-youtube':
    videoId = Addon.plugin_queries['videoId']
    stream_status = tvtime.TVtime()._get_json_u('/check' + base64.b64decode('LnBocA=='), {'id': videoId})['status']
    if stream_status == 'true':
        channels.play_youtube(videoId)
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(900024))
        exit()
##End Play Functions##

elif mode == 'tvcatchup':
    tvcatchup_main()

##Begin Live News##
elif mode == 'livenews_main':
    livenews_menu = tvtime.TVtime()._get_json('/menus/livenews' + base64.b64decode('LnBocA=='), {'key': access_key})
    livenews_menu_results = livenews_menu['results']
    for i in sorted(livenews_menu_results, reverse=False):
        if i['status'] == 'on' and i['label'] != 'France 24' and i['label'] != 'RT News':
            Addon.addLink_live(i['label'], "", i['url'], i['mode'], i['img'])
        elif i['status'] == 'on':
            Addon.add_video_item(
                'plugin://plugin.video.tvtime.private/?mode=' + i['mode'] + "&rand=" + Addon.random_generator(),
                {'title': i['label']}, img=i['img'], playable=True)
##End Live News##

##Begin Fluxus IPTV##
elif mode == 'fluxus_main':
    # Set protect flag.
    Addon.set_setting('protect', "true")

    fluxus_menu = tvtime.TVtime()._get_json('/menus/fluxus' + base64.b64decode('LnBocA=='), {'key': access_key})
    fluxus_menu_results = fluxus_menu['results']
    for i in fluxus_menu_results:
        if i['status'] == 'on':
            if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
            Addon.add_directory({'mode': i['mode']}, i['label'], img=icon)

    if Addon.get_setting('enable_adult_sections') == 'true':
        if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))):
            icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))
        else:
            icon = xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
        Addon.add_directory({'mode': "fluxus_lust"}, "Fluxus Lust", img=icon)

elif mode == 'fluxus_iptv':
    fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                            {'key': access_key, 'list': mode.replace("fluxus_","")})
    fluxus_menu_results = fluxus_menu

    # Get Updated Date
    for i in sorted(fluxus_menu_results):
        try:
            if "=" in i['tvtitle']:
                tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass

    # Get Streams
    for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
        try:
            if i['tvgroup'] == "USA" or \
                    i['tvgroup'] == "USA LOCAL" or \
                    i['tvgroup'] == "UK" or \
                    i['tvgroup'] == "CANADA" or \
                    i['tvgroup'] == "AUSTRALIA":
                tvtitle = json.dumps(i['tvtitle']).replace('"','')
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass

elif mode == 'fluxus_cctv' or mode == 'fluxus_faith' or mode == 'fluxus_lust':
    def get_fluxus():
        fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                                {'key': access_key, 'list': mode.replace("fluxus_", "")})
        fluxus_menu_results = fluxus_menu

        # Get Updated Date
        for i in sorted(fluxus_menu_results):
            try:
                if "=" in i['tvtitle']:
                    tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass

        # Get Streams
        for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
            try:
                if i['tvgroup'] != "INFO" and i['tvgroup'] != "LABEL":
                    tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass

    if mode == 'fluxus_lust':
        # Access Key Protection
        if str(Addon.get_setting('protect')) == 'true':
            retval = dlg.input(Addon.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            lock_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': retval})[
                'status']

            if lock_check == 'success':
                # Set protect flag. This will be set back to true once use 'backs out' of Fluxus Lust section.
                Addon.set_setting('protect', "false")

                dlg.ok(Addon.get_string(5000), Addon.get_string(900028))

                get_fluxus()

            else:
                dlg.ok(Addon.get_string(5000), Addon.get_string(80000))
                exit()

        elif str(Addon.get_setting('protect')) == 'false':
            get_fluxus()

    else:
        get_fluxus()

elif mode == 'fluxus_cinema':
    fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                            {'key': access_key, 'list': mode.replace("fluxus_","")})
    fluxus_menu_results = fluxus_menu
    for i in sorted(fluxus_menu_results, reverse=False):
        try:
            if i['tvgroup'] == "MOVIES" or "=" in i['tvtitle']:
                if "=" in i['tvtitle']:
                    tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                else:
                    tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass
##End Fluxus IPTV##

##End Lodge TV IPTV##
elif mode == 'lodge_tv_main':
    stratustv_menu = tvtime.TVtime()._get_json('/lodgetv/v1/get_list' + base64.b64decode('LnBocA=='),
                                               {'key': access_key, 'list': 'english'})
    stratustv_menu_results = stratustv_menu

    # Get Updated Date
    for i in sorted(stratustv_menu_results):
        if "~" not in i['tvtitle'] and "=" in i['tvtitle']:
            tvtitle = "[COLOR blue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
            img = i['tvlogo']

            Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)

    # Get Streams
    for i in sorted(stratustv_menu_results, key=lambda k: k['tvtitle']):
        if "~" not in i['tvtitle'] and "=" not in i['tvtitle']:
            img = i['tvlogo']

            Addon.addLink_live(i['tvtitle'], '', i['tvmedia'], 400, img)
##End Lodge TV IPTV##

##End Stratus TV IPTV##
elif mode == 'stratus_tv_main':
    stratustv_menu = tvtime.TVtime()._get_json('/stratustv/v1/get_list' + base64.b64decode('LnBocA=='),
                                               {'key': access_key, 'list': 'english'})
    stratustv_menu_results = stratustv_menu
    for i in sorted(stratustv_menu_results, key=lambda k: k['tvtitle']):
        try:
            tvtitle = json.dumps(i['tvtitle']).replace('"', '')
            img = i['tvlogo']
            Addon.addLink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass
##End Stratus TV IPTV##

##Begin Live TV Direct##
elif mode == 'livetv_direct_main':
    livetv_direct_menu = tvtime.TVtime()._get_json('/menus/livetv_direct' + base64.b64decode('LnBocA=='),
                                                   {'key': access_key})
    livetv_direct_menu_results = livetv_direct_menu['results']
    for i in livetv_direct_menu_results:
        if i['status'] == 'on':
            Addon.add_video_item(
                'plugin://plugin.video.tvtime.private/?mode=' + i['mode'] + "&rand=" + Addon.random_generator(),
                {'title': i['label']}, img=xbmc.translatePath(
                    os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.png')),
                playable=True)
##End Live TV Direct##

##Begin Live Sports Direct##
elif mode == 'livesports_direct_main':
    livesports_direct_menu = tvtime.TVtime()._get_json('/menus/livesports_direct' + base64.b64decode('LnBocA=='),
                                                       {'key': access_key})
    livesports_direct_menu_results = livesports_direct_menu['results']
    for i in livesports_direct_menu_results:
        if i['status'] == 'on':
            if "nbcs" in i['mode']:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'nbc_sports.jpg'))
            elif "pac" in i['mode']:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', 'pac_12.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.jpg'))
            Addon.add_video_item(
                'plugin://plugin.video.tvtime.private/?mode=' + i['mode'] + "&rand=" + Addon.random_generator(),
                {'title': i['label']}, img=icon, playable=True)
##End Live Sports Direct##

##Begin US TV Catchup##
elif mode == 'us_tvcatchup':
    youtube_channels_menu = tvtime.TVtime()._get_json('/menus/us_tvcatchup' + base64.b64decode('LnBocA=='),
                                                      {'key': access_key})
    youtube_channels_menu_results = youtube_channels_menu['results']
    for i in youtube_channels_menu_results:
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.jpg')))

elif mode == 'hgtv_main':
    hgtv_main()

elif mode == 'travel_main':
    travel_main()

elif mode == 'diy_main':
    diy_main()

elif mode == 'cooking_main':
    cooking_main()

elif mode == 'food_main':
    food_main()

elif mode == 'smith_main':
    smith_main()

elif mode == 'freeform_main':
    freeform_main()

elif mode == 'abc_main':
    abc_main()

elif mode == 'nbc_main':
    nbc_main()

elif mode == 'pbs_main':
    pbs_main()
##End US TV Catchup##

# Begin YouTube Channels #
elif mode == 'youtube_channels':
    youtube_channels_menu = tvtime.TVtime()._get_json('/menus/youtube_channels' + base64.b64decode('LnBocA=='),
                                                      {'key': access_key})
    youtube_channels_menu_results = youtube_channels_menu['results']
    for i in youtube_channels_menu_results:
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.jpg')))

elif mode == 'biography_channel':
    try:
        playlists = tvtime.TVtime().build_biograpy_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'BIOCHANNEL'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "BIOCHANNEL" in mode:
    playlists = tvtime.TVtime().build_biograpy_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'ufo_tv':
    try:
        playlists = tvtime.TVtime().build_ufo_tv_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'UFOTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "UFOTV" in mode:
    playlists = tvtime.TVtime().build_ufo_tv_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'blr':
    try:
        playlists = tvtime.TVtime().build_blr_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'BLRTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "BLRTV" in mode:
    playlists = tvtime.TVtime().build_blr_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'funnyordie':
    try:
        playlists = tvtime.TVtime().build_funnyordie_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'FUNNYORDIETV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "FUNNYORDIETV" in mode:
    playlists = tvtime.TVtime().build_funnyordie_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'joy_of_painting':
    try:
        playlists = tvtime.TVtime().build_joy_of_painting_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'JOYOFPAINTINGTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "JOYOFPAINTINGTV" in mode:
    playlists = tvtime.TVtime().build_joy_of_painting_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'last_week_tonight':
    try:
        playlists = tvtime.TVtime().build_last_week_tonight_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'LASTWEEKTONIGHTTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "LASTWEEKTONIGHTTV" in mode:
    playlists = tvtime.TVtime().build_last_week_tonight_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'mr_bean':
    try:
        playlists = tvtime.TVtime().build_mr_bean_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MRBEANTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MRBEANTV" in mode:
    playlists = tvtime.TVtime().build_mr_bean_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'soul_pancake':
    try:
        playlists = tvtime.TVtime().build_soul_pancake_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'SOULPANCAKETV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "SOULPANCAKETV" in mode:
    playlists = tvtime.TVtime().build_soul_pancake_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'thomas_the_train':
    try:
        playlists = tvtime.TVtime().build_thomas_the_train_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'THOMASTHETRAINTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "THOMASTHETRAINTV" in mode:
    playlists = tvtime.TVtime().build_thomas_the_train_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'missouri_star':
    try:
        playlists = tvtime.TVtime().build_missouri_star()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MISSOURISTARTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MISSOURISTARTV" in mode:
    playlists = tvtime.TVtime().build_missouri_star()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'maverick_movies':
    try:
        playlists = tvtime.TVtime().build_maverick_movies()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MAVERICKMOVIESTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MAVERICKMOVIESTV" in mode:
    playlists = tvtime.TVtime().build_maverick_movies()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])
# End YouTube Channels #

elif mode == 'settings':
    Addon.show_settings()

# Begin TubiTV #
md = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'media', '\\/'))

MUA = 'Mozilla/5.0 (Linux; Android 5.0.2; bg-bg; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19'
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:62.0) Gecko/20100101 Firefox/62.0'


def tubi_categories():
    req = urllib2.Request('http://tubitv.com/oz/containers/')
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'https://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())

    # addDirTubi('Search', 'http://tubitv.com/oz/search/', 'Search Tubi TV', 2, md + 'DefaultAddonsSearch.png')
    try:
        for categories in range(0, len(jsonrsp['list'])):
            try:
                desc = jsonrsp['hash'][jsonrsp['list'][categories]]['description'].decode('utf8', 'ignore').encode(
                    'utf8', 'ignore')
            except:
                desc = ' '
            try:
                Cover = 'http:' + jsonrsp['hash'][jsonrsp['list'][categories]]['thumbnail']
            except:
                Cover = md + 'DefaultFolder.png'
            addDirTubi(jsonrsp['hash'][jsonrsp['list'][categories]]['title'], jsonrsp['list'][categories], desc, 1,
                       Cover)
    except:
        pass


def tubi_index(url):
    try:
        req = urllib2.Request('http://tubitv.com/oz/containers/' + url + '/content?cursor=1&limit=200')
        req.add_header('User-Agent', UA)
        req.add_header('Referer', 'https://tubitv.com/')
        opener = urllib2.build_opener()
        f = opener.open(req)
        jsonrsp = json.loads(f.read())
        # print jsonrsp

        for movie in jsonrsp['contents'].keys():
            try:
                if jsonrsp['contents'][movie]['type'] == 'v':
                    try:
                        addLinkTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'],
                                    str(jsonrsp['contents'][movie]['duration']),
                                    jsonrsp['contents'][movie]['description'].decode('utf8', 'ignore').encode('utf8',
                                                                                                              'ignore'),
                                    jsonrsp['contents'][movie]['year'],
                                    jsonrsp['contents'][movie]['ratings'][0]['value'],
                                    jsonrsp['contents'][movie]['actors'], jsonrsp['contents'][movie]['directors'], 3,
                                    'http:' + jsonrsp['contents'][movie]['posterarts'][0])
                    except:
                        addLinkTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'],
                                    str(jsonrsp['contents'][movie]['duration']), '', jsonrsp['contents'][movie]['year'],
                                    jsonrsp['contents'][movie]['ratings'][0]['value'],
                                    jsonrsp['contents'][movie]['actors'], jsonrsp['contents'][movie]['directors'], 3,
                                    'http:' + jsonrsp['contents'][movie]['posterarts'][0])
                elif jsonrsp['contents'][movie]['type'] == 's':
                    try:
                        addDirTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'],
                                   jsonrsp['contents'][movie]['description'].decode('utf8', 'ignore').encode('utf8',
                                                                                                             'ignore'),
                                   4, 'http:' + jsonrsp['contents'][movie]['posterarts'][0])
                    except:
                        addDirTubi(jsonrsp['contents'][movie]['title'], jsonrsp['contents'][movie]['id'], '', 4,
                                   'http:' + jsonrsp['contents'][movie]['posterarts'][0])
            except:
                pass
            xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
    except:
        xbmcgui.Dialog().ok('Tubi TV', 'This is geo-blocked content!',
                            'You must have USA IP address in order to access this content or services.')


def tubi_search_content(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'http://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())

    for movie in range(0, len(jsonrsp)):
        try:
            if jsonrsp[movie]['type'] == 'v':
                addLinkTubi(jsonrsp[movie]['title'], jsonrsp[movie]['id'], str(jsonrsp[movie]['duration']),
                            jsonrsp[movie]['description'].decode('utf8', 'ignore').encode('utf8', 'ignore'),
                            jsonrsp[movie]['year'], jsonrsp[movie]['ratings'][0]['value'], jsonrsp[movie]['actors'],
                            jsonrsp[movie]['directors'], 3, 'http:' + jsonrsp[movie]['posterarts'][0])
            elif jsonrsp[movie]['type'] == 's':
                addDirTubi(jsonrsp[movie]['title'], jsonrsp[movie]['id'],
                           jsonrsp[movie]['description'].decode('utf8', 'ignore').encode('utf8', 'ignore'), 4,
                           'http:' + jsonrsp[movie]['posterarts'][0])
        except:
            pass
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)


def tubi_episodes(url):
    req = urllib2.Request('http://tubitv.com/oz/videos/0' + url + '/content')
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'http://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())
    # print jsonrsp['k'][0]

    for season in range(0, len(jsonrsp['children'])):
        for episode in range(0, len(jsonrsp['children'][season]['children'])):
            try:
                addLinkTubi(jsonrsp['children'][season]['children'][episode]['title'],
                            jsonrsp['children'][season]['children'][episode]['id'],
                            str(jsonrsp['children'][season]['children'][episode]['duration']),
                            jsonrsp['children'][season]['children'][episode]['description'].decode('utf8',
                                                                                                   'ignore').encode(
                                'utf8', 'ignore'), jsonrsp['children'][season]['children'][episode]['year'],
                            jsonrsp['children'][season]['children'][episode]['ratings'][0]['value'],
                            jsonrsp['children'][season]['children'][episode]['actors'],
                            jsonrsp['children'][season]['children'][episode]['directors'], 3,
                            'http:' + jsonrsp['children'][season]['children'][episode]['thumbnails'][0])
            except:
                pass


def tubi_search(url):
    keyb = xbmc.Keyboard('', 'Search Tubi TV')
    keyb.doModal()
    searchText = ''
    if (keyb.isConfirmed()):
        searchText = urllib.quote_plus(keyb.getText())
        searchText = searchText.replace(' ', '+')
        if searchText == '':
            exit()
            xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.tvtime.private/?mode=tubitv)")
        searchurl = url + searchText
        searchurl = searchurl.encode('utf-8')
        tubi_search_content(searchurl)
    else:
        exit()
        xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.video.tvtime.private/?mode=tubitv)")


def tubi_play(name, url):
    req = urllib2.Request('http://tubitv.com/oz/videos/' + url + '/content')
    req.add_header('User-Agent', UA)
    req.add_header('Referer', 'http://tubitv.com/')
    opener = urllib2.build_opener()
    f = opener.open(req)
    jsonrsp = json.loads(f.read())

    li = xbmcgui.ListItem(iconImage='http:' + jsonrsp['thumbnails'][0],
                          thumbnailImage='http:' + jsonrsp['thumbnails'][0],
                          path='http:' + jsonrsp['url'] + '|User-Agent=stagefright&Referer=http://tubitv.com')
    li.setInfo(type="Video", infoLabels={"Title": name, "Plot": jsonrsp[
        'description']})  # .decode('utf8', 'ignore').encode('utf8', 'ignore')
    try:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    except:
        xbmc.executebuiltin("Notification('Tubi TV','Video Not Found!')")


    xbmc.Player().showSubtitles(False)


def addLinkTubi(name, url, vd, plot, year, mpaa, cast, director, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setArt({'thumb': iconimage, 'poster': iconimage, 'banner': iconimage, 'fanart': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setInfo(type="Video", infoLabels={"Duration": vd, "Plot": plot})
    liz.setInfo(type="Video", infoLabels={"Year": year, "Mpaa": mpaa})
    liz.setInfo(type="Video", infoLabels={"Cast": cast, "Director": director})
    liz.addStreamInfo('video', {'aspect': 1.78, 'codec': 'h264'})
    liz.addStreamInfo('audio', {'codec': 'aac', 'channels': 2})
    liz.setProperty("IsPlayable", "true")
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok


def addDirTubi(name, url, desc, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": desc})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
# End Tubi TV #


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()
if mode != 'tubitv':
    url = 'null'
else:
    url = None
name = None
mode = None
iconimage = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    name = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

##This is for the Tubi TV stuff##
if mode == 'tubitv' or url == None or len(url) < 1:
    tubi_categories()

##This is for the TubiTV stuff##
elif mode == 1:
    tubi_index(url)

##This is for the TubiTV stuff##
elif mode == 2:
    tubi_search(url)

##This is for the TubiTV stuff##
elif mode == 3:
    tubi_play(name, url)

##This is for the TubiTV stuff##
elif mode == 4:
    tubi_episodes(url)

##This is for the TVCatchup.com stuff##
elif mode == 5:
    tvcatchup(url)

##This is for the HGTV stuff##
elif mode == 6:
    hgtv_episodes(url)

##This is for the HGTV stuff##
elif mode == 7:
    hgtv_stream(url)

##This is for the Travel Channel stuff##
elif mode == 8:
    travel_episodes(url)

##This is for the Travel Channel stuff##
elif mode == 9:
    travel_stream(url)

##This is for the DIY Network stuff##
elif mode == 10:
    diy_episodes(url)

##This is for the DIY Network stuff##
elif mode == 11:
    diy_stream(url)

##This is for the Cooking Channel stuff##
elif mode == 12:
    cooking_episodes(url)

##This is for the Cooking Channel stuff##
elif mode == 13:
    cooking_stream(url)

##This is for the Food Network stuff##
elif mode == 14:
    food_episodes(url)

##This is for the Food Network stuff##
elif mode == 15:
    food_stream(url)

##This is for the Smithsonian Channel stuff##
elif mode == 20:
    smith_stream(url)

##This is for the Freeform stuff##
elif mode == 21:
    freeform_episodes(url)

##This is for the Freeform stuff##
elif mode == 22:
    freeform_stream(url)

##This is for the Freeform stuff##
elif mode == 23:
    freeform_movies(url)

##This is for the ABC stuff##
elif mode == 24:
    abc_seasons(url, name, iconimage)

##This is for the ABC stuff##
elif mode == 25:
    abc_episodes(url)

##This is for the ABC stuff##
elif mode == 26:
    abc_stream(url)

##This is for the NBC stuff##
elif mode == 27:
    nbc_episodes(url)

##This is for the NBC stuff##
elif mode == 28:
    nbc_stream(url)

##This is for the PBS stuff##
elif mode == 29:
    pbs_episodes(url)

##This is for the PBS stuff##
elif mode == 30:
    pbs_stream(url)

##These are for the Live News Streams##
elif mode == 100:
    livenews_stream(url, name)
elif mode == 101:
    channels.Channel().play_cbs_news()
elif mode == 102:
    channels.Channel().play_newsy()
elif mode == 103:
    channels.Channel().play_sky_news()
elif mode == 104:
    channels.Channel().play_aljazeera()
elif mode == 105:
    cnn_stream(url, name)
elif mode == 106:
    foxnews_stream(url, name)
elif mode == 107:
    msnbc_stream(url, name)
elif mode == 108:
    channels.Channel().play_cheddar()
elif mode == 110:
    channels.Channel().play_rt()
elif mode == 111:
    channels.Channel().play_newsmax_tv()
elif mode == 112:
    cspan_stream(url, name)
elif mode == 113:
    cspan_stream(url, name)

##Fluxus, Lodge TV, and Stratus TV IPTV##
elif mode == 400:
    Addon.play_generic(url)

elif mode == 500:
    pokemon_fire_seasons(url)

elif mode == 501:
    pokemon_fire_play(url)

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass
try:
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:
    group = urllib.unquote_plus(params["group"])
except:
    pass


Addon.end_of_directory()
