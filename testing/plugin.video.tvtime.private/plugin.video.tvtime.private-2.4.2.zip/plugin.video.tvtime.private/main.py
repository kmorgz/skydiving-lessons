"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import json
import os
import sys
import urllib
import urllib2
import jsbeautifier.unpackers.packer as packer
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from datetime import datetime, timedelta
import time
from bs4 import BeautifulSoup
from resources.lib import Addon, tvtime
from resources.lib import channels
import m7lib

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')

Addon.plugin_url = sys.argv[0]
Addon.plugin_handle = int(sys.argv[1])
Addon.plugin_queries = Addon.parse_query(sys.argv[2][1:])

dlg = xbmcgui.Dialog()
dlg_progress = xbmcgui.DialogProgress()

addon_logo = xbmc.translatePath(os.path.join(plugin_path, 'icon.png'))

mode = Addon.plugin_queries['mode']

access_key = str(Addon.get_setting('access_key'))

key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})['status']

if key_check == 'offline':
    dlg.ok(Addon.get_string(5000), Addon.get_string(90000))
    exit()

if key_check != 'success':
    # Enter Access Key
    retval = dlg.input(Addon.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if retval and len(retval) > 0:
        Addon.set_setting('access_key', str(retval))
        access_key = Addon.get_setting('access_key')
        key_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': access_key})[
            'status']
    if len(Addon.get_setting('access_key')) > 0 and key_check == 'success':
        dlg.ok(Addon.get_string(5000), Addon.get_string(70000))
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(80000))
        exit()

# Begin Live TV Direct #
free_live_tv_extra_channels = [
    {"name": "ABC News", "type": "News"},
    {"name": "CBSN", "type": "News"},
    {"name": "CBSN New York", "type": "News"},
    {"name": "CBS Sports HQ", "type": "Sports"},
    {"name": "CNN", "type": "News"},
    {"name": "ET Live", "type": "Celebrity"},
    {"name": "MLB Network", "type": "Sports"},
    {"name": "MSNBC", "type": "News"},
    {"name": "NBC Golf", "type": "Sports"},
    {"name": "NBC Sports (Boston)", "type": "Sports"},
    {"name": "NBC Sports (California)", "type": "Sports"},
    {"name": "NBC Sports (Northwest)", "type": "Sports"}
]
# End Live TV Direct #

# Begin Xumo TV & Movies #
XUMO_BASE_API = 'https://valencia-app-mds.xumo.com/v2/%s'
XUMO_BASE_LOGO = 'https://image.xumo.com/v1/channels/channel/%s/512x512.png?type=color_onBlack'
XUMO_BASE_THUMB = 'https://image.xumo.com/v1/assets/asset/%s/512x512.jpg'
# End Xumo TV & Movies #


##Begin Pokemon Fire##
def pokemon_fire_seasons(url):
    link = m7lib.Common.open_url(url)
    matches = Addon.find_multiple_matches(link, '<div class="imagen">(.*?)</li>')

    for entry in matches:
        name = Addon.find_single_match(entry, '/">(.+?)</a>', 1).encode('latin-1')
        description = Addon.find_single_match(entry, '<span class="date">(.+?)</span>')
        url = Addon.find_single_match(entry, '<a href="(.+?)"')
        iconimage = Addon.find_single_match(entry, '<img src="(.+?)"')

        Addon.add_link(name, description, url, 501, iconimage)


def pokemon_fire_play(url):
    player_match_string = '<iframe class="metaframe rptss" src="(.*?)"'
    stream_match_string = 'file: \'(.*?)\''

    # Get Player
    req = m7lib.Common.open_url(url)
    player_url = Addon.find_single_match(req, player_match_string, 1)

    # Get Stream
    req = m7lib.Common.open_url(player_url)
    stream = Addon.find_single_match(req, stream_match_string)

    if 'mp4' in stream:
        m7lib.Common.play(stream)
    else:
        dlg.ok("TV Time Private", "Unable to get stream. Please try again later.")
##End Pokemon Fire##


# Start YouTube Playlist Channels #
def show_streams(title, playlist_id):
    if title in mode:
        streams = tvtime.TVtime().get_streams(playlist_id)
        if streams:
            for c in streams:
                title = c['title']
                channel = c['title']
                videoId = c['videoId']
                img = c['img']
                rURL = Addon.plugin_url + "?channel=" + channel + "&videoId=" + videoId + "&mode=play-youtube"
                Addon.add_video_item(rURL, {'title': title}, img=img)
# End YouTube Playlist Channels #


if mode == 'main':
    main_menu = tvtime.TVtime()._get_json('/menus/main' + base64.b64decode('LnBocA=='), {'key': access_key})
    main_menu_results = main_menu['results']
    for i in main_menu_results:
        if i['status'] == 'on':
            if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
            Addon.add_directory({'mode': i['mode']}, i['label'], img=icon)

    if len(Addon.get_setting('notify')) > 0:
        Addon.set_setting('notify', str(int(Addon.get_setting('notify')) + 1))
    else:
        Addon.set_setting('notify', "1")
    if int(Addon.get_setting('notify')) == 1:
        dlg.notification('Like ' + addonname + ' Private?', 'Keep it Private!', addon_logo, 5000, False)
    elif int(Addon.get_setting('notify')) == 9:
        Addon.set_setting('notify', "0")

##Begin ArconaiTV##
elif mode == 'arconaitv':
    arconaitv_menu = tvtime.TVtime()._get_json('/menus/arconaitv' + base64.b64decode('LnBocA=='), {'key': access_key})
    arconaitv_menu_results = arconaitv_menu['results']
    for i in arconaitv_menu_results:
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg')))

elif mode == 'arconaitv_live':
    channels = tvtime.TVtime().get_arconaitv_streams('Cable')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'logos', c['img']))
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)

elif mode == 'tv_show_channels':
    channels = tvtime.TVtime().get_arconaitv_streams('Shows')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = c['img']
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)

elif mode == 'movie_channels':
    channels = tvtime.TVtime().get_arconaitv_streams('Movies')
    if channels:
        for c in sorted(channels, reverse=False):
            channel = c['channel']
            id = c['id']
            rURL = "plugin://plugin.video.tvtime.private/?id=" + id + "&mode=play_arconaitv&rand=" + Addon.random_generator()
            logo = xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
            cm_refresh = (Addon.get_string(40000), 'XBMC.RunPlugin(%s/?mode=refresh)' % (Addon.plugin_url))
            cm_menu = [cm_refresh]
            Addon.add_video_item(rURL, {'title': channel}, img=logo, playable=True, HD="Medium", cm=cm_menu,
                                 cm_replace=False)
##End ArconaiTV##

# Begin Live Channels#
elif mode == 'MLB Network':
    channels.Channel().play_live_tv_direct(mode)

elif mode == 'NBC Sports (Northwest)':
    channels.Channel().play_live_tv_direct(mode)

elif mode == 'NBC Sports (Boston)':
    channels.Channel().play_live_tv_direct(mode)

elif mode == 'NBC Sports (California)':
    channels.Channel().play_live_tv_direct(mode)

elif mode == 'NBC Golf':
    channels.Channel().play_live_tv_direct(mode)

elif mode == 'ET Live':
    channels.Channel().play_et_live(mode)

elif mode == 'ABC News':
    channels.Channel().play_abc_news(mode)

elif mode == "CBS Sports HQ":
    channels.Channel().play_cbs_sports_hq(mode)

elif mode == 'CNN':
    channels.Channel().play_cnn(mode)

elif mode == 'CBSN':
    channels.Channel().play_cbs_news(mode)

elif mode == 'CBSN New York':
    channels.Channel().play_cbs_news_ny(mode)

elif mode == 'MSNBC':
    channels.Channel().play_msnbc(mode)
# End Live Channels#

# End Pokemon Fire #
elif mode == 'pokemon_fire':
    Addon.add_dir("Season 1", "", 'https://www.pokemonfire.com/seasons/pokemon-season-1/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg')
    Addon.add_dir("Season 2", "", 'https://www.pokemonfire.com/seasons/pokemon-season-2/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/xQDFEDLKeNoMUblTCVHGdqDTZHh-185x278.jpg')
    Addon.add_dir("Season 3", "", 'https://www.pokemonfire.com/seasons/pokemon-season-3/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/piTE2EIhMNeV1aHiTnq36tUc5eB-185x278.jpg')
    Addon.add_dir("Season 4", "", 'https://www.pokemonfire.com/seasons/pokemon-season-4/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/yjAq5sILzVzIBfWtVLdxD8AEjGM-185x278.jpg')
    Addon.add_dir("Season 5", "", 'https://www.pokemonfire.com/seasons/pokemon-season-5/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/4Tr6pjlKidQbSPp6wKf855Sq3L1-185x278.jpg')
    Addon.add_dir("Season 6", "", 'https://www.pokemonfire.com/seasons/pokemon-season-6/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/1dNnm3ghzcnxM9M80NnBnDGmnZI-185x278.jpg')
    Addon.add_dir("Season 7", "", 'https://www.pokemonfire.com/seasons/pokemon-season-7/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/mziBTfCtoeXTUAefm4hordE7OaQ-185x278.jpg')
    Addon.add_dir("Season 8", "", 'https://www.pokemonfire.com/seasons/pokemon-season-8/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/kJ5s8pS0FkgqZvMvKz2dlEoZsqz-185x278.jpg')
    Addon.add_dir("Season 9", "", 'https://www.pokemonfire.com/seasons/pokemon-season-9/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/6BDDH5EHiAHjfVGhi8FQc2xuDG0-185x278.jpg')
    Addon.add_dir("Season 10", "", 'https://www.pokemonfire.com/seasons/pokemon-season-10/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/9abTHX6IcyiZAXiVDQMM5jKWQDy-185x278.jpg')
    Addon.add_dir("Season 11", "", 'https://www.pokemonfire.com/seasons/pokemon-season-11/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/ny1FRSXWEtLCeevlCyq3DuVO4wF-185x278.jpg')
    Addon.add_dir("Season 12", "", 'https://www.pokemonfire.com/seasons/pokemon-season-12/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/1vBe4qmVe3R5UBLocan15WFuIJk-185x278.jpg')
    Addon.add_dir("Season 13", "", 'https://www.pokemonfire.com/seasons/pokemon-season-13/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/l5GEKuCEV27tKdZV42GWJT4i7m4-185x278.jpg')
    Addon.add_dir("Season 14", "", 'https://www.pokemonfire.com/seasons/pokemon-season-14/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/kmfsJG0y9q6y27whVTs8PZWKq4L-185x278.jpg')
    Addon.add_dir("Season 15", "", 'https://www.pokemonfire.com/seasons/pokemon-season-15/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/87N3UhDUIBSm2WtmqbJuPMzUDNx-185x278.jpg')
    Addon.add_dir("Season 16", "", 'https://www.pokemonfire.com/seasons/pokemon-season-16/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/onYS1yKCej8QNjDamw7qUqmrtD-185x278.jpg')
    Addon.add_dir("Season 17", "", 'https://www.pokemonfire.com/seasons/pokemon-season-17/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/Ac69nFUz9mTx6wDCHgxUucvAPph-185x278.jpg')
    Addon.add_dir("Season 18", "", 'https://www.pokemonfire.com/seasons/pokemon-season-18/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/w7gdyFjkcJPEmjXe51Lzdd9NxoB-185x278.jpg')
    Addon.add_dir("Season 19", "", 'https://www.pokemonfire.com/seasons/pokemon-season-19/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/hS4z6hh38C7WkbBzGIvicnYFvqp-185x278.jpg')
    Addon.add_dir("Season 20", "", 'https://www.pokemonfire.com/seasons/pokemon-season-20/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2017/10/am5cZ8RVs3HkKGsST0MFuqvDsLh-185x278.jpg')
    Addon.add_dir("Season 21", "", 'https://www.pokemonfire.com/seasons/pokemon-season-21/', 500, 'https://www.pokemonfire.com/wp-content/uploads/2018/08/fhAUZODeJy3tK0gUnw6a9JbR0iM.jpg')

elif mode == 'refresh':
    xbmc.executebuiltin('Container.Refresh')
# End Pokemon Fire #

##Begin Play Functions##
elif mode == 'play_arconaitv':
    id = Addon.plugin_queries['id']
    r = requests.get('https://www.arconaitv.us/stream.php?id=' + id)
    html_text = r.text
    soup = BeautifulSoup(html_text, 'html.parser')
    scripts = soup.find_all('script')
    for script in scripts:
        if script.string is not None:
            if "document.getElementsByTagName('video')[0].volume = 1.0;" in script.string:
                code = script.string
                startidx = code.find('eval(function(p,a,c,k,e,')
                endidx = code.find('hunterobfuscator =')
                code = code[startidx: endidx]

                if not code.replace(' ', '').startswith('eval(function(p,a,c,k,e,'):
                    code = 'fail'
                break
            else:
                code = 'fail'
        else:
            code = 'fail'

    if code != 'fail':
        USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36'
        addon_handle = int(sys.argv[1])
        unpacked = packer.unpack(code)
        video_location = unpacked[unpacked.rfind('http'): unpacked.rfind('m3u8') + 4]
        play_item = xbmcgui.ListItem(path=video_location + '|User-Agent=%s' % urllib2.quote(USER_AGENT, safe=''))
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90004))

elif mode == 'play-youtube':
    videoId = Addon.plugin_queries['videoId']
    stream_status = tvtime.TVtime()._get_json_u('/check' + base64.b64decode('LnBocA=='), {'id': videoId})['status']
    if stream_status == 'true':
        channels.play_youtube(videoId)
    else:
        dlg.ok(Addon.get_string(5000), Addon.get_string(900024))
        exit()
##End Play Functions##

##Begin Fluxus IPTV##
elif mode == 'fluxus_main':
    # Set protect flag.
    Addon.set_setting('protect', "true")

    fluxus_menu = tvtime.TVtime()._get_json('/menus/fluxus' + base64.b64decode('LnBocA=='), {'key': access_key})
    fluxus_menu_results = fluxus_menu['results']
    for i in fluxus_menu_results:
        if i['status'] == 'on':
            if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))):
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], i['icon'] + '.jpg'))
            else:
                icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', i['skin'], 'static_tv.jpg'))
            Addon.add_directory({'mode': i['mode']}, i['label'], img=icon)

    if Addon.get_setting('enable_adult_sections') == 'true':
        if os.path.isfile(xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))):
            icon = xbmc.translatePath(os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'fluxus_lust.jpg'))
        else:
            icon = xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'skin', 'main', 'static_tv.jpg'))
        Addon.add_directory({'mode': "fluxus_lust"}, "Fluxus Lust", img=icon)

elif mode == 'fluxus_iptv':
    fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                            {'key': access_key, 'list': mode.replace("fluxus_","")})
    fluxus_menu_results = fluxus_menu

    # Get Updated Date
    for i in sorted(fluxus_menu_results):
        try:
            if "=" in i['tvtitle']:
                tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                if "tvlogo" not in tvtitle:
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    Addon.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass

    # Get Streams
    for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
        try:
            if i['tvgroup'] == "USA" or \
                    i['tvgroup'] == "USA LOCAL" or \
                    i['tvgroup'] == "UK" or \
                    i['tvgroup'] == "CANADA" or \
                    i['tvgroup'] == "AUSTRALIA":
                tvtitle = json.dumps(i['tvtitle']).replace('"','')
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass

elif mode == 'fluxus_cctv' or mode == 'fluxus_faith' or mode == 'fluxus_lust':
    def get_fluxus():
        fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                                {'key': access_key, 'list': mode.replace("fluxus_", "")})
        fluxus_menu_results = fluxus_menu

        # Get Updated Date
        for i in sorted(fluxus_menu_results):
            try:
                if "=" in i['tvtitle']:
                    tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    Addon.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass

        # Get Streams
        for i in sorted(fluxus_menu_results, key=lambda k: k['tvtitle']):
            try:
                if i['tvgroup'] != "INFO" and i['tvgroup'] != "LABEL" and "* Fluxus Lust" not in i['tvtitle']:
                    tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                    if i['tvlogo'] == "":
                        img = 'https://i.imgur.com/CvQCnwZ.png'
                    else:
                        img = i['tvlogo']
                    Addon.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
            except KeyError:
                pass

    if mode == 'fluxus_lust':
        # Access Key Protection
        if str(Addon.get_setting('protect')) == 'true':
            retval = dlg.input(Addon.get_string(60000), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            lock_check = tvtime.TVtime()._get_json('/check_key' + base64.b64decode('LnBocA=='), {'key': retval})[
                'status']

            if lock_check == 'success':
                # Set protect flag. This will be set back to true once use 'backs out' of Fluxus Lust section.
                Addon.set_setting('protect', "false")

                dlg.ok(Addon.get_string(5000), Addon.get_string(900028))

                get_fluxus()

            else:
                dlg.ok(Addon.get_string(5000), Addon.get_string(80000))
                exit()

        elif str(Addon.get_setting('protect')) == 'false':
            get_fluxus()

    else:
        get_fluxus()

elif mode == 'fluxus_cinema':
    fluxus_menu = tvtime.TVtime()._get_json('/fluxus/v1/get_list' + base64.b64decode('LnBocA=='),
                                            {'key': access_key, 'list': mode.replace("fluxus_","")})
    fluxus_menu_results = fluxus_menu
    for i in sorted(fluxus_menu_results, reverse=False):
        try:
            if i['tvgroup'] == "MOVIES" or "=" in i['tvtitle']:
                if "=" in i['tvtitle']:
                    tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
                else:
                    tvtitle = json.dumps(i['tvtitle']).replace('"', '')
                if i['tvlogo'] == "":
                    img = 'https://i.imgur.com/CvQCnwZ.png'
                else:
                    img = i['tvlogo']
                Addon.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass
##End Fluxus IPTV##

##End Lodge TV IPTV##
elif mode == 'lodge_tv_main':
    lodgetv_menu = tvtime.TVtime()._get_json('/lodgetv/v1/get_list' + base64.b64decode('LnBocA=='),
                                               {'key': access_key, 'list': 'english'})
    lodgetv_menu_results = lodgetv_menu

    # Get Updated Date
    for i in sorted(lodgetv_menu_results):
        if "~" not in i['tvtitle'] and "=" in i['tvtitle']:
            tvtitle = "[COLOR lightskyblue]" + i['tvtitle'].replace("=", "** Updated:") + " **[/COLOR]"
            img = i['tvlogo']

            Addon.addlink_live(tvtitle, '', i['tvmedia'], 400, img)

    # Get Streams
    for i in sorted(lodgetv_menu_results, key=lambda k: k['tvtitle']):
        if "~" not in i['tvtitle'] and "=" not in i['tvtitle'] and ">" not in i['tvtitle']:
            img = i['tvlogo']

            Addon.addlink_live(i['tvtitle'], '', i['tvmedia'], 400, img)
##End Lodge TV IPTV##

##End Stratus TV IPTV##
elif mode == 'stratus_tv_main':
    stratustv_menu = tvtime.TVtime()._get_json('/stratustv/v1/get_list' + base64.b64decode('LnBocA=='),
                                               {'key': access_key, 'list': 'english'})
    stratustv_menu_results = stratustv_menu
    for i in sorted(stratustv_menu_results, key=lambda k: k['tvtitle']):
        try:
            tvtitle = json.dumps(i['tvtitle']).replace('"', '')
            img = i['tvlogo']
            Addon.addlink_live(tvtitle, '', i['tvmedia'], 400, img)
        except KeyError:
            pass
##End Stratus TV IPTV##

##Begin Free Live TV Direct##
elif mode == 'free_livetv_direct_main':
    # Generate Section List
    for section in sorted(m7lib.Common.get_sections(), reverse=False):
        m7lib.Common.add_section(section, m7lib.Common.get_logo(section, "section"), Addon.FANART)
##End Live TV Direct##

# Begin YouTube Channels #
elif mode == 'youtube_channels':
    youtube_channels_menu = tvtime.TVtime()._get_json('/menus/youtube_channels' + base64.b64decode('LnBocA=='),
                                                      {'key': access_key})
    youtube_channels_menu_results = youtube_channels_menu['results']
    for i in youtube_channels_menu_results:
        if i['status'] == 'on':
            Addon.add_directory({'mode': i['mode']}, i['label'], img=xbmc.translatePath(
                os.path.join(plugin_path, 'resources', 'images', 'logos', i['mode'] + '.jpg')))

elif mode == 'biography_channel':
    try:
        playlists = tvtime.TVtime().build_biograpy_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'BIOCHANNEL'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "BIOCHANNEL" in mode:
    playlists = tvtime.TVtime().build_biograpy_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'ufo_tv':
    try:
        playlists = tvtime.TVtime().build_ufo_tv_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'UFOTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "UFOTV" in mode:
    playlists = tvtime.TVtime().build_ufo_tv_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'blr':
    try:
        playlists = tvtime.TVtime().build_blr_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'BLRTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "BLRTV" in mode:
    playlists = tvtime.TVtime().build_blr_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'funnyordie':
    try:
        playlists = tvtime.TVtime().build_funnyordie_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'FUNNYORDIETV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "FUNNYORDIETV" in mode:
    playlists = tvtime.TVtime().build_funnyordie_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'joy_of_painting':
    try:
        playlists = tvtime.TVtime().build_joy_of_painting_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'JOYOFPAINTINGTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "JOYOFPAINTINGTV" in mode:
    playlists = tvtime.TVtime().build_joy_of_painting_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'last_week_tonight':
    try:
        playlists = tvtime.TVtime().build_last_week_tonight_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'LASTWEEKTONIGHTTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "LASTWEEKTONIGHTTV" in mode:
    playlists = tvtime.TVtime().build_last_week_tonight_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'mr_bean':
    try:
        playlists = tvtime.TVtime().build_mr_bean_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MRBEANTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MRBEANTV" in mode:
    playlists = tvtime.TVtime().build_mr_bean_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'soul_pancake':
    try:
        playlists = tvtime.TVtime().build_soul_pancake_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'SOULPANCAKETV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "SOULPANCAKETV" in mode:
    playlists = tvtime.TVtime().build_soul_pancake_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'thomas_the_train':
    try:
        playlists = tvtime.TVtime().build_thomas_the_train_main()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'THOMASTHETRAINTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "THOMASTHETRAINTV" in mode:
    playlists = tvtime.TVtime().build_thomas_the_train_main()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'missouri_star':
    try:
        playlists = tvtime.TVtime().build_missouri_star()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MISSOURISTARTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MISSOURISTARTV" in mode:
    playlists = tvtime.TVtime().build_missouri_star()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])

elif mode == 'maverick_movies':
    try:
        playlists = tvtime.TVtime().build_maverick_movies()
        if playlists:
            for c in sorted(playlists):
                Addon.add_directory({'mode': c['title'] + 'MAVERICKMOVIESTV'}, c['title'], img = c['img'])
    except:
        dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
        exit()

elif "MAVERICKMOVIESTV" in mode:
    playlists = tvtime.TVtime().build_maverick_movies()
    if playlists:
        for c in playlists:
            show_streams(c['title'], c['playlist_id'])
# End YouTube Channels #

elif mode == "settings":
    Addon.show_settings()

# Begin Xumo TV & Movies #
elif mode == "xumo_direct_main":
    req = m7lib.Common().open_url(XUMO_BASE_API%"channels/list/10006.json?q=genreid:195")
    stations_json = json.loads(req)
    stations = stations_json["channel"]["item"]

    for i in sorted(stations, key=lambda k: k['title']):
        logo = XUMO_BASE_LOGO % (i["guid"]["value"])
        if i["title"] != "Docurama":
            m7lib.Common.add_section(i["title"] + "-xumo-channel_" + i["guid"]["value"], logo, Addon.FANART, i["title"])
        else:
            m7lib.Common.add_channel("xumo-stream_XM0CHNSP1IRFM6" , logo, Addon.FANART, i["title"])

elif "xumo-channel_" in mode:
    channel_id = mode.split('_', 1)[-1]
    req = m7lib.Common().open_url(XUMO_BASE_API%"channels/channel/%s/categories.json" % channel_id)
    categories_json = json.loads(req)
    categories = categories_json["categories"]

    for i in sorted(categories, key=lambda k: k['title']):
        title = i["title"].replace("&", "and")
        if ":" not in title:
            cat_id = i["categoryId"]
            logo = XUMO_BASE_LOGO % channel_id
            m7lib.Common.add_section(channel_id + "-xumo-category_" + cat_id, logo, Addon.FANART, title)

elif "-xumo-category_" in mode:
    cat_id = mode.split('_', 1)[-1]
    channel_id = mode.split('-')[0]
    req = m7lib.Common().open_url(XUMO_BASE_API%"categories/category/%s.json?f=asset.title&f=asset.episodeTitle" % cat_id)

    movies_json = json.loads(req)
    movies = movies_json["results"]

    # Create Xumo cache directory #
    xumo_path = xbmc.translatePath('special://home/userdata/addon_data/' + addonid + '/xumo/')
    if not os.path.exists(xumo_path):
        os.mkdir(xumo_path)

    # Clean Xumo cache if cache is older than 30 days #
    if Addon.get_setting('xumo_cache') != "0":
        if datetime(*(time.strptime(Addon.get_setting('xumo_cache'), "%Y-%m-%d %H:%M:%S.%f")[0:6])) < datetime.now():
            Addon.set_setting('xumo_cache', "0")
            if os.path.exists(xumo_path):
                for root, dirs, files in os.walk(xumo_path):
                    for currentFile in files:
                        os.remove(os.path.join(root, currentFile))

    # Xumo cache progress
    progress = [1]
    progress_heading = 'Caching images...'
    progress_message = 'Section will load faster next time. Cache is cleared every 30 days.'

    for i in sorted(movies, key=lambda k: k['title']):
        logo_cache_path = xumo_path + i['id'] + '.jpg'
        if Addon.exists_local(logo_cache_path):
            if Addon.is_non_zero_file(logo_cache_path):
                logo = logo_cache_path
            else:
                logo = XUMO_BASE_LOGO % channel_id
        else:
            # Set Xumo cache date
            if Addon.get_setting('xumo_cache') == "0":
                Addon.set_setting('xumo_cache', str(datetime.now() + timedelta(days=30)))

            # Create Xumo progress bar
            dlg_progress.create(progress_heading, progress_message)

            # If Xumo progress dialog is canceled exit
            if dlg_progress.iscanceled():
                exit()
            urllib.urlretrieve(XUMO_BASE_THUMB % i["id"], logo_cache_path)

            # Increment progress bar
            progress.append(1)

            if Addon.exists_local(logo_cache_path):
                if Addon.is_non_zero_file(logo_cache_path):
                    logo = logo_cache_path
                else:
                    logo = XUMO_BASE_LOGO % channel_id
            else:
                logo = XUMO_BASE_LOGO % channel_id

            # Update Xumo progress bar
            dlg_progress.update(int(len(progress) * (100 / len(movies))), " ", "Images cached: [COLOR lightskyblue]" +
                                str(len(progress) - 1) + "[/COLOR] of [COLOR lightskyblue]" + str(len(movies)) + "[/COLOR]")

        m7lib.Common.add_channel("xumo-stream_" + i["id"], logo, Addon.FANART, i["title"])

elif "xumo-stream_" in mode:
    try:
        stream_id = mode.split('_', 1)[-1]
        req = m7lib.Common().open_url(XUMO_BASE_API%"/assets/asset/%s.json?f=title&f=providers" % stream_id)

        stream_json = json.loads(req)
        stream = m7lib.Common.rebase(stream_json["providers"][0]["sources"][0]["uri"])
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            channels.dlg_failed(channels.addon_name)
    except:
        channels.dlg_failed(channels.addon_name)
# End Xumo TV & Movies #

# Begin Free Live TV (Extra) #
elif mode == "All Channels":
    channel_list = []
    extra_channels = []

    m7lib_channels = m7lib.Common.get_channels()

    # Get channels from m7lib
    for channel in m7lib_channels:
        channel_list.append(channel["name"])

    # Add extra channels
    for channel in free_live_tv_extra_channels:
        channel_list.append(channel["name"])

    # Create extra channels array
    for channel in free_live_tv_extra_channels:
        extra_channels.append(channel["name"])

    # Build channel list
    for channel in sorted(channel_list, key=str.lower):
        if channel in extra_channels:
            channel_logo = channels.get_channel_logo(channel)
        else:
            channel_logo = m7lib.Common.get_logo(channel)

        m7lib.Common.add_channel(channel, channel_logo, Addon.FANART)

elif mode == "Genres":
    # Generate Genre List
    for genre in sorted(m7lib.Common.get_genres(), reverse=False):
        m7lib.Common.add_section(genre, m7lib.Common.get_logo(genre, "genre"), Addon.FANART)

elif mode in m7lib.Common.get_genres():
    channel_list = []
    extra_channels = []

    m7lib_channels = m7lib.Common.get_channels()

    # Get channels from m7lib
    for channel in m7lib_channels:
        if mode in channel["type"]:
            channel_list.append(channel["name"])

    # Add extra channels
    for channel in free_live_tv_extra_channels:
        if mode in channel["type"]:
            channel_list.append(channel["name"])

    # Create extra channels array
    for channel in free_live_tv_extra_channels:
        extra_channels.append(channel["name"])

    # Build channel list within given genre
    for channel in sorted(channel_list, key=str.lower):
        if channel in extra_channels:
            channel_logo = channels.get_channel_logo(channel)
        else:
            channel_logo = m7lib.Common.get_logo(channel)

        m7lib.Common.add_channel(channel, channel_logo, Addon.FANART)

else:
    m7lib.Common.get_stream_and_play(mode)
# End Free Live TV (Extra) #


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()

url = None
name = None
mode = None
iconimage = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    name = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

##Fluxus, Lodge TV, and Stratus TV IPTV##
if mode == 400:
    m7lib.Common.play(url)

elif mode == 500:
    pokemon_fire_seasons(url)

elif mode == 501:
    pokemon_fire_play(url)


Addon.end_of_directory()
