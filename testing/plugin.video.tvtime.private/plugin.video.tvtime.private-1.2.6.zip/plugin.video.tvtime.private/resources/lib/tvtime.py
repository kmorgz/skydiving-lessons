'''
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys, os, re
import urllib, urllib2
from urllib2 import urlopen
import json, random
import xbmcgui, xbmc, xbmcvfs, base64
import Addon

import urlresolver

class TVtime:

    def __init__(self):
        self.dlg = xbmcgui.Dialog()
        self.mBASE = base64.b64decode('aHR0cDovL21oYW5jb2M3LnNvdXJjZWNvZGUuYWcvdHZ0aW1lX3ByaXZhdGUv')
        self.uBASE = base64.b64decode('aHR0cDovL20udXN0dm5vdy5jb20=')
        self.access_key = str(Addon.get_setting('access_key'))

    def get_channels(self, quality):
	content = self._get_json('/ustvnow/v1/playingnow' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'channel': i['channel'],
	            'title': i['title'],
	            'image': i['img'],
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90003))
            exit()

    def get_link(self, get_channel, quality):
	content = self._get_json('/ustvnow/v1/playingnow' + base64.b64decode('LnBocA=='), {'key': self.access_key})
	channels = []
	results = content['results'];
        if results:
	    quality = (quality + 1)
	    passkey = self._get_passkey()
	    token = self._get_token()
	    for i in results:
	        channel = i['channel'];
                if channel == get_channel:
	            stream = self._get_json_u('stream/1/live/view', {'token': token, 'key': passkey, 'scode': i['scode']})['stream']
                    if quality == 4:
		        url = stream
                    else:
	                url = stream.replace('smil:', 'mp4:').replace('USTVNOW1', 'USTVNOW').replace('USTVNOW', 'USTVNOW' + str(quality))
	            channels.append({
	                'channel': channel,
	                'url': url
	                })
	    return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90003))
            exit()

    def get_arconaitv_channels(self):
	content = self._get_json('/arconaitv/v2/get_channels' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'id': i['id'],
	            'channel': i['channel'],
	            'img': i['img'],
	            'status': i['status']
                    
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    def get_arconaitv_tv_shows(self):
	content = self._get_json('/arconaitv/v2/get_tv_shows' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'id': i['id'],
	            'channel': i['channel'],
	            'img': i['img'],
	            'status': i['status']
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    def get_arconaitv_movies(self):
	content = self._get_json('/arconaitv/v2/get_movies' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'id': i['id'],
	            'channel': i['channel'],
	            'status': i['status']
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    def get_link_arconaitv(self, id):
	content = self._get_json('/arconaitv/v2/get_stream' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'id': id, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'url': i['stream']
	            })
	    return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    def get_sky_channels(self):
	content = self._get_json('/sky/v1/get_channels' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'id': i['id'],
	            'channel': i['channel'],
	            'img': i['img'],
	            'status': i['status']
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
            exit()

    def get_link_sky(self, id):
	content = self._get_json('/sky/v1/get_stream' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'id': id, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
                if i['multi'] == "true":
                    source = xbmcgui.Dialog().select(Addon.get_string(90007), [Addon.get_string(90008),Addon.get_string(90009)])
                    if source == 0:
                        link = i['stream']
                    if source == 1:
                        link = i['stream2']
                    if source < 0:
                        exit()
                else:
                    link = i['stream']
                channels.append({
	            'url': link
	        })
	    return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    def get_greenlie_channels(self):
	content = self._get_json('/greenlie/v1/get_channels' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'id': i['id'],
	            'channel': i['channel'],
	            'img': i['img'],
	            'status': i['status']
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
            exit()

    def get_link_greenlie(self, id):
	content = self._get_json('/greenlie/v1/get_stream' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'id': id, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
                if i['multi'] == "true":
                    source = xbmcgui.Dialog().select(Addon.get_string(90007), [Addon.get_string(90008),Addon.get_string(90009)])
                    if source == 0:
                        link = i['stream']
                    if source == 1:
                        link = i['stream2']
                    if source < 0:
                        exit()
                else:
                    link = i['stream']
                channels.append({
	            'url': link
	        })
	    return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90004))
            exit()

    def get_ondemand_movies(self, cat):
	content = self._get_json('/apollo/v4/get_movies_by_category' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'cat': cat, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'imdb': i['imdb'],
	            'title': i['title'],
	            'plot': i['plot'],
	            'director': i['director'],
	            'writer': i['writer'],
	            'genre': i['genre'],
	            'year': i['year'],
	            'mpaa': i['mpaa'],
	            'poster': i['poster'],
                    'fanart': i['fanart']
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
            exit()

    def get_ondemand_movies_genre(self, genre):
	content = self._get_json('/apollo/v4/get_movies_by_genre' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'genre': genre, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'imdb': i['imdb'],
	            'title': i['title'],
	            'plot': i['plot'],
	            'director': i['director'],
	            'writer': i['writer'],
	            'genre': i['genre'],
	            'year': i['year'],
	            'mpaa': i['mpaa'],
	            'poster': i['poster'],
                    'fanart': i['fanart']
	            })
	    return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
            exit()

    def get_ondemand_movies_search(self, search):
	content = self._get_json('/apollo/v4/search_movies' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'search': search, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
	        channels.append({
	            'imdb': i['imdb'],
	            'title': i['title'],
	            'plot': i['plot'],
	            'director': i['director'],
	            'writer': i['writer'],
	            'genre': i['genre'],
	            'year': i['year'],
	            'mpaa': i['mpaa'],
	            'poster': i['poster'],
                    'fanart': i['fanart']
	            })
	    return channels 
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90005))
            exit()

    def get_link_ondemand_movie(self, title, server):
	content = self._get_json('/vodlocker/v1/get_stream' + base64.b64decode('LnBocA=='), {'key': self.access_key, 'title': title, 'server': server, 'rand': Addon.random_generator()})
	channels = []
	results = content['results'];
        if results:
	    for i in results:
                if i['stream'] == "":
                    self.dlg.ok(Addon.get_string(5000), Addon.get_string(90005))
                    exit()
                else:
                    try:
                        if server == 'trailer':
	                    channels.append({
	                        'url': i['stream']
	                        })
                        else:
	                    channels.append({
	                        'url': urlresolver.resolve(i['stream'])
	                        })
                    except:
                        self.dlg.ok(Addon.get_string(5000), Addon.get_string(90005))
                        exit()
	        return channels
        else:
            self.dlg.ok(Addon.get_string(5000), Addon.get_string(90002))
            exit()

    def _build_url(self, path, queries={}):
        if queries:
            query = Addon.build_query(queries)
            return '%s/%s?%s' % (self.mBASE, path, query)
        else:
            return '%s/%s' % (self.mBASE, path)

    def _build_json(self, path, queries={}):
        if queries:
            query = urllib.urlencode(queries)
            return '%s/%s?%s' % (self.mBASE, path, query)
        else:
            return '%s/%s' % (self.mBASE, path)

    def _build_json_u(self, path, queries={}):
        if queries:
            query = urllib.urlencode(queries)
            return '%s/%s?%s' % (self.uBASE, path, query)
        else:
            return '%s/%s' % (self.mBASE, path)

    def _fetch(self, url, form_data=False):
        opener = urllib2.build_opener()
        opener.addheaders = [('User-agent', 'Mozilla/5.0')]
        if form_data:
            req = urllib2.Request(url, form_data)
        else:
            req = url
        try:
            response = opener.open(req)
            return response
        except urllib2.URLError, e:
            return False

    def _get_json(self, path, queries={}):
        content = False
        url = self._build_json(path, queries)
        response = self._fetch(url)
        if response:
            content = json.loads(response.read())
        else:
            content = False
        return content

    def _get_json_u(self, path, queries={}):
        content = False
        url = self._build_json_u(path, queries)
        response = self._fetch(url)
        if response:
            content = json.loads(response.read())
        else:
            content = False
        return content

    def _get_html(self, path, queries={}):
        html = False
        url = self._build_url(path, queries)
   
        response = self._fetch(url)
        if response:
            html = response.read()
        else:
            html = False
        return html

    def _get_passkey(self):
        token = self._get_json('/ustvnow/v1/token' + base64.b64decode('LnBocA=='), {'key': self.access_key})['token']
        passkey = self._get_json_u('/gtv/1/live/viewdvrlist', {'token': token})['globalparams']['passkey']
        return passkey

    def _get_token(self):
        token = self._get_json('/ustvnow/v1/token' + base64.b64decode('LnBocA=='), {'key': self.access_key})['token']
        return token
