"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmcplugin
import xbmcgui
import sys
import os
import common
import m7lib
import requests
import urllib2
import jsbeautifier.unpackers.packer as packer
from bs4 import BeautifulSoup
import base64
import json


class Channel:

    def __init__(self):
        # Begin Xumo TV & Movies #
        self.XUMO_BASE_API = 'https://valencia-app-mds.xumo.com/v2/%s'
        self.XUMO_BASE_LOGO = 'https://image.xumo.com/v1/channels/channel/%s/512x512.png?type=color_onBlack'
        self.XUMO_BASE_THUMB = 'https://image.xumo.com/v1/assets/asset/%s/512x512.jpg'
        # End Xumo TV & Movies #

        # Begin Live TV Direct #
        self.free_live_tv_extra_channels = [
            {"name": "ABC News", "type": "News"},
            {"name": "CBSN", "type": "News"},
            {"name": "CBSN New York", "type": "News"},
            {"name": "CBS Sports HQ", "type": "Sports"},
            {"name": "ET Live", "type": "Celebrity"},
            {"name": "HLN", "type": "News"}
        ]
        # End Live TV Direct #

    @staticmethod
    def get_genres():
        genres = m7lib.Common.get_genres()
        genres.append("Network TV")
        genres.append("Misc")
        return genres

    @staticmethod
    def get_channel_logo(channel):
        logo = os.path.join(common.plugin_path, 'resources', 'images', 'logos', channel + '.png')
        if os.path.isfile(logo):
            return logo
        return common.ICON

    @staticmethod
    def get_channel_poster(channel):
        filename = channel.replace(":", "").replace("&", "").replace("*", "").replace("+", "")
        logo = os.path.join(common.plugin_path, 'resources', 'images', 'posters', filename + '.jpg')
        if os.path.isfile(logo):
            return logo
        return common.ICON

    # Begin standalone live streams #
    @staticmethod
    def play_abc_news(mode):
        link = m7lib.Common.open_url("https://www.livenewson.com/american/abc-news-2.html")
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, 'file: "(.+?)"'))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_news(mode):
        site_url = "https://www.cbsnews.com/live/"
        match_string = '"contentUrl":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)


    @staticmethod
    def play_cbs_news_ny(mode):
        site_url = "https://www.cbsnews.com/live/cbsn-local-ny/"
        match_string = '"video":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_cbs_sports_hq(mode):
        site_url = "https://www.cbsnews.com/live/cbs-sports-hq/"
        match_string = '"video":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream, mode)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_hln(mode):
        site_url = "https://www.livenewswatch.com/hln.html"
        match_string = 'file: "(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream, mode)
        else:
            common.dlg_stream_failed(common.addonname)

    @staticmethod
    def play_et_live(mode):
        site_url = "https://www.cbsnews.com/live/et-live/"
        match_string = '"video":"(.+?)"'

        req = m7lib.Common.open_url(site_url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream, mode)
        else:
            common.dlg_stream_failed(common.addonname)
    # End standalone live streams #

    # Begin ustvgo #
    @staticmethod
    def get_ustvgo_channels():
        ustvgo_channels = []
        link = m7lib.Common.open_url("http://ustvgo.net/")
        matches = m7lib.Common.find_multiple_matches(link, '<li>(.*?)</li>')

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, '">(.+?)</a>')
            url = m7lib.Common.find_single_match(entry, '<a href="(.+?)"')
            channel = channel.replace("Live", "")\
                .replace(" Free", "")\
                .replace("Streaming", "")\
                .replace("Networks", "") \
                .replace("LIVE", "") \
                .replace("HD", "") \
                .replace("Fox", "FOX") \
                .replace("Golf Channel", "NBC Golf") \
                .replace("Syfy Channel", "SYFY") \
                .replace("Bravo Channel", "Bravo") \
                .replace("FX Channel", "FX") \
                .replace("Lifetime Channel", "Lifetime") \
                .replace("History Channel", "History") \
                .replace("Starz Channel", "Starz") \
                .replace("Freeform Channel", "Freeform") \
                .replace("TBS Channel", "TBS") \
                .replace("#038;","")\
                .strip()
            if "CNN" in channel or \
                    "The Weather Channel" in channel or \
                    "MSNBC" in channel or \
                    "FOX Business" in channel or \
                    "FOX News" in channel:
                type = "News"
            elif "TBS" in channel or "NBC Golf" in channel or "NFL Network" in channel:
                type = "Sports"
            elif "Disney" in channel or "Cartoon" in channel or "Nickelodeon" in channel:
                type = "Kids"
            elif "Starz" in channel or "Hallmark" in channel:
                type = "Movies"
            elif "The CW" in channel or "CBS" in channel or "NBC" in channel or "FOX" in channel or "ABC" in channel:
                type = "Network TV"
            elif "SYFY" in channel:
                type = "Sci-Fi"
            elif "Comedy Central" in channel:
                type = "Comedy"
            elif "National Geographic" in channel or \
                    "Nat Geo Wild" in channel or \
                    "History" in channel or \
                    "Animal Planet" in channel or \
                    "TLC" in channel or \
                    "Discovery Channel" in channel:
                type = "Curiosity"
            elif "Travel Channel" in channel or "HGTV" in channel or "Food Network" in channel or "Bravo" in channel:
                type = "Lifestyle"
            elif "Investigation Discovery" in channel:
                type = "Crime, Curiosity"
            elif "Freeform" in channel:
                type = "Family"
            elif "TV Land" in channel:
                type = "Retro"
            else:
                type = "Misc"
            if channel != "CNBC" and channel != "Tennis Channel":
                ustvgo_channels.append({"name": channel, "type": type, "url": url})
        return ustvgo_channels

    def get_usnewslive_channels(self):
        usnewslive_channels = []
        link = m7lib.Common.open_url("http://usnewslive.tv/")
        matches = m7lib.Common.find_multiple_matches(link, '<div class="mh-excerpt"><p>(.*?)></a></p>')

        other_channel_sources = []
        for channel in Channel.get_ustvgo_channels():
            other_channel_sources.append(channel["name"])
        for channel in self.free_live_tv_extra_channels:
            other_channel_sources.append(channel["name"])
        for channel in m7lib.Common.get_channels():
            other_channel_sources.append(channel["name"])

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, 'title="(.+?)"')
            url = m7lib.Common.find_single_match(entry, 'href="(.+?)"')
            channel = channel.replace(" Stream", "") \
                .replace("Live", "") \
                .replace("Fox", "FOX") \
                .replace("FOX Channel", "FOX") \
                .replace("FOX Business Network", "FOX Business") \
                .replace("Weather Channel", "The Weather Channel") \
                .replace("Syfy", "SYFY") \
                .replace("FX Channel", "FX") \
                .replace("History Channel", "History") \
                .replace("ESPN Channel", "ESPN") \
                .replace("#038;", "") \
                .strip()
            if "CNN" in channel or \
                    "The Weather Channel" in channel or \
                    "MSNBC" in channel or \
                    "FOX Business" in channel or \
                    "FOX News" in channel:
                type = "News"
            elif "TBS" in channel or "NBC Golf" in channel or "NFL Network" in channel or "ESPN" in channel:
                type = "Sports"
            elif "Disney" in channel or "Cartoon" in channel or "Nickelodeon" in channel:
                type = "Kids"
            elif "Starz" in channel or "Hallmark" in channel:
                type = "Movies"
            elif "The CW" in channel or "CBS" in channel or "NBC" in channel or "FOX" in channel or "ABC" in channel:
                type = "Network TV"
            elif "SYFY" in channel:
                type = "Sci-Fi"
            elif "Comedy Central" in channel:
                type = "Comedy"
            elif "National Geographic" in channel or \
                    "Nat Geo Wild" in channel or \
                    "History" in channel or \
                    "Animal Planet" in channel or \
                    "TLC" in channel or \
                    "Discovery Channel" in channel:
                type = "Curiosity"
            elif "Travel Channel" in channel or "HGTV" in channel or "Food Network" in channel or "Bravo" in channel:
                type = "Lifestyle"
            elif "Investigation Discovery" in channel:
                type = "Crime, Curiosity"
            elif "Freeform" in channel:
                type = "Family"
            elif "TV Land" in channel:
                type = "Retro"
            else:
                type = "Misc"
            if channel not in other_channel_sources:
                usnewslive_channels.append({"name": channel, "type": type, "url": url})
        return usnewslive_channels

    @staticmethod
    def play_ustvgo(url):
        link = m7lib.Common.open_url(url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(link, "file: '(.+?)'"))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)
    # End ustvgo #

    # Begin Easyview #
    @staticmethod
    def get_easyview_channels():
        easyview_channels = []
        link = m7lib.Common.open_url("https://easyview.eu/")
        matches = m7lib.Common.find_multiple_matches(link, '<li>(.*?)</li>')

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, '">(.+?)</a>')
            if "News" in channel:
                type = "News"
            elif "CBeebies" in channel or "CBBC" in channel or "CITV" in channel:
                type = "Kids"
            else:
                type = "Misc"
            url = "https://easyview.eu/" + m7lib.Common.find_single_match(entry, '<a href="(.+?)"')
            if channel != "Home":
                easyview_channels.append({"name": channel, "type": type, "url": url})
        return easyview_channels
    # End Easyview #

    @staticmethod
    def play_easyview(url):
        match_string = 'video.src = \'(.+?)\''

        req = m7lib.Common.open_url(url)
        stream = m7lib.Common.rebase(m7lib.Common.find_single_match(req, match_string))
        if "m3u8" in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_stream_failed(common.addonname)

    # Begin ArconaiTV #
    @staticmethod
    def get_arconaitv_channels(type):
        arconaitv_channels = []
        base_url = "https://www.arconaitv.us/"
        link = m7lib.Common.open_url(base_url)
        match = m7lib.Common.find_single_match(link, "<div class='stream-category'>" + type + "</div>(.+?)</div></div> </div>")

        matches = m7lib.Common.find_multiple_matches(match, "<a href(.*?)>")

        for entry in matches:
            channel = m7lib.Common.find_single_match(entry, "title='(.+?)'").replace("Tv","").replace("?","").replace("Fox","FOX").replace("HD","TV")
            url = base_url + m7lib.Common.find_single_match(entry, "='(.+?)'")
            arconaitv_channels.append({"name": channel, "url": url})
        return arconaitv_channels

    @staticmethod
    def play_arconaitv(url):
        r = requests.get(url)
        html_text = r.text
        soup = BeautifulSoup(html_text, 'html.parser')
        scripts = soup.find_all('script')
        code = ""
        for script in scripts:
            if script.string is not None:
                if "document.getElementsByTagName('video')[0].volume = 1.0;" in script.string:
                    code = script.string
                    startidx = code.find('eval(function(p,a,c,k,e,')
                    endidx = code.find('hunterobfuscator =')
                    code = code[startidx: endidx]

                    if not code.replace(' ', '').startswith('eval(function(p,a,c,k,e,'):
                        code = 'fail'
                    break
                else:
                    code = 'fail'
            else:
                code = 'fail'

        if code != 'fail':
            USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36'
            addon_handle = int(sys.argv[1])
            unpacked = packer.unpack(code)
            video_location = unpacked[unpacked.rfind('http'): unpacked.rfind('m3u8') + 4]
            play_item = xbmcgui.ListItem(path=video_location + '|User-Agent=%s' % urllib2.quote(USER_AGENT, safe=''))
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            common.dlg_oops(common.addonname)
    # End ArconaiTV #

    # Begin Pokemon Fire #
    @staticmethod
    def play_pokemon(url):
        player_match_string = '<iframe class="metaframe rptss" src="(.*?)"'
        stream_match_string = 'file: \'(.*?)\''

        # Get Player
        req = m7lib.Common.open_url(url)
        player_url = m7lib.Common.find_single_match(req, player_match_string, 1)

        # Get Stream
        req = m7lib.Common.open_url(player_url)
        stream = m7lib.Common.find_single_match(req, stream_match_string)

        if 'mp4' in stream:
            m7lib.Common.play(stream)
        else:
            common.dlg_oops(common.addonname)
    # End Pokemon Fire #

    # Begin YouTube Channels #
    @staticmethod
    def get_youtube_channel_modes():
        youtube_channels = []
        url = common.TVTime().BASE + "/menus/youtube_channels" + base64.b64decode("LnBocA==") + "?key=" + common.TVTime().access_key
        channels = m7lib.Common.open_url(url)

        channels_list = json.loads(channels)["results"]
        for channel in channels_list:
            youtube_channels.append(channel["mode"])
        return youtube_channels

    @staticmethod
    def get_youtube_channels():
        url = common.TVTime().BASE + "/menus/youtube_channels" + base64.b64decode("LnBocA==") + "?key=" + common.TVTime().access_key
        channels = m7lib.Common.open_url(url)

        channels_list = json.loads(channels)
        return channels_list

    @staticmethod
    def build_youtube_main(mode):
        url = common.TVTime().BASE + "/ytpowered/v1/get_playlists" + base64.b64decode('LnBocA==') + "?mode=" + mode

        content = m7lib.Common.open_url(url)

        playlists = []
        results = json.loads(content)['results']
        for i in results:
            if "Trailer" not in i['title'] and \
                    "My Top Videos" not in i['title'] and \
                    "420 STONER MOVIES" not in i['title'] and \
                    "TRAILER" not in i['title'] and \
                    "Indie Scene" not in i['title'] and \
                    "TERRIFYING THURSDAYS" not in i['title'] and \
                    "For Rent" not in i['title'] and \
                    "Buzz Extras" not in i['title'] and \
                    "After Dark Double Features" not in i['title'] and \
                    "Geek Week" not in i['title'] and \
                    "Maverick On The Oscars" not in i['title'] and \
                    "for Rent" not in i['title'] and \
                    "Meet The Actors" not in i['title'] and \
                    "Weekly Updates" not in i['title'] and \
                    "Teasers" not in i['title'] and "2012 MAVERICK RELEASES" not in i['title']:
                playlists.append({
                    'channel': i['title'],
                    'title': i['title'],
                    'playlist_id': i['playlist_id'],
                    'img': i['img']
                })
        return playlists

    @staticmethod
    def get_youtube_streams(playlist_id):
        url = common.TVTime().BASE + "/ytpowered/v1/get_streams" + base64.b64decode('LnBocA==') + "?id=" + playlist_id

        content = m7lib.Common.open_url(url)

        streams = []
        results = json.loads(content)['results']
        for i in results:
            if "Movie Trailer" not in i['title'] and \
                    "trailer" not in i['title'] and \
                    "trailer" not in i['title'] and \
                    "Trailer" not in i['title'] and \
                    "Coming Soon" not in i['title'] and \
                    "Coming soon" not in i['title'] and \
                    "coming Soon" not in i['title'] and \
                    "Watch Maverick Movies" not in i['title']:
                title = i['title']
                streams.append({
                    'channel': i['title'],
                    'title': title,
                    'videoId': i['id'],
                    'img': i['img']
                })

        return streams

    def show_youtube_streams(self, title, playlist_id, mode):
        if title in mode:
            streams = self.get_youtube_streams(playlist_id)
            if streams:
                for c in streams:
                    title = c['title']
                    videoId = c['videoId']
                    img = c['img']
                    m7lib.Common().add_channel(videoId + "_play-youtube", img, common.FANART, title, live=False)

    @staticmethod
    def play_youtube(id):
        url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
        item = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    # End YouTube Channels #