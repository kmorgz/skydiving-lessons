"""
    TV Time Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import cgi
import os
import sys
import xbmcaddon
import xbmcgui
import requests
import base64
import json
import urlparse
import m7lib

reload(sys)
sys.setdefaultencoding('utf8')

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
plugin_path = xbmcaddon.Addon(id=addonid).getAddonInfo('path')
ICON = os.path.join(plugin_path, 'icon.png')
FANART = os.path.join(plugin_path, 'fanart.jpg')
dlg = xbmcgui.Dialog()
dlg_progress = xbmcgui.DialogProgress()


class TVTime:
    def __init__(self):
        self.access_key = str(get_setting('access_key'))
        self.BASE = base64.b64decode('aHR0cHM6Ly90dnRpbWUudmVsdmV0aG90ZG9nLmNvbS9hcGkv')
        self.OPL_BASE = base64.b64decode('aHR0cHM6Ly9hcGkub2RiLnRvL2VtYmVkP3RpdGxlPQ==')
        self.plugin_url = sys.argv[0]
        self.plugin_handle = int(sys.argv[1])
        self.plugin_queries = parse_query(sys.argv[2][1:])

    def check_access_key(self, access_key):
        key_check_url = self.BASE + "/check_key" + base64.b64decode(
            'LnBocA==') + "?key=" + access_key
        return json.loads(m7lib.Common.open_url(key_check_url))['status']


def dlg_stream_failed(heading):
    dlg.ok(heading, get_string(100000))
    exit()


def dlg_oops(heading):
    dlg.ok(heading, get_string(100001))
    exit()


def get_setting(setting):
    return addon.getSetting(setting)


def set_setting(setting, string):
    return addon.setSetting(setting, string)


def exists_url(path):
    r = requests.head(path)
    return r.status_code == requests.codes.ok


def exists_local(path):
    return os.path.isfile(path)


def is_non_zero_file(path):
    return os.path.getsize(path) > 0


def get_string(string_id):
    return addon.getLocalizedString(string_id)


def parse_query(query, clean=True):
    queries = urlparse.parse_qs(query)
    q = {}
    for key, value in queries.items():
        q[key] = value[0]
    if clean:
        q['mode'] = q.get('mode', 'main')
        q['play'] = q.get('play', '')

    return q


def show_settings():
    addon.openSettings()
    exit()